#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
《光遇》APK完整性绕过工具
功能：直接修改APK中的libBootloader.so文件，将"integrity"字符串替换为空字节，
     绕过游戏启动时的完整性检测。
特点：无需解压重压缩，直接在APK中修改文件，避免文件损坏和闪退问题。
"""

import os
import sys
import zipfile
import shutil

# ==================== 核心功能 ====================

def patch_integrity(apk_path):
    """
    修改APK中的libBootloader.so，绕过完整性检查
    
    参数:
        apk_path: APK文件路径
    
    返回:
        bool: 修改成功返回True，否则返回False
    """
    print(f"🔧 开始修改完整性检查: {apk_path}")
    
    # 检查文件是否存在
    if not os.path.exists(apk_path):
        print("❌ APK文件不存在")
        return False
    
    # 创建备份
    backup_path = apk_path + '.bak'
    print(f"📦 创建备份: {backup_path}")
    shutil.copy2(apk_path, backup_path)
    
    try:
        # 打开APK文件（追加模式，允许修改）
        with zipfile.ZipFile(apk_path, 'a') as apk:
            namelist = apk.namelist()
            
            # 可能的libBootloader.so路径（不同架构）
            so_patterns = [
                'lib/arm64-v8a/libBootloader.so',
                'lib/armeabi-v7a/libBootloader.so',
                'lib/x86/libBootloader.so',
                'lib/x86_64/libBootloader.so',
            ]
            
            modified = False
            
            for so_path in so_patterns:
                if so_path in namelist:
                    print(f"✅ 找到目标文件: {so_path}")
                    
                    # 读取.so文件
                    with apk.open(so_path, 'r') as f:
                        so_data = f.read()
                    
                    # 查找integrity字符串
                    target = b"integrity"
                    if target not in so_data:
                        print(f"⚠️ 未找到 integrity 字符串，跳过")
                        continue
                    
                    # 统计找到的数量
                    count = so_data.count(target)
                    print(f"📊 找到 {count} 个 integrity 字符串")
                    
                    # 替换所有integrity为空字节
                    new_so_data = bytearray()
                    last_pos = 0
                    pos = 0
                    
                    while True:
                        pos = so_data.find(target, pos)
                        if pos == -1:
                            break
                        
                        # 保留前面的数据
                        new_so_data.extend(so_data[last_pos:pos])
                        # 替换为9个空字节（integrity长度为9）
                        new_so_data.extend(b'\x00' * 9)
                        
                        last_pos = pos + 9
                        pos = last_pos
                    
                    # 添加剩余数据
                    new_so_data.extend(so_data[last_pos:])
                    
                    # 验证长度一致性
                    if len(new_so_data) != len(so_data):
                        print(f"❌ 长度不匹配: 原={len(so_data)} 新={len(new_so_data)}")
                        continue
                    
                    # 创建临时APK并替换
                    temp_apk = apk_path + '.temp'
                    if create_modified_apk(apk_path, temp_apk, {so_path: bytes(new_so_data)}):
                        shutil.move(temp_apk, apk_path)
                        modified = True
                        print(f"✅ {so_path} 修改完成")
                        break
                    else:
                        print(f"❌ 创建修改版APK失败")
                        return False
            
            if modified:
                print("\n✨ 完整性绕过修改成功！")
                print(f"📁 原始备份: {backup_path}")
                return True
            else:
                print("\n❌ 未找到任何 libBootloader.so 文件")
                return False
                
    except Exception as e:
        print(f"❌ 修改失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 恢复备份
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, apk_path)
            print("✅ 已恢复原始文件")
        
        return False


def create_modified_apk(input_apk, output_apk, modified_files):
    """
    创建新APK，替换指定文件
    
    参数:
        input_apk: 原始APK路径
        output_apk: 输出APK路径
        modified_files: 需要替换的文件字典 {文件名: 新内容}
    
    返回:
        bool: 成功返回True
    """
    try:
        with zipfile.ZipFile(input_apk, 'r') as zin:
            with zipfile.ZipFile(output_apk, 'w') as zout:
                for item in zin.infolist():
                    if item.filename in modified_files:
                        zout.writestr(item, modified_files[item.filename])
                    else:
                        zout.writestr(item, zin.read(item.filename))
        return True
    except Exception as e:
        print(f"创建APK失败: {e}")
        return False


def verify_apk(apk_path):
    """
    验证APK是否有效
    
    参数:
        apk_path: APK文件路径
    
    返回:
        bool: 有效返回True
    """
    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            # 检查基本文件
            if 'AndroidManifest.xml' not in apk.namelist():
                print("❌ APK缺少 AndroidManifest.xml")
                return False
            if 'classes.dex' not in apk.namelist():
                print("❌ APK缺少 classes.dex")
                return False
            
            # 测试ZIP完整性
            corrupt = apk.testzip()
            if corrupt:
                print(f"❌ ZIP文件损坏: {corrupt}")
                return False
            
            return True
    except Exception as e:
        print(f"❌ APK验证失败: {e}")
        return False


def find_apk_files():
    """
    查找当前目录下的APK文件
    
    返回:
        list: APK文件路径列表
    """
    apk_files = []
    for file in os.listdir('.'):
        if file.endswith('.apk'):
            apk_files.append(file)
    return apk_files


# ==================== 主程序 ====================

def main():
    """主函数"""
    print("=" * 60)
    print("《光遇》APK完整性绕过工具")
    print("功能：绕过游戏启动时的完整性检测")
    print("=" * 60)
    
    # 查找APK文件
    apk_files = find_apk_files()
    
    if not apk_files:
        print("\n当前目录下未找到APK文件")
        print("\n目录内容:")
        for file in os.listdir('.'):
            print(f"  {file}")
        
        apk_path = input("\n请输入APK文件路径: ").strip()
        if not apk_path:
            print("❌ 未输入路径")
            return
        if not os.path.exists(apk_path):
            print("❌ 文件不存在")
            return
        
        apk_files = [apk_path]
    
    # 显示找到的文件
    print(f"\n找到 {len(apk_files)} 个APK文件:")
    for i, file in enumerate(apk_files, 1):
        try:
            size = os.path.getsize(file) // (1024 * 1024)
            print(f"  {i}. {file} ({size} MB)")
        except:
            print(f"  {i}. {file}")
    
    # 选择文件
    if len(apk_files) == 1:
        apk_path = apk_files[0]
        print(f"\n使用文件: {apk_path}")
    else:
        while True:
            try:
                choice = input(f"\n请选择文件 (1-{len(apk_files)}): ").strip()
                idx = int(choice) - 1
                if 0 <= idx < len(apk_files):
                    apk_path = apk_files[idx]
                    break
                else:
                    print(f"请输入 1-{len(apk_files)}")
            except ValueError:
                print("请输入数字")
    
    # 验证APK
    print("\n🔍 验证APK文件...")
    if not verify_apk(apk_path):
        print("⚠️ APK验证未通过，是否继续？")
        confirm = input("继续修改? (y/n): ").strip().lower()
        if confirm != 'y':
            print("操作取消")
            return
    
    # 确认操作
    print("\n⚠️  即将修改APK的完整性检查")
    print("   - 会创建 .bak 备份文件")
    print("   - 修改后需要重新签名才能安装")
    confirm = input("\n确认继续? (y/n): ").strip().lower()
    if confirm != 'y':
        print("操作取消")
        return
    
    # 执行修改
    success = patch_integrity(apk_path)
    
    if success:
        print("\n" + "=" * 60)
        print("✨ 修改完成！")
        print("\n【后续步骤】")
        print("   1. 修改后的APK需要重新签名才能安装")
        print("   2. 推荐使用 MT 管理器（Android）或 apktool（电脑）签名")
        print("   3. 签名后即可安装使用")
        print("\n【注意事项】")
        print("   - 如果安装后闪退，请先卸载原版再安装")
        print("   - 备份文件已保存为: " + apk_path + ".bak")
        print("=" * 60)
    else:
        print("\n❌ 修改失败，请检查APK文件是否正常")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n操作取消")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    
    input("\n按回车键退出...")