#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
《光遇》APK模型提取与添加工具
功能：
    1. 从APK安装包中提取 /assets/Data/Meshes/Bin/ 目录下的所有 .mesh 文件
    2. 将本地 .mesh 文件添加到APK的 /assets/Data/Meshes/Bin/ 目录中
输出：提取时保存到当前目录的 mesh/ 文件夹，添加时生成修改后的APK文件
      提取和添加完成后都会生成txt报告文件
"""

import os
import sys
import zipfile
import shutil
from pathlib import Path
import time

# ==================== 全局配置 ====================
TARGET_PATH = "assets/Data/Meshes/Bin/"
OUTPUT_DIR = "mesh"                     # 提取时的输出目录
REPORT_PREFIX = "mesh_list_"            # 报告文件前缀


def find_apk_files():
    """查找当前目录下的所有APK文件"""
    apk_files = [f for f in os.listdir('.') if f.lower().endswith('.apk')]
    return apk_files


def select_apk_file(apk_files):
    """交互选择APK文件"""
    if not apk_files:
        print("\n当前目录下未找到APK文件")
        apk_path = input("请输入APK文件路径: ").strip()
        if not apk_path or not os.path.isfile(apk_path):
            print("❌ 文件不存在")
            return None
        return apk_path

    print(f"\n找到 {len(apk_files)} 个APK文件:")
    for i, file in enumerate(apk_files, 1):
        size = os.path.getsize(file) // (1024 * 1024)
        print(f"  {i}. {file} ({size} MB)")

    if len(apk_files) == 1:
        print(f"\n使用文件: {apk_files[0]}")
        return apk_files[0]

    while True:
        try:
            choice = input(f"\n请选择文件 (1-{len(apk_files)}): ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(apk_files):
                return apk_files[idx]
            else:
                print(f"请输入 1-{len(apk_files)}")
        except ValueError:
            print("请输入数字")


def generate_report(file_list, output_path, action="extract"):
    """
    生成报告文件
    参数：
        file_list: 文件路径列表（相对路径）
        output_path: 报告输出路径
        action: 操作类型（extract/add）
    """
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    report_name = f"{REPORT_PREFIX}{action}_{timestamp}.txt"
    report_file = os.path.join(output_path, report_name)

    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write(f"《光遇》模型{action}报告\n")
        f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"共 {len(file_list)} 个文件\n\n")
        f.write("文件列表:\n")
        for i, file in enumerate(file_list, 1):
            f.write(f"  {i}. {file}\n")
        f.write("\n" + "=" * 60 + "\n")

    print(f"📄 报告已保存: {report_file}")
    return report_file


def extract_meshes(apk_path, output_dir=OUTPUT_DIR):
    """
    从APK中提取所有 .mesh 文件
    返回：提取的文件列表（相对路径）
    """
    extracted_files = []
    target_prefix = TARGET_PATH

    # 创建输出目录
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    print(f"\n📦 正在读取APK: {apk_path}")
    print(f"📁 目标路径: {target_prefix}")

    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            all_files = apk.namelist()
            mesh_files = [f for f in all_files if f.startswith(target_prefix) and f.endswith('.mesh')]

            if not mesh_files:
                print("⚠️ 未找到任何 .mesh 文件")
                return extracted_files

            print(f"✅ 找到 {len(mesh_files)} 个 .mesh 文件")

            for i, file_path in enumerate(mesh_files, 1):
                rel_path = file_path[len(target_prefix):]
                output_file = output_path / rel_path
                output_file.parent.mkdir(parents=True, exist_ok=True)

                with apk.open(file_path) as src:
                    with open(output_file, 'wb') as dst:
                        dst.write(src.read())

                extracted_files.append(rel_path)
                print(f"  [{i}/{len(mesh_files)}] 提取: {rel_path}")

    except zipfile.BadZipFile:
        print("❌ 错误: 文件不是有效的APK/ZIP文件")
    except Exception as e:
        print(f"❌ 提取失败: {e}")

    return extracted_files


def add_meshes(apk_path, source_path):
    """
    将本地mesh文件添加到APK中
    参数：
        apk_path: 原始APK路径
        source_path: 本地mesh文件或目录路径
    返回：
        (success, added_files) 是否成功和添加的文件列表
    """
    if not os.path.exists(source_path):
        print(f"❌ 源路径不存在: {source_path}")
        return False, []

    # 收集要添加的mesh文件
    mesh_files_to_add = []
    if os.path.isfile(source_path) and source_path.endswith('.mesh'):
        mesh_files_to_add.append(('', source_path))  # (相对路径, 绝对路径)
    elif os.path.isdir(source_path):
        for root, dirs, files in os.walk(source_path):
            for file in files:
                if file.endswith('.mesh'):
                    abs_path = os.path.join(root, file)
                    rel_path = os.path.relpath(abs_path, source_path)
                    mesh_files_to_add.append((rel_path, abs_path))
    else:
        print(f"❌ 源路径不是.mesh文件也不是目录: {source_path}")
        return False, []

    if not mesh_files_to_add:
        print("⚠️ 未找到任何 .mesh 文件")
        return False, []

    print(f"✅ 找到 {len(mesh_files_to_add)} 个 .mesh 文件")

    # 创建修改后的APK文件名
    base, ext = os.path.splitext(apk_path)
    new_apk_path = f"{base}_modified{ext}"
    backup_path = f"{new_apk_path}.bak"

    # 先备份原APK
    shutil.copy2(apk_path, backup_path)
    print(f"📦 已备份原APK: {backup_path}")

    added_files = []
    try:
        # 创建新APK
        with zipfile.ZipFile(apk_path, 'r') as zin:
            with zipfile.ZipFile(new_apk_path, 'w') as zout:
                # 复制所有原文件
                for item in zin.infolist():
                    zout.writestr(item, zin.read(item.filename))

                # 添加新mesh文件
                for rel_path, abs_path in mesh_files_to_add:
                    arc_name = TARGET_PATH + rel_path
                    with open(abs_path, 'rb') as src:
                        data = src.read()
                    zout.writestr(arc_name, data)
                    added_files.append(rel_path)
                    print(f"  ➕ 添加: {arc_name}")

        print(f"✅ 新APK已生成: {new_apk_path}")
        return True, added_files

    except Exception as e:
        print(f"❌ 添加失败: {e}")
        if os.path.exists(new_apk_path):
            os.remove(new_apk_path)
        # 恢复备份
        if os.path.exists(backup_path):
            shutil.move(backup_path, apk_path)
            print("✅ 已恢复原APK")
        return False, []


def main():
    print("=" * 60)
    print("《光遇》APK模型提取与添加工具")
    print("功能：提取或添加 /assets/Data/Meshes/Bin/ 下的 .mesh 文件")
    print("=" * 60)

    # 查找APK文件
    apk_files = find_apk_files()
    if not apk_files:
        print("\n当前目录下未找到APK文件")
        print("请将APK文件放在本脚本同一目录下，或稍后手动输入路径")
        manual = input("\n是否手动输入APK路径？(y/n): ").strip().lower()
        if manual != 'y':
            return
        apk_path = input("请输入APK文件路径: ").strip()
        if not apk_path or not os.path.isfile(apk_path):
            print("❌ 文件不存在")
            return
        apk_files = [apk_path]

    # 选择APK文件
    apk_path = select_apk_file(apk_files)
    if not apk_path:
        return

    # 显示功能菜单
    print("\n" + "=" * 60)
    print("请选择功能:")
    print("  1. 提取模型（从APK导出 .mesh 文件）")
    print("  2. 添加模型（将 .mesh 文件添加到APK）")
    print("  3. 退出")
    print("=" * 60)

    while True:
        choice = input("\n请输入数字 (1/2/3): ").strip()
        if choice == '1':
            # 提取
            extracted = extract_meshes(apk_path)
            if extracted:
                print(f"\n✅ 成功提取 {len(extracted)} 个 .mesh 文件")
                print(f"📁 保存位置: {OUTPUT_DIR}/")
                # 生成报告
                generate_report(extracted, OUTPUT_DIR, action="extract")
            else:
                print("❌ 未提取任何文件")
            break

        elif choice == '2':
            # 添加
            source = input("请输入本地mesh文件或目录路径: ").strip()
            if not source:
                print("❌ 未输入路径")
                continue

            success, added = add_meshes(apk_path, source)
            if success and added:
                print(f"\n✅ 成功添加 {len(added)} 个 .mesh 文件")
                # 生成报告
                base_name = os.path.basename(apk_path).replace('.apk', '')
                report_dir = os.path.dirname(apk_path)
                generate_report(added, report_dir, action="add")
            else:
                print("❌ 添加失败")
            break

        elif choice == '3':
            print("退出程序")
            return
        else:
            print("请输入 1、2 或 3")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n操作取消")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    input("\n按回车键退出...")