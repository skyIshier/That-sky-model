#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#作者：县小威，qq：3661380498
#公开群：1027346190
#开源免费，拒绝倒卖
"""
光遇APK直接修改工具
不进行解压重压缩，直接在APK中修改文件
解决文件损坏和闪退问题
"""

import os
import sys
import zipfile
import json
import random
import re
import struct
import shutil
from io import BytesIO

def modify_apk_directly(apk_path):
    """
    直接在APK中修改文件，不进行解压重压缩
    """
    print(f"🔧 开始直接修改: {apk_path}")
    
    if not os.path.exists(apk_path):
        print("❌ APK文件不存在")
        return False
    
    # 备份原始文件
    backup_path = apk_path + '.bak'
    shutil.copy2(apk_path, backup_path)
    print(f"✅ 已创建备份: {backup_path}")
    
    try:
        # 使用'r+b'模式打开，可读写二进制
        with zipfile.ZipFile(apk_path, 'a') as apk:  # 'a' 追加模式
            namelist = apk.namelist()
            
            # === 1. 修改OutfitDefs.json ===
            print("\n🎮 查找衣柜文件...")
            json_paths = [
                'assets/Data/Resources/OutfitDefs.json',
                'assets/Data/OutfitDefs.json',
                'Data/Resources/OutfitDefs.json',
            ]
            
            json_modified = False
            for json_path in json_paths:
                if json_path in namelist:
                    print(f"找到: {json_path}")
                    
                    # 读取JSON文件
                    with apk.open(json_path, 'r') as f:
                        content = f.read().decode('utf-8')
                        data = json.loads(content)
                    
                    print("修改衣柜数据...")
                    
                    # 检查版本
                    hair_AvatarFurCham = False
                    has_21 = False
                    
                    for item in data:
                        if "season" in item and isinstance(item["season"], str):
                            if "season_18" in item["season"]:
                                hair_AvatarFurCham = True
                            if "season_21" in item["season"]:
                                has_21 = True
                            if "season_26" in item["season"]:
                                hair_AvatarFurCham = False
                    
                    print(f"改炸毛: {hair_AvatarFurCham}, 九色鹿光翼: {has_21}")
                    
                    # 修改数据
                    modified_count = 0
                    wing_modified = 0
                    
                    for item in data:
                        # 基础解锁
                        if "isDefault" in item and not item["isDefault"]:
                            item["isDefault"] = True
                            modified_count += 1
                        if "isSkyKid" in item and not item["isSkyKid"]:
                            item["isSkyKid"] = True
                            modified_count += 1
                        if "inCloset" in item and not item["inCloset"]:
                            item["inCloset"] = True
                            modified_count += 1
                        if "isOnesie" in item and not item["isOnesie"]:
                            item["isOnesie"] = True
                            modified_count += 1
                        
                        # NPC着色器
                        if "name" in item and isinstance(item["name"], str):
                            if re.search(r'npc', item["name"], re.IGNORECASE):
                                item["shader"] = "SpiritBody"
                                modified_count += 1
                        
                        # 炸毛效果
                        if hair_AvatarFurCham and "type" in item and item["type"] == "hair":
                            item["shader"] = "AvatarFurCham"
                            modified_count += 1
                        
                        # 九色鹿光翼颜色
                        if has_21 and "type" in item and item["type"] == "wing":
                            colors = []
                            for i in range(5):
                                colors.append({
                                    "highEnergy": [
                                        random.randint(0, 360),
                                        random.randint(0, 100),
                                        80
                                    ]
                                })
                            item["wingStarColors"] = colors
                            wing_modified += 1
                    
                    print(f"修改了 {modified_count} 个项目，{wing_modified} 个光翼颜色")
                    
                    # 转换为JSON字符串
                    new_json = json.dumps(data, indent=2, ensure_ascii=False)
                    
                    # 删除原文件（通过创建一个新APK来替换）
                    temp_apk = apk_path + '.temp'
                    create_modified_apk(apk_path, temp_apk, {json_path: new_json.encode('utf-8')})
                    
                    # 替换原始APK
                    shutil.move(temp_apk, apk_path)
                    
                    json_modified = True
                    print("✅ 衣柜文件修改完成")
                    break
            
            if not json_modified:
                print("⚠️ 未找到衣柜文件")
            #作者：县小威，qq：3661380498
            #公开群：1027346190
            #开源免费，拒绝倒卖
            # === 2. 修改libBootloader.so ===
            print("\n🔧 查找Bootloader文件...")
            so_patterns = [
                'lib/arm64-v8a/libBootloader.so',
                'lib/armeabi-v7a/libBootloader.so',
                'lib/x86/libBootloader.so',
                'lib/x86_64/libBootloader.so',
            ]
            
            so_modified = False
            for so_path in so_patterns:
                if so_path in namelist:
                    print(f"找到: {so_path}")
                    
                    # 读取.so文件
                    with apk.open(so_path, 'r') as f:
                        so_data = f.read()
                    
                    # 查找并替换integrity
                    target = b"integrity"
                    if target in so_data:
                        count = so_data.count(target)
                        print(f"找到 {count} 个integrity字符串")
                        
                        # 逐个替换
                        new_so_data = bytearray()
                        last_pos = 0
                        pos = 0
                        
                        while True:
                            pos = so_data.find(target, pos)
                            if pos == -1:
                                break
                            
                            new_so_data.extend(so_data[last_pos:pos])
                            new_so_data.extend(b'\x00' * 9)
                            
                            last_pos = pos + 9
                            pos = last_pos
                        
                        new_so_data.extend(so_data[last_pos:])
                        
                        # 验证长度
                        if len(new_so_data) == len(so_data):
                            # 创建新APK
                            temp_apk = apk_path + '.temp'
                            create_modified_apk(apk_path, temp_apk, {so_path: bytes(new_so_data)})
                            
                            # 替换原始APK
                            shutil.move(temp_apk, apk_path)
                            
                            so_modified = True
                            print(f"✅ {so_path} 修改完成")
                        else:
                            print(f"❌ 长度不匹配，跳过修改")
                    else:
                        print(f"未找到integrity字符串")
                    break
            
            if not so_modified:
                print("⚠️ 未找到Bootloader文件")
            
            return True
            
    except Exception as e:
        print(f"❌ 修改失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 恢复备份
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, apk_path)
            print("✅ 已恢复原始文件")
        
        return False

def create_modified_apk(input_apk, output_apk, modified_files):
    """
    创建一个新APK，只替换指定的文件
    """
    print(f"创建修改版APK: {output_apk}")
    
    try:
        with zipfile.ZipFile(input_apk, 'r') as zin:
            with zipfile.ZipFile(output_apk, 'w') as zout:
                # 复制所有文件，替换需要修改的文件
                for item in zin.infolist():
                    if item.filename in modified_files:
                        # 使用修改后的内容
                        zout.writestr(item, modified_files[item.filename])
                        print(f"替换: {item.filename}")
                    else:
                        # 复制原始文件
                        zout.writestr(item, zin.read(item.filename))
        
        return True
    except Exception as e:
        print(f"创建修改版失败: {e}")
        return False

def patch_apk_inplace(apk_path):
    """
    直接在APK中打补丁（更高级的方法）
    """
    print(f"\n⚡ 使用高级方法修改APK...")
    
    # 备份
    backup_path = apk_path + '.orig'
    shutil.copy2(apk_path, backup_path)
    
    try:
        # 读取整个APK到内存
        with open(apk_path, 'rb') as f:
            apk_data = bytearray(f.read())
        
        # === 修改JSON文件 ===
        print("搜索JSON文件...")
        
        # 查找ZIP目录中的文件
        with zipfile.ZipFile(apk_path, 'r') as apk:
            for filename in apk.namelist():
                if 'OutfitDefs.json' in filename:
                    print(f"找到JSON文件: {filename}")
                    
                    # 获取文件在ZIP中的位置
                    with apk.open(filename) as f:
                        json_content = f.read()
                    
                    # 解析和修改JSON
                    data = json.loads(json_content.decode('utf-8'))
                    
                    # 简化修改（只做核心修改）
                    modified = False
                    for item in data:
                        # 解锁所有物品
                        if "isDefault" in item:
                            item["isDefault"] = True
                            modified = True
                        if "isSkyKid" in item:
                            item["isSkyKid"] = True
                            modified = True
                        if "inCloset" in item:
                            item["inCloset"] = True
                            modified = True
                    
                    if modified:
                        # 生成新的JSON
                        new_json = json.dumps(data, ensure_ascii=False)
                        
                        # 在APK数据中查找和替换
                        old_bytes = json_content
                        new_bytes = new_json.encode('utf-8')
                        
                        if len(new_bytes) <= len(old_bytes):
                            # 可以直接替换
                            pos = apk_data.find(old_bytes)
                            if pos != -1:
                                # 替换并填充剩余空间
                                apk_data[pos:pos+len(new_bytes)] = new_bytes
                                # 剩余部分填充0
                                if len(old_bytes) > len(new_bytes):
                                    apk_data[pos+len(new_bytes):pos+len(old_bytes)] = b'\x00' * (len(old_bytes) - len(new_bytes))
                                print("✅ JSON文件已修改")
                            else:
                                print("❌ 未找到JSON数据")
                        break
        
        # === 修改.so文件 ===
        print("\n搜索.so文件...")
        
        # 在二进制数据中直接查找integrity
        target = b"integrity"
        positions = []
        
        index = 0
        while index < len(apk_data):
            pos = apk_data.find(target, index)
            if pos == -1:
                break
            positions.append(pos)
            index = pos + 1
        
        if positions:
            print(f"找到 {len(positions)} 个integrity")
            
            # 替换所有找到的integrity
            for pos in positions:
                apk_data[pos:pos+9] = b'\x00' * 9
            
            print("✅ integrity已清除")
        
        # 写回文件
        with open(apk_path, 'wb') as f:
            f.write(apk_data)
        
        print(f"\n✅ APK修改完成")
        print(f"原始备份: {backup_path}")
        
        return True
        
    except Exception as e:
        print(f"❌ 修改失败: {e}")
        # 恢复备份
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, apk_path)
            print("✅ 已恢复原始文件")
        return False

def verify_apk(apk_path):
    """
    验证APK是否有效
    """
    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            # 检查基本文件
            required = ['AndroidManifest.xml', 'classes.dex']
            for req in required:
                if req not in apk.namelist():
                    print(f"❌ 缺少必要文件: {req}")
                    return False
            
            # 测试ZIP完整性
            corrupt = apk.testzip()
            if corrupt:
                print(f"❌ ZIP文件损坏: {corrupt}")
                return False
            
            print("✅ APK验证通过")
            return True
    except Exception as e:
        print(f"❌ APK验证失败: {e}")
        return False

def main():
    """主函数"""
    print("=" * 60)
    print("光遇APK直接修改工具")
    print("无需解压，直接在APK中修改文件")
    print("=" * 60)
    
    # 查找APK文件
    apk_files = []
    for file in os.listdir('.'):
        if file.endswith('.apk') and ('光遇' in file or 'sky' in file.lower()):
            apk_files.append(file)
    
    if not apk_files:
        print("当前目录下未找到光遇APK文件")
        print("\n目录内容:")
        for file in os.listdir('.'):
            print(f"  {file}")
        
        apk_path = input("\n请输入APK文件路径: ").strip()
        if not os.path.exists(apk_path):
            print("❌ 文件不存在")
            return
        
        # 验证APK
        if verify_apk(apk_path):
            print("\n选择修改方式:")
            print("1. 标准方法（推荐）")
            print("2. 高级方法（直接二进制修改）")
            
            choice = input("请选择 (1/2): ").strip()
            
            if choice == '1':
                modify_apk_directly(apk_path)
            elif choice == '2':
                patch_apk_inplace(apk_path)
            else:
                print("❌ 无效选择")
        return
    
    # 显示找到的文件
    print(f"找到 {len(apk_files)} 个APK文件:")
    for i, file in enumerate(apk_files, 1):
        size = os.path.getsize(file) // (1024 * 1024)
        print(f"  {i}. {file} ({size}MB)")
    
    # 选择文件
    if len(apk_files) == 1:
        apk_path = apk_files[0]
    else:
        while True:
            try:
                choice = input(f"\n选择文件 (1-{len(apk_files)}): ").strip()
                idx = int(choice) - 1
                if 0 <= idx < len(apk_files):
                    apk_path = apk_files[idx]
                    break
                else:
                    print(f"请输入 1-{len(apk_files)}")
            except ValueError:
                print("请输入数字")
    
    # 验证APK
    if not verify_apk(apk_path):
        print("❌ APK可能已损坏")
        return
    
    # 选择修改方式
    print("\n选择修改方式:")
    print("1. 标准方法 - 安全可靠（推荐）")
    print("2. 高级方法 - 直接二进制修改（快速）")
    print("3. 两种方法都尝试")
    
    method_choice = input("请选择 (1/2/3): ").strip()
    
    if method_choice == '1':
        success = modify_apk_directly(apk_path)
    elif method_choice == '2':
        success = patch_apk_inplace(apk_path)
    elif method_choice == '3':
        print("\n先尝试方法1...")
        success = modify_apk_directly(apk_path)
        if not success:
            print("\n方法1失败，尝试方法2...")
            # 恢复备份
            if os.path.exists(apk_path + '.bak'):
                shutil.copy2(apk_path + '.bak', apk_path)
            success = patch_apk_inplace(apk_path)
    else:
        print("❌ 无效选择")
        return
    
    if success:
        print("\n✨ 修改完成！")
        print("\n注意:")
        print("1. 修改后的APK可能需要重新签名")
        print("2. 如果闪退，尝试卸载原版再安装")
        print("3. 确保设备允许未知来源安装")
    else:
        print("\n❌ 修改失败")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n操作取消")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    
    input("\n按回车键退出...")