#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
《光遇》APK JSON配置文件提取工具
功能：从APK安装包中提取 /assets/Data/Resources/ 目录下的所有 JSON 文件
      支持保留完整目录结构
输出：保存到当前目录的 json_files/ 文件夹中，并显示提取的文件列表和数量
"""

import os
import sys
import zipfile
from pathlib import Path
import time

# ==================== 全局配置 ====================
TARGET_PATH = "assets/Data/Resources/"
OUTPUT_DIR = "json_files"
REPORT_PREFIX = "json_extract_"


def find_apk_files():
    """查找当前目录下的所有APK文件"""
    apk_files = [f for f in os.listdir('.') if f.lower().endswith('.apk')]
    return apk_files


def select_apk_file(apk_files):
    """交互选择APK文件"""
    if not apk_files:
        print("\n当前目录下未找到APK文件")
        apk_path = input("请输入APK文件路径: ").strip()
        if not apk_path or not os.path.isfile(apk_path):
            print("❌ 文件不存在")
            return None
        return apk_path

    print(f"\n找到 {len(apk_files)} 个APK文件:")
    for i, file in enumerate(apk_files, 1):
        try:
            size = os.path.getsize(file) // (1024 * 1024)
            print(f"  {i}. {file} ({size} MB)")
        except:
            print(f"  {i}. {file}")

    if len(apk_files) == 1:
        print(f"\n使用文件: {apk_files[0]}")
        return apk_files[0]

    while True:
        try:
            choice = input(f"\n请选择文件 (1-{len(apk_files)}): ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(apk_files):
                return apk_files[idx]
            else:
                print(f"请输入 1-{len(apk_files)}")
        except ValueError:
            print("请输入数字")


def generate_report(file_list, output_path, apk_name):
    """
    生成提取报告
    参数：
        file_list: 文件路径列表（相对路径）
        output_path: 报告输出目录
        apk_name: APK文件名
    返回：报告文件路径
    """
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    report_name = f"{REPORT_PREFIX}{timestamp}.txt"
    report_file = os.path.join(output_path, report_name)

    # 统计文件类型
    json_count = 0
    other_count = 0
    json_files = []
    other_files = []

    for f in file_list:
        if f.endswith('.json'):
            json_count += 1
            json_files.append(f)
        else:
            other_count += 1
            other_files.append(f)

    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("=" * 70 + "\n")
        f.write("《光遇》APK JSON配置文件提取报告\n")
        f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"源APK文件: {apk_name}\n")
        f.write(f"提取路径: {TARGET_PATH}\n")
        f.write("=" * 70 + "\n\n")

        f.write(f"【统计信息】\n")
        f.write(f"  总文件数: {len(file_list)}\n")
        f.write(f"  JSON文件: {json_count}\n")
        f.write(f"  其他文件: {other_count}\n\n")

        if json_files:
            f.write("【JSON文件列表】\n")
            for i, file in enumerate(json_files, 1):
                f.write(f"  {i}. {file}\n")
            f.write("\n")

        if other_files:
            f.write("【其他文件列表】（非JSON格式）\n")
            for i, file in enumerate(other_files, 1):
                f.write(f"  {i}. {file}\n")
            f.write("\n")

        f.write("=" * 70 + "\n")
        f.write("提取完成！\n")
        f.write(f"保存位置: {os.path.abspath(output_path)}/\n")
        f.write("=" * 70 + "\n")

    print(f"\n📄 报告已保存: {report_file}")
    return report_file


def extract_json_files(apk_path, output_dir=OUTPUT_DIR):
    """
    从APK中提取所有JSON文件
    返回：提取的文件列表（相对路径）
    """
    extracted_files = []
    target_prefix = TARGET_PATH

    # 创建输出目录
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    print(f"\n📦 正在读取APK: {apk_path}")
    print(f"📁 目标路径: {target_prefix}")
    print(f"📁 输出目录: {output_dir}/")

    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            # 获取所有文件列表
            all_files = apk.namelist()

            # 筛选出目标目录下的所有文件（包括子目录）
            target_files = [f for f in all_files if f.startswith(target_prefix)]

            if not target_files:
                print("⚠️ 未找到任何文件，请确认APK中包含 /assets/Data/Resources/ 目录")
                return extracted_files

            # 统计JSON文件数量
            json_files = [f for f in target_files if f.endswith('.json')]
            print(f"✅ 找到 {len(json_files)} 个 JSON 文件")
            print(f"   总共 {len(target_files)} 个文件（包含其他类型）")

            # 提取所有文件
            for i, file_path in enumerate(target_files, 1):
                # 获取相对路径（去掉目标路径前缀）
                rel_path = file_path[len(target_prefix):]
                # 如果文件在子目录中，保留子目录结构
                output_file = output_path / rel_path
                # 确保子目录存在
                output_file.parent.mkdir(parents=True, exist_ok=True)

                # 读取并写入文件
                with apk.open(file_path) as src:
                    with open(output_file, 'wb') as dst:
                        dst.write(src.read())

                extracted_files.append(rel_path)

                # 显示进度（只显示JSON文件，其他文件简略显示）
                if file_path.endswith('.json'):
                    print(f"  [{i}/{len(target_files)}] 📄 提取: {rel_path}")
                else:
                    print(f"  [{i}/{len(target_files)}] 📁 提取: {rel_path}")

    except zipfile.BadZipFile:
        print("❌ 错误: 文件不是有效的APK/ZIP文件")
    except Exception as e:
        print(f"❌ 提取失败: {e}")
        import traceback
        traceback.print_exc()

    return extracted_files


def main():
    print("=" * 70)
    print("《光遇》APK JSON配置文件提取工具")
    print("功能：提取 /assets/Data/Resources/ 目录下的所有 JSON 文件")
    print("      支持保留完整目录结构（包括子文件夹）")
    print("=" * 70)

    # 查找APK文件
    apk_files = find_apk_files()

    if not apk_files:
        print("\n当前目录下未找到APK文件")
        print("请将APK文件放在本脚本同一目录下，或稍后手动输入路径")
        manual = input("\n是否手动输入APK路径？(y/n): ").strip().lower()
        if manual != 'y':
            return
        apk_path = input("请输入APK文件路径: ").strip()
        if not apk_path or not os.path.isfile(apk_path):
            print("❌ 文件不存在")
            return
        apk_files = [apk_path]

    # 选择APK文件
    apk_path = select_apk_file(apk_files)
    if not apk_path:
        return

    # 确认提取
    print("\n⚠️  即将提取以下内容:")
    print(f"   APK文件: {apk_path}")
    print(f"   提取路径: {TARGET_PATH}")
    print(f"   输出目录: {OUTPUT_DIR}/")
    print(f"   注意: 将提取所有文件（包括子目录中的文件）")

    confirm = input("\n确认提取? (y/n): ").strip().lower()
    if confirm != 'y':
        print("操作取消")
        return

    # 执行提取
    extracted = extract_json_files(apk_path)

    if extracted:
        print(f"\n✅ 成功提取 {len(extracted)} 个文件")
        print(f"📁 保存位置: {OUTPUT_DIR}/")

        # 统计JSON文件数量
        json_count = sum(1 for f in extracted if f.endswith('.json'))
        print(f"📊 其中 JSON 文件: {json_count} 个")

        # 生成报告
        generate_report(extracted, OUTPUT_DIR, os.path.basename(apk_path))

        # 显示目录结构预览
        print("\n📂 目录结构预览:")
        show_dir_structure(OUTPUT_DIR)

    else:
        print("❌ 未提取任何文件")


def show_dir_structure(directory, max_depth=2, max_items=10):
    """
    显示目录结构预览
    """
    dir_path = Path(directory)
    if not dir_path.exists():
        return

    def print_tree(path, prefix="", depth=0):
        if depth > max_depth:
            return
        items = sorted([p for p in path.iterdir()])
        # 限制显示数量
        if len(items) > max_items:
            items = items[:max_items]
            show_more = True
        else:
            show_more = False

        for i, item in enumerate(items):
            is_last = (i == len(items) - 1) and not show_more
            if item.is_dir():
                print(f"{prefix}{'└── ' if is_last else '├── '}{item.name}/")
                print_tree(item, prefix + ("    " if is_last else "│   "), depth + 1)
            else:
                print(f"{prefix}{'└── ' if is_last else '├── '}{item.name}")
        if show_more:
            print(f"{prefix}└── ... 还有更多文件")

    print_tree(dir_path)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n操作取消")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()

    input("\n按回车键退出...")