#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#作者：县小威，qq：3661380498
#公开群：1027346190
#开源免费，拒绝倒卖
"""
光遇APK直接修改工具
包含全物品解锁和地图修改功能
不进行解压重压缩，直接在APK中修改文件
解决文件损坏和闪退问题
"""

import os
import sys
import zipfile
import json
import random
import re
import struct
import shutil
import termios
import tty
from io import BytesIO

# 地图修改规则（直接嵌入）
MAP_PATCH_RULES = {
 "rules":[
  {
    "from": "65 15 08 43 57 27 22 43 01 4E 90 C2",
    "to": "65 15 08 43 15 BB B3 C4 01 4E 90 C2"
  },
  {
    "from": "2F DB 0B 40 55 39 39 43 E6 64 B4 C2",
    "to": "2F DB 0B 40 D6 D8 B0 C4 E6 64 B4 C2"
  },
  {
    "from": "B4 AB 91 C1 32 0C 0C 43 2F 23 98 42",
    "to": "B4 AB 91 C1 7A 7E B6 C4 2F 23 98 42"
  },
  {
    "from": "D1 60 D6 41 50 FE 81 43 93 96 7C C3",
    "to": "D1 60 D6 41 6C 80 A7 C4 93 96 7C C3"
  },
  {
    "from": "AD CC D0 41 89 25 4D 43 DD 9D E5 C2",
    "to": "AD CC D0 41 4F 5B AE C4 DD 9D E5 C2"
  },
  {
    "from": "3A E9 DD C2 BB 19 2C 43 97 65 D9 C2",
    "to": "3A E9 DD C2 C8 7C B2 C4 97 65 D9 C2"
  },
  {
    "from": "CD EC 84 42 54 63 85 43 BB 29 95 C3",
    "to": "CD EC 84 42 2B A7 A6 C4 BB 29 95 C3"
  },
  {
    "from": "29 2D 29 C2 6E 9C 27 43 A6 B8 59 C0",
    "to": "29 2D 29 C2 72 0C B3 C4 A6 B8 59 C0"
  },
  {
    "from": "03 79 FB 40 0C EB 84 43 04 D8 80 C3",
    "to": "03 79 FB 40 3D C5 A6 C4 04 D8 80 C3"
  },
  {
    "from": "63 01 05 41 6C 82 80 43 85 17 68 C3",
    "to": "63 01 05 41 65 DF A7 C4 85 17 68 C3"
  },
  {
    "from": "45 E5 20 42 54 77 7D 43 37 95 58 C3",
    "to": "45 E5 20 42 16 51 A8 C4 37 95 58 C3"
  },
  {
    "from": "EB 51 84 41 96 88 54 43 9C 5F FC C2",
    "to": "EB 51 84 41 ED 6E AD C4 9C 5F FC C2"
  },
  {
    "from": "39 4B DB C0 85 3F 06 43 A5 DE 84 42",
    "to": "39 4B DB C0 10 38 B7 C4 A5 DE 84 42"
  },
  {
    "from": "98 29 87 C3 13 19 97 42 15 20 95 C2",
    "to": "98 29 87 C3 6F 8E BE C4 15 20 95 C2"
  },
  {
    "from": "3F 6B 32 C2 CA 40 80 43 9B 00 60 C3",
    "to": "3F 6B 32 C2 CE EF A7 C4 9B 00 60 C3"
  },
  {
    "from": "76 48 B4 41 5F D2 48 43 83 FC D0 C2",
    "to": "76 48 B4 41 B4 E5 AE C4 83 FC D0 C2"
  },
  {
    "from": "31 64 75 41 26 7A 45 43 60 D3 C0 C2",
    "to": "31 64 75 41 BB 50 AF C4 60 D3 C0 C2"
  },
  {
    "from": "61 4D B8 C0 78 D5 13 43 34 F0 5F 42",
    "to": "61 4D B8 C0 51 85 B5 C4 34 F0 5F 42"
  },
  {
    "from": "FB EE 39 41 3D FE 40 43 44 51 E5 C2",
    "to": "FB EE 39 41 38 E0 AF C4 44 51 E5 C2"
  },
  {
    "from": "28 7A 3C 41 01 E0 52 43 0F 9F ED C2",
    "to": "28 7A 3C 41 00 A4 AD C4 0F 9F ED C2"
  },
  {
    "from": "19 69 24 C1 75 4A 1B 43 C3 93 E9 41",
    "to": "19 69 24 C1 B2 96 B4 C4 C3 93 E9 41"
  },
  {
    "from": "D1 5D BA C0 74 D7 5E 43 87 ED 04 C3",
    "to": "D1 5D BA C0 12 25 AC C4 87 ED 04 C3"
  },
  {
    "from": "12 A2 B6 40 A8 B2 70 43 66 CB 3C C3",
    "to": "12 A2 B6 40 AB E9 A9 C4 66 CB 3C C3"
  },
  {
    "from": "CE 14 4C C1 6C A6 46 43 C6 54 FA C2",
    "to": "CE 14 4C C1 32 2B AF C4 C6 54 FA C2"
  },
  {
    "from": "E3 D5 78 C1 1E 4B 20 43 40 34 31 C2",
    "to": "E3 D5 78 C1 9C F6 B3 C4 40 34 31 C2"
  },
  {
    "from": "AF A3 55 41 59 0E 83 43 6A 31 71 C3",
    "to": "AF A3 55 41 6A 3C A7 C4 6A 31 71 C3"
  },
  {
    "from": "19 94 2C 41 D4 E3 6C 43 05 8A 0A C3",
    "to": "19 94 2C 41 86 63 AA C4 05 8A 0A C3"
  },
  {
    "from": "79 EB D9 40 87 E3 76 43 75 4F 4D C3",
    "to": "79 EB D9 40 8F 23 A9 C4 75 4F 4D C3"
  },
  {
    "from": "40 B9 51 C1 7C FD 2C 43 89 99 F4 C2",
    "to": "40 B9 51 C1 50 60 B2 C4 89 99 F4 C2"
  },
  {
    "from": "37 5E AE C0 9C 4A 19 43 E5 4F C7 41",
    "to": "37 5E AE C0 AC D6 B4 C4 E5 4F C7 41"
  },
  {
    "from": "DE 3C D9 40 EF 17 78 43 34 3D 4E C3",
    "to": "DE 3C D9 40 02 FD A8 C4 34 3D 4E C3"
  },
  {
    "from": "CA E6 C3 40 A8 48 85 43 7E 15 7C C3",
    "to": "CA E6 C3 40 D6 AD A6 C4 7E 15 7C C3"
  },
  {
    "from": "68 D2 AA 41 62 A5 47 43 D1 1F C8 C2",
    "to": "68 D2 AA 41 54 0B AF C4 D1 1F C8 C2"
  },
  {
    "from": "C9 4C 33 41 1A 31 40 43 D2 FD BB C2",
    "to": "C9 4C 33 41 DD F9 AF C4 D2 FD BB C2"
  },
  {
    "from": "BC 38 90 42 4A 68 F9 42 00 D2 3A 42",
    "to": "BC 38 90 42 7C 69 B8 C4 00 D2 3A 42"
  },
  {
    "from": "39 25 BA 3F 4E 45 73 43 96 84 44 C3",
    "to": "39 25 BA 3F 56 97 A9 C4 96 84 44 C3"
  },
  {
    "from": "02 7F 13 40 24 65 84 43 27 C7 72 C3",
    "to": "02 7F 13 40 B7 E6 A6 C4 27 C7 72 C3"
  },
  {
    "from": "82 EB C6 42 F8 05 21 43 68 1F 3A C3",
    "to": "82 EB C6 42 41 DF B3 C4 68 1F 3A C3"
  },
  {
    "from": "88 C0 EE 40 B5 43 85 43 D2 A6 80 C3",
    "to": "88 C0 EE 40 13 AF A6 C4 D2 A6 80 C3"
  },
  {
    "from": "3D 6E 8C 40 FA B7 6D 43 99 55 35 C3",
    "to": "3D 6E 8C 40 01 49 AA C4 99 55 35 C3"
  },
  {
    "from": "CF A4 1C C2 A2 14 5F 43 50 2D 37 C3",
    "to": "CF A4 1C C2 6C 1D AC C4 50 2D 37 C3"
  },
  {
    "from": "56 BF E2 41 AA 55 0B 43 38 42 5B C3",
    "to": "56 BF E2 41 4B 95 B6 C4 38 42 5B C3"
  },
  {
    "from": "61 D0 A8 41 DD 67 49 43 A0 F5 CF C2",
    "to": "61 D0 A8 41 04 D3 AE C4 A0 F5 CF C2"
  },
  {
    "from": "75 58 4F 40 7F 90 39 43 57 7A B1 C2",
    "to": "75 58 4F 40 F0 CD B0 C4 57 7A B1 C2"
  },
  {
    "from": "E8 01 97 43 8C CB 93 42 A1 FD AD C2",
    "to": "E8 01 97 43 47 C3 BE C4 A1 FD AD C2"
  },
  {
    "from": "E7 D9 79 C1 17 7A 88 43 5F A3 63 C3",
    "to": "E7 D9 79 C1 7A E1 A5 C4 5F A3 63 C3"
  },
  {
    "from": "64 94 F4 40 0C EB 84 43 2F 80 7F C3",
    "to": "64 94 F4 40 3D C5 A6 C4 2F 80 7F C3"
  },
  {
    "from": "3C 1C CC 42 34 96 57 43 8A 29 A0 C2",
    "to": "3C 1C CC 42 3A 0D AD C4 8A 29 A0 C2"
  },
  {
    "from": "51 4D 4C C0 8F 27 6F 43 99 6D 3A C3",
    "to": "51 4D 4C C0 0E 1B AA C4 99 6D 3A C3"
  },
  {
    "from": "89 EC F4 C1 5A 5B 74 43 89 42 7D C3",
    "to": "89 EC F4 C1 95 74 A9 C4 89 42 7D C3"
  },
  {
    "from": "E9 3F 5D 41 AA 45 7E 43 D0 E1 70 C3",
    "to": "E9 3F 5D 41 4B 37 A8 C4 D0 E1 70 C3"
  },
  {
    "from": "E3 EB 51 42 CA FC 28 43 47 CC 17 C2",
    "to": "E3 EB 51 42 67 E0 B2 C4 47 CC 17 C2"
  },
  {
    "from": "7B 3B 81 40 82 48 39 43 03 2F AE C2",
    "to": "7B 3B 81 40 F0 D6 B0 C4 03 2F AE C2"
  },
  {
    "from": "3B 8B 7E 3E 2B 2D 67 43 AB 3B 0D C3",
    "to": "3B 8B 7E 3E 5A 1A AB C4 AB 3B 0D C3"
  },
  {
    "from": "AA 6E DD 40 51 94 3B 43 42 BE BF C2",
    "to": "AA 6E DD 40 76 8D B0 C4 42 BE BF C2"
  },
  {
    "from": "27 F5 93 41 14 EA 5B 43 68 7B D7 C2",
    "to": "27 F5 93 41 BE 82 AC C4 68 7B D7 C2"
  },
  {
    "from": "22 81 C1 41 4B 84 85 43 B2 BF 91 C3",
    "to": "22 81 C1 41 ED 9E A6 C4 B2 BF 91 C3"
  },
  {
    "from": "C4 47 0C C0 B0 98 0D 43 F1 CC 8D 42",
    "to": "C4 47 0C C0 EA 4C B6 C4 F1 CC 8D 42"
  },
  {
    "from": "82 61 94 40 71 66 76 43 5D 52 4C C3",
    "to": "82 61 94 40 32 33 A9 C4 5D 52 4C C3"
  },
  {
    "from": "C7 8A A7 C1 2E 8A 23 43 9A 7E 5F C2",
    "to": "C7 8A A7 C1 BA 8E B3 C4 9A 7E 5F C2"
  },
  {
    "from": "3F 0A 5D 42 FE A3 1B 43 DB 24 74 C2",
    "to": "3F 0A 5D 42 80 8B B4 C4 DB 24 74 C2"
  },
  {
    "from": "37 61 A6 C1 AE 8B 5E 43 4E 15 FD C2",
    "to": "37 61 A6 C1 8A 2E AC C4 4E 15 FD C2"
  },
  {
    "from": "47 49 76 42 B5 D2 84 43 1D AE 95 C3",
    "to": "47 49 76 42 53 CB A6 C4 1D AE 95 C3"
  },
  {
    "from": "53 3D 0A 40 7F A1 39 43 FD 64 B4 C2",
    "to": "53 3D 0A 40 D0 CB B0 C4 FD 64 B4 C2"
  },
  {
    "from": "60 B3 5A C1 02 1E 09 43 FC 6E B6 42",
    "to": "60 B3 5A C1 40 DC B6 C4 FC 6E B6 42"
  },
  {
    "from": "9F 6E CC C1 B9 48 1C 43 33 14 90 41",
    "to": "9F 6E CC C1 E9 76 B4 C4 33 14 90 41"
  },
  {
    "from": "B1 96 BC 40 9F EA 71 43 63 E6 40 C3",
    "to": "B1 96 BC 40 AC C2 A9 C4 63 E6 40 C3"
  },
  {
    "from": "F8 E4 44 C1 49 85 78 43 EC 99 5C C3",
    "to": "F8 E4 44 C1 57 EF A8 C4 EC 99 5C C3"
  },
  {
    "from": "02 C6 AB 42 93 56 5E 43 EA CC 2F C3",
    "to": "02 C6 AB 42 2E 35 AC C4 EA CC 2F C3"
  },
  {
    "from": "CC E4 25 C0 05 F9 10 43 07 BB 8B 42",
    "to": "CC E4 25 C0 E0 E0 B5 C4 07 BB 8B 42"
  },
  {
    "from": "D3 AE 68 41 50 C1 83 43 25 82 87 C3",
    "to": "D3 AE 68 41 AC 0F A7 C4 25 82 87 C3"
  },
  {
    "from": "AA 83 B8 42 02 17 57 43 09 99 BF C2",
    "to": "AA 83 B8 42 20 1D AD C4 09 99 BF C2"
  },
  {
    "from": "06 38 EA C2 1D EF 48 43 52 29 41 C3",
    "to": "06 38 EA C2 1C E2 AE C4 52 29 41 C3"
  },
  {
    "from": "C1 CD 2F 42 70 0A 10 43 6B 0A 31 C2",
    "to": "C1 CD 2F 42 B2 FE B5 C4 6B 0A 31 C2"
  },
  {
    "from": "D7 EA 51 42 C8 FC 28 43 6A CC 17 C2",
    "to": "D7 EA 51 42 67 E0 B2 C4 6A CC 17 C2"
  },
  {
    "from": "3C D5 CE C1 C9 A2 37 43 05 4E CA C2",
    "to": "3C D5 CE C1 A7 0B B1 C4 05 4E CA C2"
  },
  {
    "from": "72 3D 27 42 B6 10 25 43 09 CE 5D C2",
    "to": "72 3D 27 42 E9 5D B3 C4 09 CE 5D C2"
  },
  {
    "from": "C5 9B 95 40 F0 91 76 43 D2 80 4D C3",
    "to": "C5 9B 95 40 C2 2D A9 C4 D2 80 4D C3"
  },
  {
    "from": "29 E2 5D 42 C0 99 86 43 CF 47 A0 C3",
    "to": "29 E2 5D 42 90 59 A6 C4 CF 47 A0 C3"
  },
  {
    "from": "D0 39 66 C1 87 93 6C 43 A0 93 32 C3",
    "to": "D0 39 66 C1 8F 6D AA C4 A0 93 32 C3"
  },
  {
    "from": "54 7C A9 42 E8 48 4F 43 0F FA BA C2",
    "to": "54 7C A9 42 E3 16 AE C4 0F FA BA C2"
  },
  {
    "from": "15 11 0B C0 A2 BD 11 43 97 E2 65 42",
    "to": "15 11 0B C0 4C C8 B5 C4 97 E2 65 42"
  },
  {
    "from": "61 2C 6F 41 78 D0 42 43 6B 9F BB C2",
    "to": "61 2C 6F 41 F1 A5 AF C4 6B 9F BB C2"
  },
  {
    "from": "2D BF 78 41 DA FA 2E 43 25 99 21 C3",
    "to": "2D BF 78 41 A5 20 B2 C4 25 99 21 C3"
  },
  {
    "from": "EB A2 25 41 8F 06 53 43 EB AE ED C2",
    "to": "EB A2 25 41 2E 9F AD C4 EB AE ED C2"
  },
  {
    "from": "5D CD 89 C1 E7 CA 09 43 30 AF 81 42",
    "to": "5D CD 89 C1 A3 C6 B6 C4 30 AF 81 42"
  },
  {
    "from": "85 40 0E 40 7D FF 76 43 B0 F7 4D C3",
    "to": "85 40 0E 40 10 20 A9 C4 B0 F7 4D C3"
  },
  {
    "from": "B2 E4 62 42 9C B1 61 43 A1 4A 84 C3",
    "to": "B2 E4 62 42 CC C9 AB C4 A1 4A 84 C3"
  },
  {
    "from": "43 24 09 42 F7 14 86 43 45 A3 68 C3",
    "to": "43 24 09 42 C2 7A A6 C4 45 A3 68 C3"
  },
  {
    "from": "90 68 C7 40 F7 9C 84 43 AC DC 71 C3",
    "to": "90 68 C7 40 C2 D8 A6 C4 AC DC 71 C3"
  },
  {
    "from": "6E 9A A1 40 16 E7 76 43 65 BA 4D C3",
    "to": "6E 9A A1 40 1D 23 A9 C4 65 BA 4D C3"
  },
  {
    "from": "2A 06 20 41 C2 C3 81 43 1F FC 6B C3",
    "to": "2A 06 20 41 10 8F A7 C4 1F FC 6B C3"
  },
  {
    "from": "99 3F EE 40 58 90 78 43 77 97 4E C3",
    "to": "99 3F EE 40 F5 ED A8 C4 77 97 4E C3"
  },
  {
    "from": "01 82 49 C1 83 DE 15 43 79 35 21 42",
    "to": "01 82 49 C1 30 44 B5 C4 79 35 21 42"
  },
  {
    "from": "7C EF A7 40 71 F5 76 43 52 A0 4C C3",
    "to": "7C EF A7 40 52 21 A9 C4 52 A0 4C C3"
  },
  {
    "from": "73 8A A3 3F 96 84 80 43 F6 36 66 C3",
    "to": "73 8A A3 3F DA DE A7 C4 F6 36 66 C3"
  },
  {
    "from": "03 51 E8 40 93 92 49 43 06 BF 08 C3",
    "to": "03 51 E8 40 AE CD AE C4 06 BF 08 C3"
  },
  {
    "from": "1E B6 F7 40 4B C9 77 43 A1 75 4D C3",
    "to": "1E B6 F7 40 D6 06 A9 C4 A1 75 4D C3"
  },
  {
    "from": "2E 3E 07 C2 40 96 87 43 1A 59 81 C3",
    "to": "2E 3E 07 C2 70 1A A6 C4 1A 59 81 C3"
  },
  {
    "from": "63 1F 98 C0 A6 56 77 43 1B 8B 4D C3",
    "to": "63 1F 98 C0 2B 15 A9 C4 1B 8B 4D C3"
  },
  {
    "from": "ED 0A 3D 42 A8 48 85 43 6A 70 92 C3",
    "to": "ED 0A 3D 42 D6 AD A6 C4 6A 70 92 C3"
  },
  {
    "from": "E1 28 42 C1 3B 72 0E 43 41 74 56 42",
    "to": "E1 28 42 C1 B8 31 B6 C4 41 74 56 42"
  },
  {
    "from": "82 AF C8 41 32 23 5D 43 25 AC DD C2",
    "to": "82 AF C8 41 9A 5B AC C4 25 AC DD C2"
  },
  {
    "from": "C7 D5 A6 41 81 12 4B 43 94 AD D5 C2",
    "to": "C7 D5 A6 41 B0 9D AE C4 94 AD D5 C2"
  },
  {
    "from": "73 DC 87 C2 7A 62 5D 43 E3 60 80 C3",
    "to": "73 DC 87 C2 B1 53 AC C4 E3 60 80 C3"
  },
  {
    "from": "70 D2 81 40 AF 65 39 43 3E 32 AE C2",
    "to": "70 D2 81 40 4A D3 B0 C4 3E 32 AE C2"
  },
  {
    "from": "3D 12 59 C1 69 13 5E 43 C1 3C FF C2",
    "to": "3D 12 59 C1 93 3D AC C4 C1 3C FF C2"
  },
  {
    "from": "E3 B3 D7 41 74 4D 4D 43 C1 21 EB C2",
    "to": "E3 B3 D7 41 52 56 AE C4 C1 21 EB C2"
  },
  {
    "from": "A3 85 BD 41 36 51 3B 43 9B 99 B3 C2",
    "to": "A3 85 BD 41 D9 95 B0 C4 9B 99 B3 C2"
  },
  {
    "from": "6B 94 71 41 27 F2 42 43 92 D6 C1 C2",
    "to": "6B 94 71 41 BB A1 AF C4 92 D6 C1 C2"
  },
  {
    "from": "98 B5 89 41 5C 09 6A 43 7D 02 06 C3",
    "to": "98 B5 89 41 D4 BE AA C4 7D 02 06 C3"
  },
  {
    "from": "98 0F EF 41 71 B1 41 43 31 08 C7 C2",
    "to": "98 0F EF 41 D2 C9 AF C4 31 08 C7 C2"
  },
  {
    "from": "DF F6 FC C1 D5 93 35 43 BA D4 2E C2",
    "to": "DF F6 FC C1 86 4D B1 C4 BA D4 2E C2"
  },
  {
    "from": "0C 10 D3 C1 92 62 20 43 76 96 50 41",
    "to": "0C 10 D3 C1 AE F3 B3 C4 76 96 50 41"
  },
  {
    "from": "EB 33 88 41 75 E1 80 43 BD B0 6B C3",
    "to": "EB 33 88 41 A3 C7 A7 C4 BD B0 6B C3"
  },
  {
    "from": "AE 12 6D 41 53 8E 43 43 9E 78 C0 C2",
    "to": "AE 12 6D 41 36 8E AF C4 9E 78 C0 C2"
  },
  {
    "from": "B1 1F 52 C1 2F E9 0E 43 C5 A2 5A 42",
    "to": "B1 1F 52 C1 DA 22 B6 C4 C5 A2 5A 42"
  },
  {
    "from": "65 1A 71 3F FE B9 6F 43 B4 99 3C C3",
    "to": "65 1A 71 3F C0 08 AA C4 B4 99 3C C3"
  },
  {
    "from": "D0 EC BA 40 A2 DA 7F 43 EC 4F 66 C3",
    "to": "D0 EC BA 40 AC 04 A8 C4 EC 4F 66 C3"
  },
  {
    "from": "7C 52 F8 40 18 1A 7E 43 18 B9 64 C3",
    "to": "7C 52 F8 40 BD 3C A8 C4 18 B9 64 C3"
  },
  {
    "from": "E8 F9 84 C0 BF FE 32 43 53 41 C9 C2",
    "to": "E8 F9 84 C0 28 A0 B1 C4 53 41 C9 C2"
  },
  {
    "from": "82 A1 0C C2 62 B4 87 43 25 59 80 C3",
    "to": "82 A1 0C C2 E8 12 A6 C4 25 59 80 C3"
  },
  {
    "from": "19 AF 91 BF CE E8 34 43 C2 C0 B9 C2",
    "to": "19 AF 91 BF E6 62 B1 C4 C2 C0 B9 C2"
  },
  {
    "from": "58 C7 41 41 BD 7D 3B 43 41 EC AD C2",
    "to": "58 C7 41 41 48 90 B0 C4 41 EC AD C2"
  },
  {
    "from": "F2 D2 22 C2 94 08 26 43 E5 44 41 C0",
    "to": "F2 D2 22 C2 EE 3E B3 C4 E5 44 41 C0"
  },
  {
    "from": "EB 7E 55 C1 CF FB 1B 43 37 66 B1 41",
    "to": "EB 7E 55 C1 86 80 B4 C4 37 66 B1 41"
  },
  {
    "from": "59 EA B7 C0 DF 08 4F 43 91 01 04 C3",
    "to": "59 EA B7 C0 E4 1E AE C4 91 01 04 C3"
  },
  {
    "from": "B6 D8 D3 41 9E 3B 4D 43 F5 CB E6 C2",
    "to": "B6 D8 D3 41 8C 58 AE C4 F5 CB E6 C2"
  },
  {
    "from": "CA CB CD 41 68 85 4D 43 00 B3 F4 C2",
    "to": "CA CB CD 41 53 4F AE C4 00 B3 F4 C2"
  },
  {
    "from": "3E 48 30 41 B4 74 52 43 B7 8A E0 C2",
    "to": "3E 48 30 41 6A B1 AD C4 B7 8A E0 C2"
  },
  {
    "from": "67 85 93 41 B6 03 50 43 58 95 DA C2",
    "to": "67 85 93 41 89 FF AD C4 58 95 DA C2"
  },
  {
    "from": "A2 1E D5 41 BA 1C 51 43 BC C5 EA C2",
    "to": "A2 1E D5 41 69 DC AD C4 BC C5 EA C2"
  },
  {
    "from": "42 E4 03 41 C5 7B 7D 43 0B 52 6B C3",
    "to": "42 E4 03 41 88 50 A8 C4 0B 52 6B C3"
  },
  {
    "from": "4D 97 84 41 53 BA 5E 43 01 90 D7 C2",
    "to": "4D 97 84 41 B6 28 AC C4 01 90 D7 C2"
  },
  {
    "from": "EB FE C0 41 43 80 4D 43 2F AA F7 C2",
    "to": "EB FE C0 41 F8 4F AE C4 2F AA F7 C2"
  },
  {
    "from": "D6 40 4B 41 8B 37 4C 43 ED 1E E1 C2",
    "to": "D6 40 4B 41 0E 79 AE C4 ED 1E E1 C2"
  },
  {
    "from": "E6 4D 7A 42 58 71 87 43 9E B7 A4 C3",
    "to": "E6 4D 7A 42 AA 23 A6 C4 9E B7 A4 C3"
  },
  {
    "from": "B0 AC B4 3D F5 60 7F 43 45 D2 64 C3",
    "to": "B0 AC B4 3D E2 13 A8 C4 45 D2 64 C3"
  },
  {
    "from": "F9 F9 B8 41 A3 54 52 43 C5 6B DC C2",
    "to": "F9 F9 B8 41 6C B5 AD C4 C5 6B DC C2"
  },
  {
    "from": "7A 56 AD 41 79 53 49 43 AE 53 D6 C2",
    "to": "7A 56 AD 41 91 D5 AE C4 AE 53 D6 C2"
  },
  {
    "from": "6D 8E A2 41 0F 0E 55 43 AE 2F D9 C2",
    "to": "6D 8E A2 41 3E 5E AD C4 AE 2F D9 C2"
  },
  {
    "from": "B1 2E 4F 42 07 DA 3E 43 73 C0 DF C2",
    "to": "B1 2E 4F 42 BF 24 B0 C4 73 C0 DF C2"
  },
  {
    "from": "9C 6A 91 40 57 52 7A 43 3D AB 5E C3",
    "to": "9C 6A 91 40 B5 B5 A8 C4 3D AB 5E C3"
  },
  {
    "from": "BB 44 EF 3F 6A 55 79 43 B7 C6 4F C3",
    "to": "BB 44 EF 3F 53 D5 A8 C4 B7 C6 4F C3"
  },
  {
    "from": "8B C6 2D 41 36 AF 4B 43 85 AA E8 C2",
    "to": "8B C6 2D 41 19 8A AE C4 85 AA E8 C2"
  },
  {
    "from": "47 02 CE 41 57 4E 51 43 D3 3D E6 C2",
    "to": "47 02 CE 41 35 D6 AD C4 D3 3D E6 C2"
  },
  {
    "from": "51 BD 4F C1 8A E5 16 43 C9 95 24 42",
    "to": "51 BD 4F C1 4F 23 B5 C4 C9 95 24 42"
  },
  {
    "from": "2A FE 1E 41 EF EA 84 43 5A F6 80 C3",
    "to": "2A FE 1E 41 44 C5 A6 C4 5A F6 80 C3"
  },
  {
    "from": "61 A6 28 C0 0F 2B 6D 43 54 02 35 C3",
    "to": "61 A6 28 C0 9E 5A AA C4 54 02 35 C3"
  },
  {
    "from": "7D CB 46 40 3D 1F 4F 43 F4 D9 04 C3",
    "to": "7D CB 46 40 18 1C AE C4 F4 D9 04 C3"
  },
  {
    "from": "42 99 82 41 FC FD 3A 43 6D 5C A0 C2",
    "to": "42 99 82 41 40 A0 B0 C4 6D 5C A0 C2"
  },
  {
    "from": "EE F0 A3 41 AA AA 58 43 89 1C DD C2",
    "to": "EE F0 A3 41 AB EA AC C4 89 1C DD C2"
  },
  {
    "from": "3C ED B6 3E 00 9F 82 43 9B BB 6B C3",
    "to": "3C ED B6 3E 40 58 A7 C4 9B BB 6B C3"
  },
  {
    "from": "12 20 B6 C0 14 72 5E 43 51 20 05 C3",
    "to": "12 20 B6 C0 BE 31 AC C4 51 20 05 C3"
  },
  {
    "from": "57 B6 6B 41 66 29 50 43 B2 F8 DC C2",
    "to": "57 B6 6B 41 D3 FA AD C4 B2 F8 DC C2"
  },
  {
    "from": "77 14 C3 BF BB 46 35 43 89 FB B3 C2",
    "to": "77 14 C3 BF 28 57 B1 C4 89 FB B3 C2"
  },
  {
    "from": "E0 75 31 C1 11 8C 06 43 7B E1 8F 42",
    "to": "E0 75 31 C1 7E 2E B7 C4 7B E1 8F 42"
  },
  {
    "from": "F4 15 23 42 E6 A1 1D 43 C9 BB 3E C2",
    "to": "F4 15 23 42 C3 4B B4 C4 C9 BB 3E C2"
  },
  {
    "from": "F0 DB AE 40 97 C2 83 43 31 BD 7A C3",
    "to": "F0 DB AE 40 5A 0F A7 C4 31 BD 7A C3"
  },
  {
    "from": "D1 83 BD 41 36 51 3B 43 56 99 B3 C2",
    "to": "D1 83 BD 41 D9 95 B0 C4 56 99 B3 C2"
  },
  {
    "from": "23 26 4E C1 7A 90 10 43 5E 50 15 C2",
    "to": "23 26 4E C1 F1 ED B5 C4 5E 50 15 C2"
  },
  {
    "from": "2A 58 CA C0 A4 53 5B 43 F9 64 01 C3",
    "to": "2A 58 CA C0 8C 95 AC C4 F9 64 01 C3"
  },
  {
    "from": "7C 0D 0D BF F2 6E 7B 43 D6 42 5D C3",
    "to": "7C 0D 0D BF 22 92 A8 C4 D6 42 5D C3"
  },
  {
    "from": "B3 0E 09 C2 6C E9 88 43 1A A4 86 C3",
    "to": "B3 0E 09 C2 A5 C5 A5 C4 1A A4 86 C3"
  },
  {
    "from": "F7 34 B5 C1 A1 C2 6A 43 3B 77 42 C3",
    "to": "F7 34 B5 C1 AC A7 AA C4 3B 77 42 C3"
  },
  {
    "from": "0A CC 5E C1 60 06 0A 43 6F 82 96 42",
    "to": "0A CC 5E C1 34 BF B6 C4 6F 82 96 42"
  },
  {
    "from": "2A FF 4B C0 E4 84 2C 43 04 9E 86 C2",
    "to": "2A FF 4B C0 64 6F B2 C4 04 9E 86 C2"
  },
  {
    "from": "D0 D3 0A C1 2D 75 53 43 0A EA 03 C3",
    "to": "D0 D3 0A C1 5A 91 AD C4 0A EA 03 C3"
  },
  {
    "from": "10 82 37 41 58 59 51 43 54 DC F4 C2",
    "to": "10 82 37 41 D5 D4 AD C4 54 DC F4 C2"
  },
  {
    "from": "98 92 97 41 C0 30 59 43 01 31 DD C2",
    "to": "98 92 97 41 E8 D9 AC C4 01 31 DD C2"
  },
  {
    "from": "E5 83 3B 41 6B AF 51 43 DD A4 EC C2",
    "to": "E5 83 3B 41 12 CA AD C4 DD A4 EC C2"
  },
  {
    "from": "3A D9 4C 42 BC 4A 85 43 22 16 94 C3",
    "to": "3A D9 4C 42 51 AD A6 C4 22 16 94 C3"
  },
  {
    "from": "1B 45 A0 41 A7 A8 33 43 14 55 94 C2",
    "to": "1B 45 A0 41 EB 8A B1 C4 14 55 94 C2"
  },
  {
    "from": "93 D6 DA 40 57 52 7A 43 4C FC 5B C3",
    "to": "93 D6 DA 40 B5 B5 A8 C4 4C FC 5B C3"
  },
  {
    "from": "58 65 CF 3F 18 01 6D 43 DE 5A 1A C3",
    "to": "58 65 CF 3F DD 5F AA C4 DE 5A 1A C3"
  },
  {
    "from": "17 B1 BD 41 0F FF 64 43 1F BC F4 C2",
    "to": "17 B1 BD 41 1E 60 AB C4 1F BC F4 C2"
  },
  {
    "from": "AD 7F F9 41 A2 F9 24 43 15 F7 C3 C2",
    "to": "AD 7F F9 41 CC 60 B3 C4 15 F7 C3 C2"
  },
  {
    "from": "57 97 7B C1 53 37 13 43 A1 3F 5F 42",
    "to": "57 97 7B C1 16 99 B5 C4 A1 3F 5F 42"
  },
  {
    "from": "CB 24 1F C2 18 A4 26 43 ED D4 82 3F",
    "to": "CB 24 1F C2 7D 2B B3 C4 ED D4 82 3F"
  },
  {
    "from": "45 D0 2C 41 F5 4A 85 43 1E 8F 88 C3",
    "to": "45 D0 2C 41 43 AD A6 C4 1E 8F 88 C3"
  },
  {
    "from": "1C ED 3D C0 72 A8 71 43 66 5D 40 C3",
    "to": "1C ED 3D C0 F2 CA A9 C4 66 5D 40 C3"
  },
  {
    "from": "09 92 9D 41 A2 E3 42 43 D1 B1 C0 C2",
    "to": "09 92 9D 41 8C A3 AF C4 D1 B1 C0 C2"
  },
  {
    "from": "6E 51 98 41 88 F6 F7 42 A5 12 40 42",
    "to": "6E 51 98 41 98 80 B8 C4 A5 12 40 42"
  },
  {
    "from": "60 B8 34 C1 8F D5 14 43 36 5D 31 42",
    "to": "60 B8 34 C1 4E 65 B5 C4 36 5D 31 42"
  },
  {
    "from": "0D A6 82 40 1B D3 32 43 45 D6 D6 C2",
    "to": "0D A6 82 40 9C A5 B1 C4 45 D6 D6 C2"
  },
  {
    "from": "63 D3 5C 40 91 19 3A 43 C1 C0 B1 C2",
    "to": "63 D3 5C 40 CE BC B0 C4 C1 C0 B1 C2"
  },
  {
    "from": "D0 CB 60 C0 CB 4E 09 43 58 26 8B 42",
    "to": "D0 CB 60 C0 26 D6 B6 C4 58 26 8B 42"
  },
  {
    "from": "24 D4 12 C1 3E 99 68 43 71 DD 1A C3",
    "to": "24 D4 12 C1 D8 EC AA C4 71 DD 1A C3"
  },
  {
    "from": "26 C8 48 C0 08 CB 6B 43 29 86 17 C3",
    "to": "26 C8 48 C0 9F 86 AA C4 29 86 17 C3"
  },
  {
    "from": "3F ED 55 C1 10 8C 17 43 6B 33 17 42",
    "to": "3F ED 55 C1 7E 0E B5 C4 6B 33 17 42"
  },
  {
    "from": "88 64 E6 C0 53 F8 36 43 BE 82 0F C3",
    "to": "88 64 E6 C0 F6 20 B1 C4 BE 82 0F C3"
  },
  {
    "from": "DF 47 BA 41 BE E9 4C 43 08 EF D4 C2",
    "to": "DF 47 BA 41 C8 62 AE C4 08 EF D4 C2"
  },
  {
    "from": "6D FA 95 41 F2 9C 59 43 D7 7C DC C2",
    "to": "6D FA 95 41 62 CC AC C4 D7 7C DC C2"
  },
  {
    "from": "6C EB B9 3F 29 BC 51 43 FB AB 03 C3",
    "to": "6C EB B9 3F 7B C8 AD C4 FB AB 03 C3"
  },
  {
    "from": "31 23 20 42 A8 BF B2 42 5D 29 DD 41",
    "to": "31 23 20 42 06 D4 BC C4 5D 29 DD 41"
  },
  {
    "from": "7A A3 9F C1 6C E9 88 43 D3 AC 7D C3",
    "to": "7A A3 9F C1 A5 C5 A5 C4 D3 AC 7D C3"
  },
  {
    "from": "E3 FC A0 40 A4 02 3C 43 AE DA B7 C2",
    "to": "E3 FC A0 40 AC 7F B0 C4 AE DA B7 C2"
  },
  {
    "from": "BB 2F 50 42 B5 81 84 43 C1 42 95 C3",
    "to": "BB 2F 50 42 93 DF A6 C4 C1 42 95 C3"
  },
  {
    "from": "AA 61 92 40 AC CF 50 43 2F 2D 05 C3",
    "to": "AA 61 92 40 0A E6 AD C4 2F 2D 05 C3"
  },
  {
    "from": "E4 0F 62 C1 C0 8F 2D 43 4B 2A 64 C2",
    "to": "E4 0F 62 C1 08 4E B2 C4 4B 2A 64 C2"
  },
  {
    "from": "38 8E 01 41 0B 37 70 43 F2 75 3C C3",
    "to": "38 8E 01 41 1E F9 A9 C4 F2 75 3C C3"
  },
  {
    "from": "0B CF 6D 42 A1 CF 85 43 02 56 9C C3",
    "to": "0B CF 6D 42 18 8C A6 C4 02 56 9C C3"
  },
  {
    "from": "23 10 C5 41 98 C6 29 43 8F 4D B1 C2",
    "to": "23 10 C5 41 2D C7 B2 C4 8F 4D B1 C2"
  },
  {
    "from": "99 22 FF 41 38 7C 85 43 F8 7D 92 C3",
    "to": "99 22 FF 41 F2 A0 A6 C4 F8 7D 92 C3"
  },
  {
    "from": "7E FC 2A C2 00 D8 28 43 33 4F 75 C0",
    "to": "7E FC 2A C2 00 E5 B2 C4 33 4F 75 C0"
  },
  {
    "from": "7E 73 A7 C1 7C 4B 5E 43 B3 F0 FC C2",
    "to": "7E 73 A7 C1 90 36 AC C4 B3 F0 FC C2"
  },
  {
    "from": "65 2B 73 42 A9 2C 85 43 75 E0 95 C3",
    "to": "65 2B 73 42 D6 B4 A6 C4 75 E0 95 C3"
  },
  {
    "from": "16 B5 9D C0 B1 6E 4F 43 20 F1 02 C3",
    "to": "16 B5 9D C0 2A 12 AE C4 20 F1 02 C3"
  },
  {
    "from": "CF 1B 24 42 AA 52 BA 42 B4 7C D8 42",
    "to": "CF 1B 24 42 D6 5A BC C4 B4 7C D8 42"
  },
  {
    "from": "CD 6D 82 C1 D4 CD 07 43 FE 05 A2 42",
    "to": "CD 6D 82 C1 46 06 B7 C4 FE 05 A2 42"
  },
  {
    "from": "20 8A 0A 42 7A 24 85 43 44 C5 8E C3",
    "to": "20 8A 0A 42 E2 B6 A6 C4 44 C5 8E C3"
  },
  {
    "from": "49 7D B8 41 83 28 4C 43 A8 8A D5 C2",
    "to": "49 7D B8 41 F0 7A AE C4 A8 8A D5 C2"
  },
  {
    "from": "C1 1B 99 40 23 88 3D 43 1C 16 B9 C2",
    "to": "C1 1B 99 40 FC 4E B0 C4 1C 16 B9 C2"
  },
  {
    "from": "F8 EC FE 40 39 ED 84 43 0F F1 7A C3",
    "to": "F8 EC FE 40 B2 C4 A6 C4 0F F1 7A C3"
  },
  {
    "from": "FA 56 78 C1 74 D2 12 43 1F AF 8F 42",
    "to": "FA 56 78 C1 B2 A5 B5 C4 1F AF 8F 42"
  },
  {
    "from": "42 33 57 41 B1 A4 4C 43 5A 67 02 C3",
    "to": "42 33 57 41 6A 6B AE C4 5A 67 02 C3"
  },
  {
    "from": "31 36 A2 40 CB B1 76 43 59 9A 4C C3",
    "to": "31 36 A2 40 C6 29 A9 C4 59 9A 4C C3"
  },
  {
    "from": "3F C3 97 40 A2 02 85 43 85 90 72 C3",
    "to": "3F C3 97 40 58 BF A6 C4 85 90 72 C3"
  },
  {
    "from": "1C C7 2C 42 5B 8A 1D 43 CA EA 7B C2",
    "to": "1C C7 2C 42 B4 4E B4 C4 CA EA 7B C2"
  },
  {
    "from": "D0 72 46 41 8B C9 83 43 7E 8C 82 C3",
    "to": "D0 72 46 41 9D 0D A7 C4 7E 8C 82 C3"
  },
  {
    "from": "FC E2 64 40 A8 D3 84 43 9B 1D 78 C3",
    "to": "FC E2 64 40 16 CB A6 C4 9B 1D 78 C3"
  },
  {
    "from": "EC 30 82 C1 6C DD 1B 43 02 6E 8F 41",
    "to": "EC 30 82 C1 52 84 B4 C4 02 6E 8F 41"
  },
  {
    "from": "69 B7 99 41 49 E8 68 43 1B 95 02 C3",
    "to": "69 B7 99 41 F7 E2 AA C4 1B 95 02 C3"
  },
  {
    "from": "20 6F 15 C2 23 A6 30 43 06 A3 1D C2",
    "to": "20 6F 15 C2 3C EB B1 C4 06 A3 1D C2"
  },
  {
    "from": "E0 66 C2 41 50 9F 63 43 DF A8 F2 C2",
    "to": "E0 66 C2 41 16 8C AB C4 DF A8 F2 C2"
  },
  {
    "from": "9A 4D B1 40 70 02 34 43 89 37 BB C2",
    "to": "9A 4D B1 40 B2 7F B1 C4 89 37 BB C2"
  },
  {
    "from": "1A BC 75 C1 0A 45 09 43 21 34 69 42",
    "to": "1A BC 75 C1 5F D7 B6 C4 21 34 69 42"
  },
  {
    "from": "36 4E 0F C1 66 0E 71 43 DC E8 3B C3",
    "to": "36 4E 0F C1 33 DE A9 C4 DC E8 3B C3"
  },
  {
    "from": "59 EA 10 C2 12 35 22 43 A4 37 73 40",
    "to": "59 EA 10 C2 5E B9 B3 C4 A4 37 73 40"
  },
  {
    "from": "A7 12 62 42 59 96 87 43 CE 0F A4 C3",
    "to": "A7 12 62 42 6A 1A A6 C4 CE 0F A4 C3"
  },
  {
    "from": "F7 92 7D C1 17 7A 88 43 A0 BC 63 C3",
    "to": "F7 92 7D C1 7A E1 A5 C4 A0 BC 63 C3"
  },
  {
    "from": "2A 03 55 42 3D 10 0C 43 9C BA 0C C2",
    "to": "2A 03 55 42 F8 7D B6 C4 9C BA 0C C2"
  },
  {
    "from": "F0 FE 9B 41 8A A6 58 43 EE 0C DE C2",
    "to": "F0 FE 9B 41 2F EB AC C4 EE 0C DE C2"
  },
  {
    "from": "B9 17 C9 40 CA BA 3B 43 62 AD C1 C2",
    "to": "B9 17 C9 40 A7 88 B0 C4 62 AD C1 C2"
  },
  {
    "from": "70 09 C8 BF A5 8D 6B 43 6C 18 11 C3",
    "to": "70 09 C8 BF 4C 8E AA C4 6C 18 11 C3"
  },
  {
    "from": "88 2C 59 42 33 68 30 43 25 8D 55 C2",
    "to": "88 2C 59 42 FA F2 B1 C4 25 8D 55 C2"
  },
  {
    "from": "FC 65 44 41 16 48 85 43 08 45 83 C3",
    "to": "FC 65 44 41 FA AD A6 C4 08 45 83 C3"
  },
  {
    "from": "90 75 8C 40 E7 13 3B 43 26 F4 B2 C2",
    "to": "90 75 8C 40 83 9D B0 C4 26 F4 B2 C2"
  },
  {
    "from": "9F 71 B9 42 4E 0C 03 43 3A 3C 05 41",
    "to": "9F 71 B9 42 76 9E B7 C4 3A 3C 05 41"
  },
  {
    "from": "2A 7A 1B C1 50 3B 15 43 34 B1 62 42",
    "to": "2A 7A 1B C1 96 58 B5 C4 34 B1 62 42"
  },
  {
    "from": "33 BB 20 C1 CF 1A 0E 43 31 20 97 42",
    "to": "33 BB 20 C1 A6 3C B6 C4 31 20 97 42"
  },
  {
    "from": "CA 09 41 41 EB 12 3F 43 44 08 C3 C2",
    "to": "CA 09 41 41 A2 1D B0 C4 44 08 C3 C2"
  },
  {
    "from": "9B DB 86 C1 DE CF 07 43 0F D8 63 42",
    "to": "9B DB 86 C1 04 06 B7 C4 0F D8 63 42"
  },
  {
    "from": "D9 23 19 41 74 AC 80 43 08 1B 69 C3",
    "to": "D9 23 19 41 E3 D4 A7 C4 08 1B 69 C3"
  },
  {
    "from": "0D FD 81 BF 5A 2B 83 43 68 40 70 C3",
    "to": "0D FD 81 BF 2A 35 A7 C4 68 40 70 C3"
  },
  {
    "from": "56 2D 8F C0 EC 74 1A 43 A0 E1 7C 41",
    "to": "56 2D 8F C0 62 B1 B4 C4 A0 E1 7C 41"
  },
  {
    "from": "9F D7 8B C1 C1 B8 11 43 05 85 97 42",
    "to": "9F D7 8B C1 E8 C8 B5 C4 05 85 97 42"
  },
  {
    "from": "FB 66 D7 40 DE AC 82 43 F9 3C 6F C3",
    "to": "FB 66 D7 40 C8 54 A7 C4 F9 3C 6F C3"
  },
  {
    "from": "13 D0 4D C2 01 16 1B 43 FD 74 A1 41",
    "to": "13 D0 4D C2 40 9D B4 C4 FD 74 A1 41"
  },
  {
    "from": "8A 0E E4 40 C9 56 7A 43 F5 9D 5B C3",
    "to": "8A 0E E4 40 27 B5 A8 C4 F5 9D 5B C3"
  },
  {
    "from": "7D 7E C8 C1 45 69 32 43 44 39 D8 C2",
    "to": "7D 7E C8 C1 D8 B2 B1 C4 44 39 D8 C2"
  },
  {
    "from": "E6 12 DD 42 CC D1 47 43 AE 38 43 C3",
    "to": "E6 12 DD 42 C6 05 AF C4 AE 38 43 C3"
  },
  {
    "from": "26 C8 2C 42 5E 8A 1D 43 99 EA 7B C2",
    "to": "26 C8 2C 42 B4 4E B4 C4 99 EA 7B C2"
  },
  {
    "from": "75 38 2A 42 40 6A DD 42 92 C6 2C C2",
    "to": "75 38 2A 42 5C 29 BA C4 92 C6 2C C2"
  },
  {
    "from": "FE 19 C6 40 22 94 4B 43 40 F4 05 C3",
    "to": "FE 19 C6 40 7C 8D AE C4 40 F4 05 C3"
  },
  {
    "from": "76 8D B1 C1 74 AC 2B 43 F7 84 6A C2",
    "to": "76 8D B1 C1 72 8A B2 C4 F7 84 6A C2"
  },
  {
    "from": "0C 66 22 C1 8C 0B 4E 43 50 C7 00 C3",
    "to": "0C 66 22 C1 8E 3E AE C4 50 C7 00 C3"
  },
  {
    "from": "01 0C 7F 41 E9 43 87 43 1E 51 7A C3",
    "to": "01 0C 7F 41 06 2F A6 C4 1E 51 7A C3"
  },
  {
    "from": "E1 5F 2D 40 C0 2C 7A 43 5F DA 56 C3",
    "to": "E1 5F 2D 40 68 BA A8 C4 5F DA 56 C3"
  },
  {
    "from": "CA E0 BA 3F 6F 0B 82 43 7A E2 6B C3",
    "to": "CA E0 BA 3F 24 7D A7 C4 7A E2 6B C3"
  },
  {
    "from": "FB 84 2C 41 4F 6D 51 43 BE 50 EA C2",
    "to": "FB 84 2C 41 56 D2 AD C4 BE 50 EA C2"
  },
  {
    "from": "BD C7 FB 42 BC 02 09 43 C0 D0 4B C3",
    "to": "BD C7 FB 42 A8 DF B6 C4 C0 D0 4B C3"
  },
  {
    "from": "5F 93 91 41 59 79 46 43 85 74 C3 C2",
    "to": "5F 93 91 41 D5 30 AF C4 85 74 C3 C2"
  },
  {
    "from": "4B DC 5F 41 75 1D 85 43 F5 3D 7F C3",
    "to": "4B DC 5F 41 A3 B8 A6 C4 F5 3D 7F C3"
  },
  {
    "from": "92 AC B4 41 5A C9 5B 43 7E 30 DA C2",
    "to": "92 AC B4 41 D5 86 AC C4 7E 30 DA C2"
  },
  {
    "from": "F2 8C 6F 42 61 B1 88 43 7E FD A8 C3",
    "to": "F2 8C 6F 42 A8 D3 A5 C4 7E FD A8 C3"
  },
  {
    "from": "83 75 00 C1 9F 4A 71 43 36 D2 3C C3",
    "to": "83 75 00 C1 AC D6 A9 C4 36 D2 3C C3"
  },
  {
    "from": "25 6D C5 41 9E 31 62 43 22 8F F0 C2",
    "to": "25 6D C5 41 CC B9 AB C4 22 8F F0 C2"
  },
  {
    "from": "84 A7 43 C1 17 DD 09 43 A1 D2 71 42",
    "to": "84 A7 43 C1 5D C4 B6 C4 A1 D2 71 42"
  },
  {
    "from": "B9 4C A5 41 AB 40 68 43 A2 99 FF C2",
    "to": "B9 4C A5 41 EA F7 AA C4 A2 99 FF C2"
  },
  {
    "from": "9B 49 80 40 D0 17 C8 42 6B 88 1A C2",
    "to": "9B 49 80 40 83 7E BB C4 6B 88 1A C2"
  },
  {
    "from": "F7 3B BF 41 18 C5 4C 43 83 83 D0 C2",
    "to": "F7 3B BF 41 5D 67 AE C4 83 83 D0 C2"
  },
  {
    "from": "DE 93 B1 42 42 D9 56 43 92 C9 D7 C2",
    "to": "DE 93 B1 42 D8 24 AD C4 92 C9 D7 C2"
  },
  {
    "from": "C1 8F FB C1 50 29 49 43 60 2B 0F C3",
    "to": "C1 8F FB C1 D6 DA AE C4 60 2B 0F C3"
  },
  {
    "from": "14 6E 3D 42 56 EF 84 43 20 22 8F C3",
    "to": "14 6E 3D 42 2A C4 A6 C4 20 22 8F C3"
  },
  {
    "from": "40 6C E2 40 DD 45 82 43 63 25 6C C3",
    "to": "40 6C E2 40 89 6E A7 C4 63 25 6C C3"
  },
  {
    "from": "B5 DF 9A 3E 22 94 4B 43 60 EC 03 C3",
    "to": "B5 DF 9A 3E 7C 8D AE C4 60 EC 03 C3"
  },
  {
    "from": "7E 13 CC 41 4A 41 51 43 8C 04 EE C2",
    "to": "7E 13 CC 41 D7 D7 AD C4 8C 04 EE C2"
  },
  {
    "from": "56 91 FD 40 70 87 6F 43 E6 D6 3A C3",
    "to": "56 91 FD 40 12 0F AA C4 E6 D6 3A C3"
  },
  {
    "from": "9D E5 86 41 D3 58 62 43 38 2E 12 C3",
    "to": "9D E5 86 41 E6 B4 AB C4 38 2E 12 C3"
  },
  {
    "from": "23 AC 5C 42 7A EC 28 43 87 E6 73 C2",
    "to": "23 AC 5C 42 71 E2 B2 C4 87 E6 73 C2"
  },
  {
    "from": "AD 60 EE C1 E6 89 24 43 75 02 BD C0",
    "to": "AD 60 EE C1 C3 6E B3 C4 75 02 BD C0"
  },
  {
    "from": "DA 08 41 41 EB 12 3F 43 80 08 C3 C2",
    "to": "DA 08 41 41 A2 1D B0 C4 80 08 C3 C2"
  },
  {
    "from": "AC FD 41 41 80 6D 6C 43 58 AC 09 C3",
    "to": "AC FD 41 41 50 72 AA C4 58 AC 09 C3"
  },
  {
    "from": "FE A3 8C 41 71 D0 58 43 49 B5 DC C2",
    "to": "FE A3 8C 41 F2 E5 AC C4 49 B5 DC C2"
  },
  {
    "from": "0B BB 5A C1 EC 4B 5E 43 09 61 FF C2",
    "to": "0B BB 5A C1 82 36 AC C4 09 61 FF C2"
  },
  {
    "from": "AD 18 AC BF 41 0E 80 43 42 F4 65 C3",
    "to": "AD 18 AC BF 70 FC A7 C4 42 F4 65 C3"
  },
  {
    "from": "C2 F9 9E 41 BE FA 58 43 2C FB DC C2",
    "to": "C2 F9 9E 41 A8 E0 AC C4 2C FB DC C2"
  },
  {
    "from": "1C D9 9E C1 EA BD 10 43 3F 20 75 42",
    "to": "1C D9 9E C1 43 E8 B5 C4 3F 20 75 42"
  },
  {
    "from": "24 9B 12 C1 C5 FA 70 43 8C B8 3D C3",
    "to": "24 9B 12 C1 A8 E0 A9 C4 8C B8 3D C3"
  },
  {
    "from": "43 97 54 42 B0 31 11 43 12 EB 0F C2",
    "to": "43 97 54 42 CA D9 B5 C4 12 EB 0F C2"
  },
  {
    "from": "2F 79 99 C1 06 AA 2F 43 C8 44 90 C2",
    "to": "2F 79 99 C1 BF 0A B2 C4 C8 44 90 C2"
  },
  {
    "from": "39 C2 13 42 A8 48 85 43 9C 50 90 C3",
    "to": "39 C2 13 42 D6 AD A6 C4 9C 50 90 C3"
  },
  {
    "from": "A5 11 55 42 33 68 30 43 41 0D 37 C2",
    "to": "A5 11 55 42 FA F2 B1 C4 41 0D 37 C2"
  },
  {
    "from": "22 56 AE 42 3D 8D 56 43 F2 FE 03 C3",
    "to": "22 56 AE 42 58 2E AD C4 F2 FE 03 C3"
  },
  {
    "from": "A7 BE BB 40 7F 69 3C 43 86 21 B5 C2",
    "to": "A7 BE BB 40 D0 72 B0 C4 86 21 B5 C2"
  },
  {
    "from": "21 A0 A2 41 A7 C4 58 43 84 90 DE C2",
    "to": "21 A0 A2 41 6B E7 AC C4 84 90 DE C2"
  },
  {
    "from": "6B B2 1F C1 71 C6 19 43 7F 12 06 42",
    "to": "6B B2 1F C1 32 C7 B4 C4 7F 12 06 42"
  },
  {
    "from": "25 53 6E 42 A8 C1 84 43 39 98 9F C3",
    "to": "25 53 6E 42 96 CF A6 C4 39 98 9F C3"
  },
  {
    "from": "6B BA 95 41 8E 68 5A 43 57 5E DC C2",
    "to": "6B BA 95 41 EE B2 AC C4 57 5E DC C2"
  },
  {
    "from": "B6 16 FB C0 55 34 09 43 7A 1C 94 42",
    "to": "B6 16 FB C0 76 D9 B6 C4 7A 1C 94 42"
  },
  {
    "from": "52 F5 2D 42 7F FA 18 43 E6 04 34 C2",
    "to": "52 F5 2D 42 B0 E0 B4 C4 E6 04 34 C2"
  },
  {
    "from": "70 8D 36 41 78 F5 84 43 56 01 8C C3",
    "to": "70 8D 36 41 A2 C2 A6 C4 56 01 8C C3"
  },
  {
    "from": "DA 66 78 C1 15 9C 05 43 D7 1F B5 42",
    "to": "DA 66 78 C1 7E 4C B7 C4 D7 1F B5 42"
  },
  {
    "from": "54 2C B7 41 60 3F 49 43 5F 08 DE C2",
    "to": "54 2C B7 41 14 D8 AE C4 5F 08 DE C2"
  },
  {
    "from": "DE 93 B1 42 42 D9 56 43 92 C9 D7 C2",
    "to": "DE 93 B1 42 D8 24 AD C4 92 C9 D7 C2"
  },
  {
    "from": "F3 51 52 41 16 3F 52 43 6D 56 ED C2",
    "to": "F3 51 52 41 1D B8 AD C4 6D 56 ED C2"
  },
  {
    "from": "24 37 72 41 70 00 84 43 18 00 75 C3",
    "to": "24 37 72 41 E4 FF A6 C4 18 00 75 C3"
  },
  {
    "from": "FA F6 8F C0 3F 22 13 43 F0 B3 6D 42",
    "to": "FA F6 8F C0 B8 9B B5 C4 F0 B3 6D 42"
  },
  {
    "from": "DD E8 7C 42 7A 07 40 43 5F 2B 70 C3",
    "to": "DD E8 7C 42 11 FF AF C4 5F 2B 70 C3"
  },
  {
    "from": "4C CC 68 C0 54 B7 14 43 E0 40 70 42",
    "to": "4C CC 68 C0 16 69 B5 C4 E0 40 70 42"
  },
  {
    "from": "85 1D 88 C1 F4 52 6C 43 39 68 32 C3",
    "to": "85 1D 88 C1 A2 75 AA C4 39 68 32 C3"
  },
  {
    "from": "14 1F BD C0 CE B2 0F 43 2E 53 58 42",
    "to": "14 1F BD C0 A6 09 B6 C4 2E 53 58 42"
  },
  {
    "from": "5D EE 40 41 68 69 5A 43 39 4A 0F C3",
    "to": "5D EE 40 41 D3 B2 AC C4 39 4A 0F C3"
  },
  {
    "from": "8A 6F 67 41 D3 62 4C 43 2E 9C ED C2",
    "to": "8A 6F 67 41 A6 73 AE C4 2E 9C ED C2"
  },
  {
    "from": "79 E4 35 41 36 AF 4B 43 28 19 E5 C2",
    "to": "79 E4 35 41 19 8A AE C4 28 19 E5 C2"
  },
  {
    "from": "9F ED FA C1 15 87 23 43 F6 43 21 41",
    "to": "9F ED FA C1 1E 8F B3 C4 F6 43 21 41"
  },
  {
    "from": "EB 9D 2F 41 DB 3F 85 43 05 67 80 C3",
    "to": "EB 9D 2F 41 09 B0 A6 C4 05 67 80 C3"
  },
  {
    "from": "4A 56 60 C1 73 B0 08 43 91 7A A2 42",
    "to": "4A 56 60 C1 F2 E9 B6 C4 91 7A A2 42"
  },
  {
    "from": "08 E5 64 C1 2F DA 16 43 8C E2 65 42",
    "to": "08 E5 64 C1 BA 24 B5 C4 8C E2 65 42"
  },
  {
    "from": "2E DA 1F 41 A8 48 85 43 C2 BC 86 C3",
    "to": "2E DA 1F 41 D6 AD A6 C4 C2 BC 86 C3"
  },
  {
    "from": "89 C5 91 C1 5A AF 08 43 CF 52 91 42",
    "to": "89 C5 91 C1 15 EA B6 C4 CF 52 91 42"
  },
  {
    "from": "7C B8 1A C0 71 E3 39 43 ED D4 05 C3",
    "to": "7C B8 1A C0 92 C3 B0 C4 ED D4 05 C3"
  },
  {
    "from": "65 03 A0 41 16 90 33 43 8A 48 94 C2",
    "to": "65 03 A0 41 FD 8D B1 C4 8A 48 94 C2"
  },
  {
    "from": "9F E7 EE 41 64 B1 41 43 3E 02 C7 C2",
    "to": "9F E7 EE 41 D4 C9 AF C4 3E 02 C7 C2"
  },
  {
    "from": "3F 8B 84 C1 8C FC 5A 43 B3 20 0D C3",
    "to": "3F 8B 84 C1 6E A0 AC C4 B3 20 0D C3"
  },
  {
    "from": "56 52 F3 40 4B F4 21 43 5F A6 E7 C2",
    "to": "56 52 F3 40 76 C1 B3 C4 5F A6 E7 C2"
  },
  {
    "from": "4D FA 41 C1 63 F6 13 43 80 B9 33 42",
    "to": "4D FA 41 C1 34 81 B5 C4 80 B9 33 42"
  },
  {
    "from": "DF AB 5C 42 6D DD 28 43 54 E6 73 C2",
    "to": "DF AB 5C 42 52 E4 B2 C4 54 E6 73 C2"
  },
  {
    "from": "64 AF 68 41 C2 36 8B 43 58 27 96 C3",
    "to": "64 AF 68 41 50 32 A5 C4 58 27 96 C3"
  },
  {
    "from": "3A EA A6 3F E6 6B 6D 43 9E 7E 35 C3",
    "to": "3A EA A6 3F 83 52 AA C4 9E 7E 35 C3"
  },
  {
    "from": "DD 1E A6 C1 EC 4B 5E 43 E8 F0 FC C2",
    "to": "DD 1E A6 C1 82 36 AC C4 E8 F0 FC C2"
  },
  {
    "from": "3F A0 6C 42 AF 38 76 43 63 1D 5C C3",
    "to": "3F A0 6C 42 EA 38 A9 C4 63 1D 5C C3"
  },
  {
    "from": "FB 1A AE 42 2F 8B 56 43 15 66 04 C3",
    "to": "FB 1A AE 42 9A 2E AD C4 15 66 04 C3"
  },
  {
    "from": "B1 EB 8C 42 02 44 5D 43 B4 98 65 C3",
    "to": "B1 EB 8C 42 80 57 AC C4 B4 98 65 C3"
  },
  {
    "from": "84 F1 1D C1 29 41 1C 43 FD C0 48 41",
    "to": "84 F1 1D C1 DB 77 B4 C4 FD C0 48 41"
  },
  {
    "from": "16 C2 07 C1 D5 B1 4E 43 62 90 01 C3",
    "to": "16 C2 07 C1 C6 29 AE C4 62 90 01 C3"
  },
  {
    "from": "34 D9 D5 C0 47 06 0D 43 8B 1F 67 42",
    "to": "34 D9 D5 C0 37 5F B6 C4 8B 1F 67 42"
  },
  {
    "from": "EB AC 5C 42 6E DD 28 43 31 E6 73 C2",
    "to": "EB AC 5C 42 52 E4 B2 C4 31 E6 73 C2"
  },
  {
    "from": "D3 ED 5C 42 F8 7C 83 43 8D 45 6A C3",
    "to": "D3 ED 5C 42 C2 20 A7 C4 8D 45 6A C3"
  },
  {
    "from": "92 7A C7 C0 BA 53 6D 43 01 FF 26 C3",
    "to": "92 7A C7 C0 89 55 AA C4 01 FF 26 C3"
  },
  {
    "from": "0A 70 2C C1 C2 E4 6C 43 02 27 2F C3",
    "to": "0A 70 2C C1 68 63 AA C4 02 27 2F C3"
  },
  {
    "from": "64 99 FB 3F 62 7C 79 43 6B 36 65 C3",
    "to": "64 99 FB 3F 74 D0 A8 C4 6B 36 65 C3"
  },
  {
    "from": "FD C7 A4 C0 26 72 72 43 DA 88 40 C3",
    "to": "FD C7 A4 C0 BB B1 A9 C4 DA 88 40 C3"
  },
  {
    "from": "E1 28 42 C1 59 54 0F 43 EF 51 51 42",
    "to": "E1 28 42 C1 75 15 B6 C4 EF 51 51 42"
  },
  {
    "from": "1D 79 61 41 0D E5 6A 43 E8 45 0A C3",
    "to": "1D 79 61 41 5E A3 AA C4 E8 45 0A C3"
  },
  {
    "from": "C9 B0 6E BF 4E 57 52 43 DD 05 06 C3",
    "to": "C9 B0 6E BF 16 B5 AD C4 DD 05 06 C3"
  },
  {
    "from": "DA 89 78 C0 46 2B 0A 43 97 64 78 42",
    "to": "DA 89 78 C0 97 BA B6 C4 97 64 78 42"
  },
  {
    "from": "97 D9 C7 C1 92 7D 2D 43 0D 7F C5 C2",
    "to": "97 D9 C7 C1 4E 50 B2 C4 0D 7F C5 C2"
  },
  {
    "from": "D7 F3 D4 C1 33 EE DF 42 8C 8F D1 42",
    "to": "D7 F3 D4 C1 1D 01 BA C4 8C 8F D1 42"
  },
  {
    "from": "CF 5E 7F 41 51 94 3B 43 5B B6 CD C2",
    "to": "CF 5E 7F 41 76 8D B0 C4 5B B6 CD C2"
  },
  {
    "from": "51 4A 00 C2 D6 E6 24 43 7E 3A A9 C0",
    "to": "51 4A 00 C2 25 63 B3 C4 7E 3A A9 C0"
  },
  {
    "from": "0E 4E B2 C1 D1 9E 1C 43 26 B3 CA 41",
    "to": "0E 4E B2 C1 26 6C B4 C4 26 B3 CA 41"
  },
  {
    "from": "86 B2 88 C1 95 5C 1B 43 78 5B 01 42",
    "to": "86 B2 88 C1 6E 94 B4 C4 78 5B 01 42"
  },
  {
    "from": "39 C7 30 C2 78 06 28 43 70 06 B8 C2",
    "to": "39 C7 30 C2 31 FF B2 C4 70 06 B8 C2"
  },
  {
    "from": "BB 3F 12 C2 56 62 23 43 F8 C1 A4 40",
    "to": "BB 3F 12 C2 B5 93 B3 C4 F8 C1 A4 40"
  },
  {
    "from": "47 DE C3 41 5A 8E 29 43 4E 58 B1 C2",
    "to": "47 DE C3 41 35 CE B2 C4 4E 58 B1 C2"
  },
  {
    "from": "50 65 C7 C1 94 8A 2A 43 B9 C9 D0 C2",
    "to": "50 65 C7 C1 AE AE B2 C4 B9 C9 D0 C2"
  },
  {
    "from": "12 DF 8D 41 3F 83 41 43 22 1A BF C2",
    "to": "12 DF 8D 41 98 CF AF C4 22 1A BF C2"
  },
  {
    "from": "C0 88 3B 41 14 65 3B 43 89 A2 AF C2",
    "to": "C0 88 3B 41 5E 93 B0 C4 89 A2 AF C2"
  },
  {
    "from": "EE 1F BD 41 05 0F 5D 43 E4 20 DC C2",
    "to": "EE 1F BD 41 20 5E AC C4 E4 20 DC C2"
  },
  {
    "from": "B9 62 A9 40 D3 59 3E 43 A3 80 BD C2",
    "to": "B9 62 A9 40 C6 34 B0 C4 A3 80 BD C2"
  },
  {
    "from": "AF 99 7B C1 F6 C2 1E 43 F0 4D EA 40",
    "to": "AF 99 7B C1 A1 27 B4 C4 F0 4D EA 40"
  },
  {
    "from": "84 1D AE 41 EF 4B 4C 43 DC 49 D9 C2",
    "to": "84 1D AE 41 82 76 AE C4 DC 49 D9 C2"
  },
  {
    "from": "E9 09 06 C1 B1 E7 1E 43 B7 26 5D 3E",
    "to": "E9 09 06 C1 0A 23 B4 C4 B7 26 5D 3E"
  },
  {
    "from": "5A 2E 70 C1 2A B5 6B 43 EE 7E 34 C3",
    "to": "5A 2E 70 C1 5B 89 AA C4 EE 7E 34 C3"
  },
  {
    "from": "7D 90 13 41 10 CC 33 43 C1 CC B9 C2",
    "to": "7D 90 13 41 7E 86 B1 C4 C1 CC B9 C2"
  },
  {
    "from": "59 8A 8D 41 8E 0C 75 43 B6 AB 57 C3",
    "to": "59 8A 8D 41 6E 5E A9 C4 B6 AB 57 C3"
  },
  {
    "from": "A7 13 8C 40 0A D3 0A 43 F6 1C 76 C2",
    "to": "A7 13 8C 40 9F A5 B6 C4 F6 1C 76 C2"
  },
  {
    "from": "99 E5 DD 40 45 68 40 43 58 4B 06 C3",
    "to": "99 E5 DD 40 F8 F2 AF C4 58 4B 06 C3"
  },
  {
    "from": "1B 50 86 41 96 58 63 43 C9 3B 12 C3",
    "to": "1B 50 86 41 ED 94 AB C4 C9 3B 12 C3"
  },
  {
    "from": "06 E3 8C C1 35 F1 15 43 BA 49 7A 42",
    "to": "06 E3 8C C1 DA 41 B5 C4 BA 49 7A 42"
  },
  {
    "from": "7C 1B C4 C0 61 4A 63 43 FC 2B 13 C3",
    "to": "7C 1B C4 C0 B4 96 AB C4 FC 2B 13 C3"
  },
  {
    "from": "11 34 29 40 B9 E9 79 43 7E 90 56 C3",
    "to": "11 34 29 40 C9 C2 A8 C4 7E 90 56 C3"
  },
  {
    "from": "9F 21 DC BD 75 66 35 43 33 5E A8 C2",
    "to": "9F 21 DC BD 32 53 B1 C4 33 5E A8 C2"
  },
  {
    "from": "FF C9 9B 41 D7 3C 5A 43 B0 E6 19 C3",
    "to": "FF C9 9B 41 65 B8 AC C4 B0 E6 19 C3"
  },
  {
    "from": "05 13 EF C1 AF F1 23 43 86 89 89 C0",
    "to": "05 13 EF C1 CA 81 B3 C4 86 89 89 C0"
  },
  {
    "from": "A1 3B 81 40 EC 42 39 43 91 2C AE C2",
    "to": "A1 3B 81 40 A2 D7 B0 C4 91 2C AE C2"
  },
  {
    "from": "3E 5D 8B 42 DF D0 1F 43 8A C9 C4 C2",
    "to": "3E 5D 8B 42 E4 05 B4 C4 8A C9 C4 C2"
  },
  {
    "from": "2B EA FB 40 D7 71 4D 43 74 17 00 C3",
    "to": "2B EA FB 40 C5 51 AE C4 74 17 00 C3"
  },
  {
    "from": "38 BD 4D C0 20 6B 50 43 9C 0B 01 C3",
    "to": "38 BD 4D C0 9C F2 AD C4 9C 0B 01 C3"
  },
  {
    "from": "7F BC 3C C1 74 0E 69 43 F1 3D 23 C3",
    "to": "7F BC 3C C1 32 DE AA C4 F1 3D 23 C3"
  },
  {
    "from": "43 D3 B9 C0 08 5F 69 43 74 EB 12 C3",
    "to": "43 D3 B9 C0 1F D4 AA C4 74 EB 12 C3"
  },
  {
    "from": "12 CF F7 40 CC D2 67 43 CE 87 1A C3",
    "to": "12 CF F7 40 A6 05 AB C4 CE 87 1A C3"
  },
  {
    "from": "0A 57 96 40 98 50 6C 43 E3 63 21 C3",
    "to": "0A 57 96 40 ED 75 AA C4 E3 63 21 C3"
  },
  {
    "from": "39 66 05 41 54 3E 68 43 FA A2 1E C3",
    "to": "39 66 05 41 36 F8 AA C4 FA A2 1E C3"
  },
  {
    "from": "C5 1C C0 3F 57 D3 68 43 F6 94 26 C3",
    "to": "C5 1C C0 3F 95 E5 AA C4 F6 94 26 C3"
  },
  {
    "from": "10 95 E2 40 A4 02 3C 43 84 9E B1 C2",
    "to": "10 95 E2 40 AC 7F B0 C4 84 9E B1 C2"
  },
  {
    "from": "A5 DA EF 40 A5 8D 6B 43 C0 F7 16 C3",
    "to": "A5 DA EF 40 4C 8E AA C4 C0 F7 16 C3"
  },
  {
    "from": "35 E1 C8 40 8B ED 6A 43 9D 87 1E C3",
    "to": "35 E1 C8 40 4E A2 AA C4 9D 87 1E C3"
  },
  {
    "from": "98 7B 8E 40 A8 D3 84 43 B0 C9 7E C3",
    "to": "98 7B 8E 40 16 CB A6 C4 B0 C9 7E C3"
  },
  {
    "from": "EB 8D 31 C0 E5 36 6D 43 89 4B 34 C3",
    "to": "EB 8D 31 C0 24 59 AA C4 89 4B 34 C3"
  },
  {
    "from": "46 D1 5B 40 AB E4 38 43 19 7D B2 C2",
    "to": "46 D1 5B 40 6A E3 B0 C4 19 7D B2 C2"
  },
  {
    "from": "6E 13 24 40 1D 98 70 43 AD 57 3D C3",
    "to": "6E 13 24 40 FC EC A9 C4 AD 57 3D C3"
  },
  {
    "from": "ED 9F FB C1 54 ED E5 42 C4 D5 61 C3",
    "to": "ED 9F FB C1 2B A1 B9 C4 C4 D5 61 C3"
  },
  {
    "from": "DB 15 4E 40 B6 7C 6F 43 B6 54 3B C3",
    "to": "DB 15 4E 40 69 10 AA C4 B6 54 3B C3"
  },
  {
    "from": "20 28 67 C1 C0 4F 0B 43 23 55 A3 42",
    "to": "20 28 67 C1 08 96 B6 C4 23 55 A3 42"
  },
  {
    "from": "A2 89 57 42 1B F2 E1 42 BA F3 02 C2",
    "to": "A2 89 57 42 DE E0 B9 C4 BA F3 02 C2"
  },
  {
    "from": "32 FF 7C 41 98 1D 45 43 71 F1 C0 C2",
    "to": "32 FF 7C 41 4D 5C AF C4 71 F1 C0 C2"
  },
  {
    "from": "44 15 1E 3E 40 E8 72 43 6A 9B 45 C3",
    "to": "44 15 1E 3E F8 A2 A9 C4 6A 9B 45 C3"
  },
  {
    "from": "F0 D8 0A C1 74 84 70 43 82 EA 3C C3",
    "to": "F0 D8 0A C1 72 EF A9 C4 82 EA 3C C3"
  },
  {
    "from": "43 B8 06 C1 B2 98 6A 43 F9 78 1F C3",
    "to": "43 B8 06 C1 EA AC AA C4 F9 78 1F C3"
  },
  {
    "from": "FC 5F B1 40 4B 32 77 43 D9 DC 4C C3",
    "to": "FC 5F B1 40 B6 19 A9 C4 D9 DC 4C C3"
  },
  {
    "from": "E9 EF D9 40 94 55 77 43 78 07 4D C3",
    "to": "E9 EF D9 40 4E 15 A9 C4 78 07 4D C3"
  },
  {
    "from": "CA 7B E0 40 42 39 79 43 D0 6E 50 C3",
    "to": "CA 7B E0 40 D8 D8 A8 C4 D0 6E 50 C3"
  },
  {
    "from": "90 CA C9 40 75 26 79 43 D4 67 54 C3",
    "to": "90 CA C9 40 32 DB A8 C4 D4 67 54 C3"
  },
  {
    "from": "DD 0C E9 3F 12 5C 79 43 25 BC 4F C3",
    "to": "DD 0C E9 3F 7E D4 A8 C4 25 BC 4F C3"
  },
  {
    "from": "6B DC 89 41 5B 02 46 43 A2 61 C2 C2",
    "to": "6B DC 89 41 B4 3F AF C4 A2 61 C2 C2"
  },
  {
    "from": "F8 6C 5A C0 3E 30 52 43 DF 6F 05 C3",
    "to": "F8 6C 5A C0 F8 B9 AD C4 DF 6F 05 C3"
  },
  {
    "from": "60 80 3A 41 16 48 85 43 BD D5 81 C3",
    "to": "60 80 3A 41 FA AD A6 C4 BD D5 81 C3"
  },
  {
    "from": "B1 32 56 3F D7 1A 42 43 93 5B 05 C3",
    "to": "B1 32 56 3F A5 BC AF C4 93 5B 05 C3"
  },
  {
    "from": "93 90 92 3F 0D 55 39 43 D2 E4 08 C3",
    "to": "93 90 92 3F 5E D5 B0 C4 D2 E4 08 C3"
  },
  {
    "from": "28 9E 3D 42 D8 B8 85 43 78 48 81 C3",
    "to": "28 9E 3D 42 CA 91 A6 C4 78 48 81 C3"
  },
  {
    "from": "E9 B8 3A 3E 26 3E 85 43 18 E1 72 C3",
    "to": "E9 B8 3A 3E 76 B0 A6 C4 18 E1 72 C3"
  },
  {
    "from": "2A AE 9E 42 1B EF 1F 42 D5 9C 8A C2",
    "to": "2A AE 9E 42 87 00 C3 C4 D5 9C 8A C2"
  },
  {
    "from": "F3 B4 94 41 43 75 7C 43 07 8C 6B C3",
    "to": "F3 B4 94 41 58 71 A8 C4 07 8C 6B C3"
  },
  {
    "from": "F6 B5 6F 42 8B EA 88 43 50 F5 A9 C3",
    "to": "F6 B5 6F 42 5D C5 A5 C4 50 F5 A9 C3"
  },
  {
    "from": "EA 59 B4 40 83 DC 84 43 2A 0F 76 C3",
    "to": "EA 59 B4 40 DF C8 A6 C4 2A 0F 76 C3"
  },
  {
    "from": "24 F2 AE C0 DE D0 82 43 3A D1 7A C3",
    "to": "24 F2 AE C0 C8 4B A7 C4 3A D1 7A C3"
  },
  {
    "from": "CD 63 74 C1 27 58 1D 43 4C 1F 79 41",
    "to": "CD 63 74 C1 FB 54 B4 C4 4C 1F 79 41"
  },
  {
    "from": "E6 1B 9E 41 BF F2 47 43 1A 42 C7 C2",
    "to": "E6 1B 9E 41 A8 01 AF C4 1A 42 C7 C2"
  },
  {
    "from": "EE 27 27 41 23 A1 73 43 21 CF 47 C3",
    "to": "EE 27 27 41 DC 8B A9 C4 21 CF 47 C3"
  },
  {
    "from": "41 A0 D5 C0 B5 9B 0D 43 3B 79 53 42",
    "to": "41 A0 D5 C0 8A 4C B6 C4 3B 79 53 42"
  },
  {
    "from": "22 C0 9C C1 65 D6 1D 43 C3 F3 9E 41",
    "to": "22 C0 9C C1 34 45 B4 C4 C3 F3 9E 41"
  },
  {
    "from": "14 EC 12 41 8B BE 75 43 7D 7E 4D C3",
    "to": "14 EC 12 41 2E 48 A9 C4 7D 7E 4D C3"
  },
  {
    "from": "FF 92 7C BF D5 8E 7F 43 4B 48 68 C3",
    "to": "FF 92 7C BF 26 0E A8 C4 4B 48 68 C3"
  },
  {
    "from": "17 CC C0 40 98 65 3F 43 FB 80 BE C2",
    "to": "17 CC C0 40 4D 13 B0 C4 FB 80 BE C2"
  },
  {
    "from": "E2 DC 00 41 75 1D 85 43 13 4B 89 C3",
    "to": "E2 DC 00 41 A3 B8 A6 C4 13 4B 89 C3"
  },
  {
    "from": "20 8A 0A 42 7A 24 85 43 C0 45 8E C3",
    "to": "20 8A 0A 42 E2 B6 A6 C4 C0 45 8E C3"
  },
  {
    "from": "B5 4E 82 3F BD 94 36 43 54 1C AF C2",
    "to": "B5 4E 82 3F 68 2D B1 C4 54 1C AF C2"
  },
  {
    "from": "83 16 36 40 3E 30 52 43 C8 51 04 C3",
    "to": "83 16 36 40 F8 B9 AD C4 C8 51 04 C3"
  },
  {
    "from": "73 A8 84 42 61 33 87 43 E5 18 A4 C3",
    "to": "73 A8 84 42 28 33 A6 C4 E5 18 A4 C3"
  },
  {
    "from": "D0 18 89 42 52 09 86 43 46 B3 9D C3",
    "to": "D0 18 89 42 AC 7D A6 C4 46 B3 9D C3"
  },
  {
    "from": "F9 5D 6F 42 38 9E 85 43 4F 55 9D C3",
    "to": "F9 5D 6F 42 72 98 A6 C4 4F 55 9D C3"
  },
  {
    "from": "66 7D 5A 42 50 39 85 43 3B 6F 9A C3",
    "to": "66 7D 5A 42 AC B1 A6 C4 3B 6F 9A C3"
  },
  {
    "from": "EA 9E 4D C2 87 4E 29 43 9A 53 B9 C1",
    "to": "EA 9E 4D C2 2F D6 B2 C4 9A 53 B9 C1"
  },
  {
    "from": "75 CD F8 C0 37 05 1C 43 80 CC 41 41",
    "to": "75 CD F8 C0 59 7F B4 C4 80 CC 41 41"
  },
  {
    "from": "FC 16 23 42 E9 A1 1D 43 98 BB 3E C2",
    "to": "FC 16 23 42 C3 4B B4 C4 98 BB 3E C2"
  },
  {
    "from": "4B A0 70 C1 1D E5 11 43 DC 1D 76 42",
    "to": "4B A0 70 C1 5C C3 B5 C4 DC 1D 76 42"
  },
  {
    "from": "05 92 B7 41 43 E5 4C 43 B1 01 D9 C2",
    "to": "05 92 B7 41 58 63 AE C4 B1 01 D9 C2"
  },
  {
    "from": "81 BF 91 41 5C 69 7E 43 F6 E7 69 C3",
    "to": "81 BF 91 41 D4 32 A8 C4 F6 E7 69 C3"
  },
  {
    "from": "83 6C C2 40 C6 E8 84 43 7E 98 78 C3",
    "to": "83 6C C2 40 CE C5 A6 C4 7E 98 78 C3"
  },
  {
    "from": "4D 79 80 C1 2D B0 07 43 E2 19 B8 42",
    "to": "4D 79 80 C1 FA 09 B7 C4 E2 19 B8 42"
  },
  {
    "from": "49 8C 7D 42 A8 61 87 43 32 A0 A4 C3",
    "to": "49 8C 7D 42 96 27 A6 C4 32 A0 A4 C3"
  },
  {
    "from": "02 CB 7E 42 69 65 86 43 AB EE A1 C3",
    "to": "02 CB 7E 42 A6 66 A6 C4 AB EE A1 C3"
  },
  {
    "from": "4B 89 C4 41 AA 32 5F 43 0A E3 0C C3",
    "to": "4B 89 C4 41 AB 19 AC C4 0A E3 0C C3"
  },
  {
    "from": "25 58 08 42 CD 0C 86 43 FC 5F 69 C3",
    "to": "25 58 08 42 CD 7C A6 C4 FC 5F 69 C3"
  },
  {
    "from": "A7 23 0E C1 AA BF 10 43 DD 64 5A 42",
    "to": "A7 23 0E C1 0B E8 B5 C4 DD 64 5A 42"
  },
  {
    "from": "FE 7E C9 40 DE 6A 66 43 30 F9 0C C3",
    "to": "FE 7E C9 40 A4 32 AB C4 30 F9 0C C3"
  },
  {
    "from": "79 07 44 3F 12 E0 6E 43 40 34 3B C3",
    "to": "79 07 44 3F FE 23 AA C4 40 34 3B C3"
  },
  {
    "from": "3D BE 52 42 9B 24 1A 43 80 E6 12 C2",
    "to": "3D BE 52 42 6C BB B4 C4 80 E6 12 C2"
  },
  {
    "from": "12 06 E1 C0 E0 9E 6B 43 51 44 18 C3",
    "to": "12 06 E1 C0 24 8C AA C4 51 44 18 C3"
  },
  {
    "from": "C8 35 64 41 A7 BC 53 43 40 B8 F8 C2",
    "to": "C8 35 64 41 6B 88 AD C4 40 B8 F8 C2"
  },
  {
    "from": "5B 43 B6 40 AA 11 3F 43 1C 0F BE C2",
    "to": "5B 43 B6 40 CB 1D B0 C4 1C 0F BE C2"
  },
  {
    "from": "30 1F C4 40 63 E6 84 43 3D 97 76 C3",
    "to": "30 1F C4 40 67 C6 A6 C4 3D 97 76 C3"
  },
  {
    "from": "22 95 5F C0 BC 73 0D 43 64 95 60 42",
    "to": "22 95 5F C0 88 51 B6 C4 64 95 60 42"
  },
  {
    "from": "E2 73 F7 3F FD 65 6F 43 F2 57 3C C3",
    "to": "E2 73 F7 3F 40 13 AA C4 F2 57 3C C3"
  },
  {
    "from": "F6 0C 9E C0 E6 1C 81 43 95 C0 6B C3",
    "to": "F6 0C 9E C0 C6 B8 A7 C4 95 C0 6B C3"
  },
  {
    "from": "20 8A 0A 42 7A 24 85 43 AC 10 93 C3",
    "to": "20 8A 0A 42 E2 B6 A6 C4 AC 10 93 C3"
  },
  {
    "from": "44 BE 31 C2 10 AF 7F 43 6F BA 5F C3",
    "to": "44 BE 31 C2 1E 0A A8 C4 6F BA 5F C3"
  },
  {
    "from": "BC FA F5 C1 23 0B 61 43 50 56 1D C3",
    "to": "BC FA F5 C1 9C DE AB C4 50 56 1D C3"
  },
  {
    "from": "D5 C2 20 42 AC 1F 7C 43 2B B0 58 C3",
    "to": "D5 C2 20 42 0A 7C A8 C4 2B B0 58 C3"
  },
  {
    "from": "29 31 31 C1 2B D9 18 43 6C 3F 13 42",
    "to": "29 31 31 C1 DA E4 B4 C4 6C 3F 13 42"
  },
  {
    "from": "B6 03 24 C0 48 75 0E 43 EB B1 7D 42",
    "to": "B6 03 24 C0 57 31 B6 C4 EB B1 7D 42"
  },
  {
    "from": "C3 9A DC 3F 8C 5B 83 43 01 98 70 C3",
    "to": "C3 9A DC 3F 1D 29 A7 C4 01 98 70 C3"
  },
  {
    "from": "19 0E 3F C1 B6 47 6C 43 9C 0D 33 C3",
    "to": "19 0E 3F C1 09 77 AA C4 9C 0D 33 C3"
  },
  {
    "from": "6D AB 71 41 45 DD 44 43 A1 E6 C5 C2",
    "to": "6D AB 71 41 58 64 AF C4 A1 E6 C5 C2"
  },
  {
    "from": "01 B0 91 C1 DF 3B 36 43 49 3A E0 C2",
    "to": "01 B0 91 C1 84 38 B1 C4 49 3A E0 C2"
  },
  {
    "from": "E8 DA 0B 40 EC 3E 39 43 58 67 B4 C2",
    "to": "E8 DA 0B 40 22 D8 B0 C4 58 67 B4 C2"
  },
  {
    "from": "70 14 DF 41 7D 41 85 43 81 1B 8D C3",
    "to": "70 14 DF 41 A1 AF A6 C4 81 1B 8D C3"
  },
  {
    "from": "2E CE A9 41 58 8A 1B 43 E8 AF 91 C2",
    "to": "2E CE A9 41 B5 8E B4 C4 E8 AF 91 C2"
  },
  {
    "from": "AA 00 26 C1 91 98 14 43 5F DF 72 42",
    "to": "AA 00 26 C1 EE 6C B5 C4 5F DF 72 42"
  },
  {
    "from": "26 60 97 41 6E 7F 59 43 66 52 DD C2",
    "to": "26 60 97 41 12 D0 AC C4 66 52 DD C2"
  },
  {
    "from": "58 CA 7E 42 BF B7 85 43 EE 97 92 C3",
    "to": "58 CA 7E 42 10 92 A6 C4 EE 97 92 C3"
  },
  {
    "from": "76 C1 82 40 2C C6 50 43 AC 50 04 C3",
    "to": "76 C1 82 40 3A E7 AD C4 AC 50 04 C3"
  },
  {
    "from": "A4 62 2E 41 65 A7 53 43 26 53 ED C2",
    "to": "A4 62 2E 41 14 8B AD C4 26 53 ED C2"
  },
  {
    "from": "35 2B 55 42 33 68 30 43 A4 96 37 C2",
    "to": "35 2B 55 42 FA F2 B1 C4 A4 96 37 C2"
  },
  {
    "from": "55 CD 9C C1 9C B8 0E 43 89 1F 89 42",
    "to": "55 CD 9C C1 EC 28 B6 C4 89 1F 89 42"
  },
  {
    "from": "E4 78 F9 41 41 02 29 43 04 55 C4 C2",
    "to": "E4 78 F9 41 B8 DF B2 C4 04 55 C4 C2"
  },
  {
    "from": "18 B3 65 41 DB 3F 85 43 4D 41 88 C3",
    "to": "18 B3 65 41 09 B0 A6 C4 4D 41 88 C3"
  },
  {
    "from": "30 55 7F 42 D3 9A 87 43 04 98 A5 C3",
    "to": "30 55 7F 42 4B 19 A6 C4 04 98 A5 C3"
  },
  {
    "from": "F7 4F C4 41 45 3E 5F 43 06 C9 0C C3",
    "to": "F7 4F C4 41 38 18 AC C4 06 C9 0C C3"
  },
  {
    "from": "14 1A 16 41 97 C2 83 43 BA 0D 86 C3",
    "to": "14 1A 16 41 5A 0F A7 C4 BA 0D 86 C3"
  },
  {
    "from": "F0 29 A3 C1 14 4E 20 43 E2 33 26 C2",
    "to": "F0 29 A3 C1 3E F6 B3 C4 E2 33 26 C2"
  },
  {
    "from": "38 AE 7A C1 AC 25 16 43 58 6F 77 42",
    "to": "38 AE 7A C1 4A 3B B5 C4 58 6F 77 42"
  },
  {
    "from": "6A D7 15 41 48 5B 66 43 E3 E0 48 C3",
    "to": "6A D7 15 41 97 34 AB C4 E3 E0 48 C3"
  },
  {
    "from": "7E A9 3E 41 C7 F7 51 43 E7 90 E8 C2",
    "to": "7E A9 3E 41 07 C1 AD C4 E7 90 E8 C2"
  },
  {
    "from": "F2 D1 95 C1 C2 A9 72 43 5A 25 47 C3",
    "to": "F2 D1 95 C1 C8 AA A9 C4 5A 25 47 C3"
  },
  {
    "from": "F8 EC FE 40 39 ED 84 43 7B 54 7D C3",
    "to": "F8 EC FE 40 B2 C4 A6 C4 7B 54 7D C3"
  },
  {
    "from": "29 66 29 41 45 69 54 43 CE C2 ED C2",
    "to": "29 66 29 41 D8 72 AD C4 CE C2 ED C2"
  },
  {
    "from": "4E 60 20 40 78 41 67 43 DC CD 2E C3",
    "to": "4E 60 20 40 D1 17 AB C4 DC CD 2E C3"
  },
  {
    "from": "7E E0 21 41 8A B6 53 43 EC 93 07 C3",
    "to": "7E E0 21 41 2F 89 AD C4 EC 93 07 C3"
  },
  {
    "from": "FC 39 2F 41 46 45 52 43 37 43 F0 C2",
    "to": "FC 39 2F 41 57 B7 AD C4 37 43 F0 C2"
  },
  {
    "from": "68 D8 94 C0 3E F4 7D 43 70 76 80 C3",
    "to": "68 D8 94 C0 78 41 A8 C4 70 76 80 C3"
  },
  {
    "from": "C7 41 F2 C1 48 EF 23 43 4B 05 C6 C0",
    "to": "C7 41 F2 C1 17 82 B3 C4 4B 05 C6 C0"
  },
  {
    "from": "DC 0E 99 41 05 24 63 43 DA D5 19 C3",
    "to": "DC 0E 99 41 80 9B AB C4 DA D5 19 C3"
  },
  {
    "from": "95 30 33 C1 7F A2 0E 43 85 8B 5A 42",
    "to": "95 30 33 C1 B0 2B B6 C4 85 8B 5A 42"
  },
  {
    "from": "4B 56 9A 41 AB BD 59 43 84 C7 DC C2",
    "to": "4B 56 9A 41 4A C8 AC C4 84 C7 DC C2"
  },
  {
    "from": "61 AC 83 40 25 5A 76 43 FE A4 4B C3",
    "to": "61 AC 83 40 BC 34 A9 C4 FE A4 4B C3"
  },
  {
    "from": "BB 1A A9 41 F3 7C 55 43 0D 57 FA C2",
    "to": "BB 1A A9 41 62 50 AD C4 0D 57 FA C2"
  },
  {
    "from": "7A 6C C7 BF 77 3E 50 43 82 B1 03 C3",
    "to": "7A 6C C7 BF 31 F8 AD C4 82 B1 03 C3"
  },
  {
    "from": "F9 0A B0 C2 D7 1C 92 42 B7 07 57 C3",
    "to": "F9 0A B0 C2 32 DE BE C4 B7 07 57 C3"
  },
  {
    "from": "00 06 07 C1 C9 A2 1C 43 F5 6A 06 41",
    "to": "00 06 07 C1 A7 6B B4 C4 F5 6A 06 41"
  },
  {
    "from": "8B AF 8F C1 F8 74 8D 43 2E 13 73 C3",
    "to": "8B AF 8F C1 C2 A2 A4 C4 2E 13 73 C3"
  },
  {
    "from": "53 88 5D 42 E7 42 83 43 07 14 6B C3",
    "to": "53 88 5D 42 46 2F A7 C4 07 14 6B C3"
  },
  {
    "from": "4B 09 3D C1 48 0C 11 43 01 76 47 42",
    "to": "4B 09 3D C1 77 DE B5 C4 01 76 47 42"
  },
  {
    "from": "F3 AB 2E C0 53 BF 61 43 3E 4E 0B C3",
    "to": "F3 AB 2E C0 16 C8 AB C4 3E 4E 0B C3"
  },
  {
    "from": "36 EA 86 40 40 7B 51 43 CF 32 06 C3",
    "to": "36 EA 86 40 98 D0 AD C4 CF 32 06 C3"
  },
  {
    "from": "5E 03 6C 42 D5 9C 76 43 70 2A 5C C3",
    "to": "5E 03 6C 42 66 2C A9 C4 70 2A 5C C3"
  },
  {
    "from": "CA 6C 41 C0 36 5C 4F 43 2F 53 01 C3",
    "to": "CA 6C 41 C0 79 14 AE C4 2F 53 01 C3"
  },
  {
    "from": "82 1E 02 C3 62 DB 22 43 F0 AF 10 C3",
    "to": "82 1E 02 C3 94 A4 B3 C4 F0 AF 10 C3"
  },
  {
    "from": "D3 4A FC 42 1E F1 10 43 24 E6 1A C3",
    "to": "D3 4A FC 42 DC E1 B5 C4 24 E6 1A C3"
  },
  {
    "from": "5A 26 AA 41 D1 60 85 43 68 E1 89 C3",
    "to": "5A 26 AA 41 CC A7 A6 C4 68 E1 89 C3"
  },
  {
    "from": "3F FA 8D C1 10 08 13 43 9B C9 8B 42",
    "to": "3F FA 8D C1 FE 9E B5 C4 9B C9 8B 42"
  },
  {
    "from": "C7 C6 C2 C0 83 03 6B 43 CF 6C 1C C3",
    "to": "C7 C6 C2 C0 90 9F AA C4 CF 6C 1C C3"
  },
  {
    "from": "F9 3D 0A C1 F3 57 31 43 7F C9 72 C2",
    "to": "F9 3D 0A C1 02 D5 B1 C4 7F C9 72 C2"
  },
  {
    "from": "81 A0 F6 C1 E5 29 27 43 CF 06 5D C1",
    "to": "81 A0 F6 C1 C4 1A B3 C4 CF 06 5D C1"
  },
  {
    "from": "57 3F 56 40 D0 0B 76 43 CA A2 4C C3",
    "to": "57 3F 56 40 86 3E A9 C4 CA A2 4C C3"
  },
  {
    "from": "F0 5B 79 C1 FC D9 1C 43 4C EB 8E 41",
    "to": "F0 5B 79 C1 C0 64 B4 C4 4C EB 8E 41"
  },
  {
    "from": "54 A7 B7 C0 B3 EA 4D 43 FE D2 01 C3",
    "to": "54 A7 B7 C0 AA 42 AE C4 FE D2 01 C3"
  },
  {
    "from": "D4 35 18 42 A7 47 28 43 52 75 B3 C2",
    "to": "D4 35 18 42 0B F7 B2 C4 52 75 B3 C2"
  },
  {
    "from": "C8 25 C7 C0 0B BD C3 42 5D 8F 05 C2",
    "to": "C8 25 C7 C0 2F C4 BB C4 5D 8F 05 C2"
  },
  {
    "from": "4F C8 48 42 E2 D3 19 43 4D DE 1B C2",
    "to": "4F C8 48 42 84 C5 B4 C4 4D DE 1B C2"
  },
  {
    "from": "E1 01 7A C1 DD 44 6F 43 3E EF 4F C3",
    "to": "E1 01 7A C1 64 17 AA C4 3E EF 4F C3"
  },
  {
    "from": "D3 DD 09 40 B9 E9 79 43 4A 74 59 C3",
    "to": "D3 DD 09 40 C9 C2 A8 C4 4A 74 59 C3"
  },
  {
    "from": "A6 89 B8 40 58 BD 3C 43 07 A7 B4 C2",
    "to": "A6 89 B8 40 55 68 B0 C4 07 A7 B4 C2"
  },
  {
    "from": "F7 2A 87 C1 F2 0B 0A 43 3C 92 A3 42",
    "to": "F7 2A 87 C1 82 BE B6 C4 3C 92 A3 42"
  },
  {
    "from": "ED FA 5F C2 DF 47 24 43 EC 1D 00 C1",
    "to": "ED FA 5F C2 04 77 B3 C4 EC 1D 00 C1"
  },
  {
    "from": "28 51 9D 41 DA D6 42 43 27 D9 C0 C2",
    "to": "28 51 9D 41 25 A5 AF C4 27 D9 C0 C2"
  },
  {
    "from": "7D E8 41 C1 80 AB 1D 43 F0 4D EA 40",
    "to": "7D E8 41 C1 90 4A B4 C4 F0 4D EA 40"
  },
  {
    "from": "DA 75 EE 40 C7 D1 87 43 3A D1 7A C3",
    "to": "DA 75 EE 40 8E 0B A6 C4 3A D1 7A C3"
  },
  {
    "from": "EF 89 40 C1 AA D5 0C 43 FC A7 60 42",
    "to": "EF 89 40 C1 4B 65 B6 C4 FC A7 60 42"
  },
  {
    "from": "F9 7C 87 41 88 A8 66 43 66 FE 09 C3",
    "to": "F9 7C 87 41 EF 2A AB C4 66 FE 09 C3"
  },
  {
    "from": "D7 B0 20 42 E3 77 7D 43 A3 90 58 C3",
    "to": "D7 B0 20 42 04 51 A8 C4 A3 90 58 C3"
  },
  {
    "from": "E2 31 2C 41 C5 AE 51 43 29 05 EF C2",
    "to": "E2 31 2C 41 28 CA AD C4 29 05 EF C2"
  },
  {
    "from": "2C C5 6A C1 AF D6 0C 43 AC EC 97 42",
    "to": "2C C5 6A C1 2A 65 B6 C4 AC EC 97 42"
  },
  {
    "from": "4D 0F 13 C1 0E D2 0C 43 F3 9A 5F 42",
    "to": "4D 0F 13 C1 BE 65 B6 C4 F3 9A 5F 42"
  },
  {
    "from": "49 2A 8C 41 F7 E4 52 43 CC F0 F3 C2",
    "to": "49 2A 8C 41 61 A3 AD C4 CC F0 F3 C2"
  },
  {
    "from": "53 53 C7 41 6E 2C 63 43 1E 50 F2 C2",
    "to": "53 53 C7 41 72 9A AB C4 1E 50 F2 C2"
  },
  {
    "from": "96 CE D7 BE 34 91 36 43 43 D1 AC C2",
    "to": "96 CE D7 BE DA 2D B1 C4 43 D1 AC C2"
  },
  {
    "from": "99 E2 79 C1 AB 42 88 43 B0 68 63 C3",
    "to": "99 E2 79 C1 55 EF A5 C4 B0 68 63 C3"
  },
  {
    "from": "6B 70 3C C1 86 33 10 43 C3 0F 4C 42",
    "to": "6B 70 3C C1 8F F9 B5 C4 C3 0F 4C 42"
  },
  {
    "from": "2E 88 CF 40 08 5E 3F 43 3F D3 BB C2",
    "to": "2E 88 CF 40 3F 14 B0 C4 3F D3 BB C2"
  },
  {
    "from": "1B 60 99 40 B4 70 3E 43 A0 D9 BC C2",
    "to": "1B 60 99 40 EA 31 B0 C4 A0 D9 BC C2"
  },
  {
    "from": "4B 1F 60 C1 29 BA 07 43 E5 00 85 42",
    "to": "4B 1F 60 C1 BB 08 B7 C4 E5 00 85 42"
  },
  {
    "from": "0A B2 92 41 73 7D 8A 43 EF A5 80 C3",
    "to": "0A B2 92 41 A3 60 A5 C4 EF A5 80 C3"
  },
  {
    "from": "20 9C 2A 40 FD E4 46 43 1C 5F 05 C3",
    "to": "20 9C 2A 40 60 23 AF C4 1C 5F 05 C3"
  },
  {
    "from": "B3 E4 09 C1 9E D7 1A 43 61 85 9D 41",
    "to": "B3 E4 09 C1 0C A5 B4 C4 61 85 9D 41"
  },
  {
    "from": "9C B1 42 41 32 C1 31 43 25 DF C2 C2",
    "to": "9C B1 42 41 DA C7 B1 C4 25 DF C2 C2"
  },
  {
    "from": "0B 04 6C 42 5E 2B 76 43 05 25 5C C3",
    "to": "0B 04 6C 42 94 3A A9 C4 05 25 5C C3"
  },
  {
    "from": "2C E5 7F 41 BD 70 1C 43 8D AB A4 C2",
    "to": "2C E5 7F 41 E8 71 B4 C4 8D AB A4 C2"
  },
  {
    "from": "FF 41 23 40 3B 27 53 43 36 7C 07 C3",
    "to": "FF 41 23 40 18 9B AD C4 36 7C 07 C3"
  },
  {
    "from": "85 0C 68 41 7A 67 44 43 3D 84 C5 C2",
    "to": "85 0C 68 41 11 73 AF C4 3D 84 C5 C2"
  },
  {
    "from": "1B D8 E1 41 A6 45 85 43 7F B0 91 C3",
    "to": "1B D8 E1 41 96 AE A6 C4 7F B0 91 C3"
  },
  {
    "from": "96 03 C1 41 F0 37 4F 43 70 9C F5 C2",
    "to": "96 03 C1 41 02 19 AE C4 70 9C F5 C2"
  },
  {
    "from": "2B 03 F6 C1 26 1F 33 43 08 A2 A9 C2",
    "to": "2B 03 F6 C1 1B 9C B1 C4 08 A2 A9 C2"
  },
  {
    "from": "53 CF A8 41 6C 6B 1F 43 9B 11 92 C2",
    "to": "53 CF A8 41 92 12 B4 C4 9B 11 92 C2"
  },
  {
    "from": "D4 0F BB C1 BF 82 20 43 70 44 EE C1",
    "to": "D4 0F BB C1 A8 EF B3 C4 70 44 EE C1"
  },
  {
    "from": "1E 28 99 40 98 FE 52 43 FB 04 08 C3",
    "to": "1E 28 99 40 2D A0 AD C4 FB 04 08 C3"
  },
  {
    "from": "40 E8 2E C1 56 05 71 43 B5 41 3C C3",
    "to": "40 E8 2E C1 55 DF A9 C4 B5 41 3C C3"
  },
  {
    "from": "F0 87 38 40 83 03 6B 43 85 8C 24 C3",
    "to": "F0 87 38 40 90 9F AA C4 85 8C 24 C3"
  },
  {
    "from": "04 8E 88 C0 93 1A 73 43 D5 63 44 C3",
    "to": "04 8E 88 C0 AE 9C A9 C4 D5 63 44 C3"
  },
  {
    "from": "B0 4F 06 C1 28 97 69 43 CA 62 1C C3",
    "to": "B0 4F 06 C1 1B CD AA C4 CA 62 1C C3"
  },
  {
    "from": "C3 3F 7B 41 8F 4F 45 43 82 48 C6 C2",
    "to": "C3 3F 7B 41 0E 56 AF C4 82 48 C6 C2"
  },
  {
    "from": "41 6C CA C1 81 C0 2F 43 02 6F AD C2",
    "to": "41 6C CA C1 F0 07 B2 C4 02 6F AD C2"
  },
  {
    "from": "D6 59 AF 41 4F 4D 85 43 F4 61 8C C3",
    "to": "D6 59 AF 41 AC AC A6 C4 F4 61 8C C3"
  },
  {
    "from": "F5 10 E8 40 09 9E 84 43 BE FB 71 C3",
    "to": "F5 10 E8 40 7E D8 A6 C4 BE FB 71 C3"
  },
  {
    "from": "88 8C A2 42 28 0B 4F 43 99 2A D3 C2",
    "to": "88 8C A2 42 9B 1E AE C4 99 2A D3 C2"
  },
  {
    "from": "A2 AF 53 42 AB 42 85 43 6C 76 93 C3",
    "to": "A2 AF 53 42 55 AF A6 C4 6C 76 93 C3"
  },
  {
    "from": "74 0B 1C C1 71 DF 10 43 3F 24 8D 42",
    "to": "74 0B 1C C1 12 E4 B5 C4 3F 24 8D 42"
  },
  {
    "from": "4F 87 0E C1 AD B6 1A 43 7E FD BC 41",
    "to": "4F 87 0E C1 2A A9 B4 C4 7E FD BC 41"
  },
  {
    "from": "AA 83 B8 42 02 17 57 43 09 99 BF C2",
    "to": "AA 83 B8 42 20 1D AD C4 09 99 BF C2"
  },
  {
    "from": "B5 4F 45 C2 9F 9A 26 43 DB 6F 1D 3E",
    "to": "B5 4F 45 C2 AC 2C B3 C4 DB 6F 1D 3E"
  },
  {
    "from": "40 3A 4F C1 30 26 0F 43 C3 9E 57 42",
    "to": "40 3A 4F C1 3A 1B B6 C4 C3 9E 57 42"
  },
  {
    "from": "1A 43 BD 40 A9 4E 53 43 4B 03 07 C3",
    "to": "1A 43 BD 40 2B 96 AD C4 4B 03 07 C3"
  },
  {
    "from": "44 9E 37 41 C6 87 A3 42 51 B2 A7 41",
    "to": "44 9E 37 41 84 C7 BD C4 51 B2 A7 41"
  },
  {
    "from": "BD A0 4A 42 D3 E3 10 43 D3 E3 18 C2",
    "to": "BD A0 4A 42 86 E3 B5 C4 D3 E3 18 C2"
  },
  {
    "from": "CA 3E BF C2 4A 5C 49 43 43 15 63 C3",
    "to": "CA 3E BF C2 77 D4 AE C4 43 15 63 C3"
  },
  {
    "from": "40 16 33 40 9C EF 37 43 01 7B B1 C2",
    "to": "40 16 33 40 0C 02 B1 C4 01 7B B1 C2"
  },
  {
    "from": "5B 4F 62 C1 06 84 1E 43 99 2F F1 40",
    "to": "5B 4F 62 C1 7F 2F B4 C4 99 2F F1 40"
  },
  {
    "from": "28 0F 47 41 90 41 75 43 7D 57 4A C3",
    "to": "28 0F 47 41 CE 57 A9 C4 7D 57 4A C3"
  },
  {
    "from": "F4 70 8E 41 F3 52 81 43 29 67 72 C3",
    "to": "F4 70 8E 41 43 AB A7 C4 29 67 72 C3"
  },
  {
    "from": "6E 0F 4B C1 86 C8 2F 43 A2 30 AF C2",
    "to": "6E 0F 4B C1 EF 06 B2 C4 A2 30 AF C2"
  },
  {
    "from": "AA 39 B5 41 8F D9 61 43 4F 6E 20 C3",
    "to": "AA 39 B5 41 CE C4 AB C4 4F 6E 20 C3"
  },
  {
    "from": "B1 2E 4F 42 07 DA 3E 43 73 C0 DF C2",
    "to": "B1 2E 4F 42 BF 24 B0 C4 73 C0 DF C2"
  },
  {
    "from": "0F EF 95 3F FF 1E 80 43 52 90 67 C3",
    "to": "0F EF 95 3F 40 F8 A7 C4 52 90 67 C3"
  },
  {
    "from": "18 5E AE 42 D3 56 56 43 07 6A 04 C3",
    "to": "18 5E AE 42 26 35 AD C4 07 6A 04 C3"
  },
  {
    "from": "A5 23 60 41 8B 01 6E 43 82 CF 48 C3",
    "to": "A5 23 60 41 CE 3F AA C4 82 CF 48 C3"
  },
  {
    "from": "F6 44 3B 42 B8 E4 2E 43 26 30 C1 C2",
    "to": "F6 44 3B 42 69 23 B2 C4 26 30 C1 C2"
  },
  {
    "from": "73 63 7E 40 98 50 6C 43 62 AC 1C C3",
    "to": "73 63 7E 40 ED 75 AA C4 62 AC 1C C3"
  },
  {
    "from": "F2 DC 95 41 14 9A 58 43 82 EE DC C2",
    "to": "F2 DC 95 41 BE EC AC C4 82 EE DC C2"
  },
  {
    "from": "BE A8 65 41 A7 AB 51 43 72 CE EA C2",
    "to": "BE A8 65 41 8B CA AD C4 72 CE EA C2"
  },
  {
    "from": "36 83 7B 40 B8 9B 3D 43 59 AF BB C2",
    "to": "36 83 7B 40 89 4C B0 C4 59 AF BB C2"
  },
  {
    "from": "49 2C 45 BF 64 30 50 43 9A DA 03 C3",
    "to": "49 2C 45 BF F4 F9 AD C4 9A DA 03 C3"
  },
  {
    "from": "73 8E 30 42 42 BE 84 43 F1 D8 93 C3",
    "to": "73 8E 30 42 70 D0 A6 C4 F1 D8 93 C3"
  },
  {
    "from": "2D 6F 9A C1 FC 83 0D 43 2B A6 95 42",
    "to": "2D 6F 9A C1 80 4F B6 C4 2B A6 95 42"
  },
  {
    "from": "CE 38 62 40 57 6D 76 43 70 E1 4C C3",
    "to": "CE 38 62 40 55 32 A9 C4 70 E1 4C C3"
  },
  {
    "from": "6D 2D 4C C1 4C 3D 0A 43 5D C8 95 42",
    "to": "6D 2D 4C C1 56 B8 B6 C4 5D C8 95 42"
  },
  {
    "from": "AE 4F 4F C1 A9 4F 4D 43 70 8D FB C2",
    "to": "AE 4F 4F C1 0B 56 AE C4 70 8D FB C2"
  },
  {
    "from": "E8 6A 2B 3E 95 2E 73 43 D2 87 45 C3",
    "to": "E8 6A 2B 3E 2E 9A A9 C4 D2 87 45 C3"
  },
  {
    "from": "14 CD 7A C1 A8 DF 1B 43 B6 AC DA 41",
    "to": "14 CD 7A C1 0B 84 B4 C4 B6 AC DA 41"
  },
  {
    "from": "8B 72 5E 41 B4 05 E8 42 A6 79 89 42",
    "to": "8B 72 5E 41 A5 7F B9 C4 A6 79 89 42"
  },
  {
    "from": "B3 EE C3 40 69 03 4E 43 F1 F0 F6 C2",
    "to": "B3 EE C3 40 93 3F AE C4 F1 F0 F6 C2"
  },
  {
    "from": "51 88 3F 41 3F 06 3E 43 6F CE E5 C2",
    "to": "51 88 3F 41 38 3F B0 C4 6F CE E5 C2"
  },
  {
    "from": "F7 B4 CE 41 08 37 49 43 0F 42 D4 C2",
    "to": "F7 B4 CE 41 1F D9 AE C4 0F 42 D4 C2"
  },
  {
    "from": "FD 15 E9 C2 07 2E A1 42 55 93 DB C2",
    "to": "FD 15 E9 C2 20 ED BD C4 55 93 DB C2"
  },
  {
    "from": "71 89 40 C1 D0 CC 12 43 75 65 3E 42",
    "to": "71 89 40 C1 66 A6 B5 C4 75 65 3E 42"
  },
  {
    "from": "F4 F2 52 C1 AE 54 06 43 37 02 B7 42",
    "to": "F4 F2 52 C1 6A 35 B7 C4 37 02 B7 42"
  },
  {
    "from": "F9 9D 86 C0 90 8E 32 43 A7 05 A1 C2",
    "to": "F9 9D 86 C0 2E AE B1 C4 A7 05 A1 C2"
  },
  {
    "from": "5A 4D 07 C2 93 26 22 43 D6 EC 0C 41",
    "to": "5A 4D 07 C2 2E BB B3 C4 D6 EC 0C 41"
  },
  {
    "from": "F1 03 B8 40 84 42 5B 43 90 CF F6 C2",
    "to": "F1 03 B8 40 B0 97 AC C4 90 CF F6 C2"
  },
  {
    "from": "25 CB 83 41 75 1D 85 43 8E 9B 85 C3",
    "to": "25 CB 83 41 A3 B8 A6 C4 8E 9B 85 C3"
  },
  {
    "from": "29 15 5C 41 DB 3F 85 43 39 CE 86 C3",
    "to": "29 15 5C 41 09 B0 A6 C4 39 CE 86 C3"
  },
  {
    "from": "56 F4 AF 3E 2F 0F 33 43 5E 61 9F C2",
    "to": "56 F4 AF 3E 1A 9E B1 C4 5E 61 9F C2"
  },
  {
    "from": "2E 4B AF 40 28 97 69 43 4F 1A 28 C3",
    "to": "2E 4B AF 40 1B CD AA C4 4F 1A 28 C3"
  },
  {
    "from": "AD 98 70 42 D0 22 F0 42 40 D9 93 42",
    "to": "AD 98 70 42 D3 FD B8 C4 40 D9 93 42"
  },
  {
    "from": "35 DF 77 41 B4 33 4E 43 56 AA F4 C2",
    "to": "35 DF 77 41 8A 39 AE C4 56 AA F4 C2"
  },
  {
    "from": "A8 FE DF BF 89 54 82 40 C1 70 BA BF",
    "to": "A8 FE DF BF AC 7D C7 C4 C1 70 BA BF"
  },
  {
    "from": "F5 70 E8 41 EB 11 EF 42 7F E0 1A 42",
    "to": "F5 70 E8 41 E1 0E B9 C4 7F E0 1A 42"
  },
  {
    "from": "E6 07 EA 42 65 DC 03 43 35 88 A2 C1",
    "to": "E6 07 EA 42 74 84 B7 C4 35 88 A2 C1"
  },
  {
    "from": "DC FC 7C 42 4B B5 88 43 C7 27 A9 C3",
    "to": "DC FC 7C 42 AD D2 A5 C4 C7 27 A9 C3"
  },
  {
    "from": "63 74 60 42 6F E6 BA 42 EF 5C 30 C3",
    "to": "63 74 60 42 99 51 BC C4 EF 5C 30 C3"
  },
  {
    "from": "A0 3F 8E 41 0C 9C 59 43 F5 6B DC C2",
    "to": "A0 3F 8E 41 7E CC AC C4 F5 6B DC C2"
  },
  {
    "from": "AC 33 03 C1 62 80 09 43 0D 7B 73 42",
    "to": "AC 33 03 C1 F4 CF B6 C4 0D 7B 73 42"
  },
  {
    "from": "5F 2B 2E C1 A8 31 14 43 25 D5 60 42",
    "to": "5F 2B 2E C1 CB 79 B5 C4 25 D5 60 42"
  },
  {
    "from": "E4 57 B2 41 9B E7 4F 43 53 7C DE C2",
    "to": "E4 57 B2 41 0C 03 AE C4 53 7C DE C2"
  },
  {
    "from": "36 B4 70 42 92 65 87 43 7B CA A4 C3",
    "to": "36 B4 70 42 9C 26 A6 C4 7B CA A4 C3"
  },
  {
    "from": "2E C9 F5 3F A8 1F 6F 43 8B 6B 3C C3",
    "to": "2E C9 F5 3F 0B 1C AA C4 8B 6B 3C C3"
  },
  {
    "from": "39 EC D8 40 92 C1 83 43 10 E7 7F C3",
    "to": "39 EC D8 40 9C 0F A7 C4 10 E7 7F C3"
  },
  {
    "from": "8C 03 CE 41 04 FE 5F 43 8A 09 EE C2",
    "to": "8C 03 CE 41 40 00 AC C4 8A 09 EE C2"
  },
  {
    "from": "3A 23 A4 40 75 1D 85 43 A6 C3 82 C3",
    "to": "3A 23 A4 40 A3 B8 A6 C4 A6 C3 82 C3"
  },
  {
    "from": "75 F6 86 41 48 16 4D 43 D9 9C ED C2",
    "to": "75 F6 86 41 37 5D AE C4 D9 9C ED C2"
  },
  {
    "from": "3D 28 3C BF 98 59 34 43 E4 93 A8 C2",
    "to": "3D 28 3C BF CD 74 B1 C4 E4 93 A8 C2"
  },
  {
    "from": "27 D2 B1 C1 BA 8D 1F 43 F7 60 8C 41",
    "to": "27 D2 B1 C1 49 0E B4 C4 F7 60 8C 41"
  },
  {
    "from": "1B 6F C9 41 8B 83 4D 43 0C 7C F5 C2",
    "to": "1B 6F C9 41 8E 4F AE C4 0C 7C F5 C2"
  },
  {
    "from": "68 F9 ED C2 26 85 4B 43 1F EE 32 C3",
    "to": "68 F9 ED C2 5B 8F AE C4 1F EE 32 C3"
  },
  {
    "from": "21 42 3F C1 1E B7 11 43 16 5E 44 42",
    "to": "21 42 3F C1 1C C9 B5 C4 16 5E 44 42"
  },
  {
    "from": "3A B1 D4 41 99 AC 5D 43 B8 30 E7 C2",
    "to": "3A B1 D4 41 6D 4A AC C4 B8 30 E7 C2"
  },
  {
    "from": "C6 0B 9F 40 BA FF 77 43 58 AE 4D C3",
    "to": "C6 0B 9F 40 09 00 A9 C4 58 AE 4D C3"
  },
  {
    "from": "70 5B 84 41 68 3A A6 43 94 A4 A7 C3",
    "to":   "00 00 A0 C1 00 00 DC 42 00 00 16 C4"
  },
  {
    "from": "CA EA AC C1 84 E2 20 43 5F 44 52 C2",
    "to":   "12 3D 9B C1 00 00 66 42 D3 D1 A0 C2"
  },
    {
    "from": "9A B2 B9 40",
    "to":   "00 80 73 44"
  },
  {
    "from": "6F F4 BA 40",
    "to":   "00 80 73 44"
  },
  {
    "from": "3D 1F C0 C1 33 20 32 43 D7 64 50 C2",
    "to":   "CB AD 25 C2 00 00 00 00 BF 17 BE C2"
  },
    {
    "from": "FB 14 8D 41 06 2C 51 43 6D 0F EB C2",
    "to":   "CD 97 01 C2 00 00 00 00 E9 06 22 C3"
  },
    {
    "from": "8F E1 4D 42 B2 8E 84 43 08 11 95 C3",
    "to":   "D4 D1 D4 C1 00 00 00 00 BA E0 0E C3"
  },
    {
    "from": "9C 36 A4 40 0D 6C 33 43 98 45 E1 C2",
    "to":   "A9 60 6A C2 00 00 00 00 73 12 91 C2"
  },
  {
    "from": "27 77 C5 C0 FA 90 07 43 E6 F9 87 42",
    "to": "01 91 A6 40 52 38 76 42 9F 53 AF C2"
  },
  {
    "from": "87 16 C1 C0 94 8F 07 43 6A CF 87 42",
    "to": "52 2E A7 40 52 38 76 42 1F 16 B0 C2"
  },
  {
    "from": "E6 2F C9 C0 6B 9B 07 43 BA B2 87 42",
    "to": "6E AF 96 40 52 38 76 42 1C AD AF C2"
  },
  {
    "from": "07 DF E6 C0 21 A9 07 43 F8 74 86 42",
    "to": "41 72 40 41 33 B3 81 42 EF 18 C8 C2"
  },
  {
    "from": "46 EB BA C0 C0 64 08 43 EC 9E 85 42",
    "to": "E6 7D 36 41 0A D7 81 42 3F A8 C8 C2"
  },
  {
    "from": "66 BD C0 C0 4E 5A 08 43 90 7E 85 42",
    "to": "DE 4D 36 41 0A D7 81 42 39 BE C6 C2"
  },
  {
    "from": "87 4D BB C0 E9 58 08 43 16 0B 86 42",
    "to": "ED F3 15 42 66 66 7E 42 AB 9E 26 C3"
  },
  {
    "from": "26 36 E1 C0 BB A7 07 43 EC 8B 86 42",
    "to": "26 FC 16 42 66 66 7E 42 61 EC 25 C3"
  },
  {
    "from": "E7 F2 E6 C0 92 B3 07 43 10 18 86 42",
    "to": "09 A3 17 42 66 66 7E 42 B4 58 27 C3"
  },
  {
    "from": "A3 76 61 C1 26 62 09 43 1B 54 8B 42",
    "to":   "B7 C4 1E 41 A9 DD 82 42 BD 96 C8 C2"
  },
  {
    "from": "F4 BD 03 C2 2B FB 32 43 CA 04 2B C2",
    "to":   "B7 C4 1E 41 A9 DD 82 42 BD 96 C8 C2"
  },
  {
    "from": "4D 03 3B C1 42 5A 1A 43 91 12 0B 42",
    "to":   "B7 C4 1E 41 A9 DD 82 42 BD 96 C8 C2"
  },
  {
    "from": "FC 7C 0D C1 C2 BE C4 42 BF 40 8F C2",
    "to":   "FC 7C 0D C1 00 44 1C 46 BF 40 8F C2"
  },
  {
    "from": "91 64 97 41 B0 83 14 43 39 C5 AD C2",
    "to":   "FC 7C 0D C1 00 44 1C 46 BF 40 8F C2"
  },
  {
    "from": "19 4B 33 C1 BF D4 0E 43 E1 CE 5A 42",
    "to":   "B2 D8 A7 40 9A 99 77 42 C0 13 B0 C2"
  },
    {
    "from": "3E 24 51 C1 8A 17 0F 43 1F DB 5A 42",
    "to":   "B2 D8 A7 40 9A 99 77 42 C0 13 B0 C2"
  },
  {
    "from": "1C 9D 94 42 7F 39 5F 43 57 06 2C C3",
    "to":   "1C 9D 94 42 FE 72 92 42 57 06 2C C3"
  },
  {
    "from": "24 AF AB 42 7F 39 5F 43 5E EF 08 C3",
    "to":   "24 AF AB 42 FE 72 92 42 5E EF 08 C3"
  },
  {
    "from": "58 53 B4 42 7F 39 5F 43 5C 53 DB C2",
    "to":   "58 53 B4 42 FE 72 92 42 5C 53 DB C2"
  },
  {
    "from": "41 A1 9B 42 07 42 58 43 69 1F CB C2",
    "to":   "41 A1 9B 42 0E 84 84 42 69 1F CB C2"
  },
  {
    "from": "0A EA 89 42 3D 91 49 43 F9 BE DF C2",
    "to":   "0A EA 89 42 F4 44 4E 42 F9 BE DF C2"
  },
  {
    "from": "69 CD 74 42 3D 91 49 43 2B 82 05 C3",
    "to":   "69 CD 74 42 F4 44 4E 42 2B 82 05 C3"
  },
  {
    "from": "5F 6E 48 42 3D 91 49 43 6F 67 2F C3",
    "to":   "5F 6E 48 42 F4 44 4E 42 6F 67 2F C3"
  },
  {
    "from": "71 84 05 42 73 62 55 43 A3 4A 3C C3",
    "to":   "71 84 05 42 CC 89 7D 42 A3 4A 3C C3"
  },
  {
    "from": "BC B2 3C 42 DA F0 62 43 88 EA 4B C3",
    "to":   "BC B2 3C 42 B4 E1 99 42 88 EA 4B C3"
  },
  {
    "from": "AB 0D 83 42 D4 BF 5F 43 A5 E0 48 C3",
    "to":   "AB 0D 83 42 A8 7F 93 42 A5 E0 48 C3"
  },
  {
    "from": "89 78 FF C0 3C 5D 85 43 1A CD 6C C3",
    "to":   "89 78 FF C0 F0 74 85 42 1A CD 6C C3"
  },
  {
    "from": "4D 75 A0 C1 3C 5D 85 43 6E AF 73 C3",
    "to":   "4D 75 A0 C1 F0 74 85 42 6E AF 73 C3"
  },
  {
    "from": "4B C4 2F C1 C5 DE 88 43 14 86 73 C3",
    "to":   "4B C4 2F C1 14 7B 93 42 14 86 73 C3"
  },
  {
    "from": "C3 2A 91 40 F3 85 84 43 BB 2F 6A C3",
    "to":   "C3 2A 91 40 CC 17 82 42 BB 2F 6A C3"
  },
  {
    "from": "E9 F5 97 41 6D 58 83 43 1D 94 65 C3",
    "to":   "E9 F5 97 41 68 C3 7A 42 1D 94 65 C3"
  },
  {
    "from": "99 86 01 42 E3 D7 80 43 1D 94 65 C3",
    "to":   "99 86 01 42 18 BF 66 42 1D 94 65 C3"
  },
  {
    "from": "9B FD 33 42 CA 26 83 43 1D 94 65 C3",
    "to":   "9B FD 33 42 50 36 79 42 1D 94 65 C3"
  },
  {
    "from": "E3 0F 1B 42 A0 54 8B 43 F7 A6 70 C3",
    "to":   "E3 0F 1B 42 80 52 9D 42 F7 A6 70 C3"
  },
  {
    "from": "22 49 DC 41 C0 2A 8B 43 04 FB 6F C3",
    "to":   "22 49 DC 41 00 AB 9C 42 04 FB 6F C3"
  },
  {
    "from": "82 6C 90 41 A6 C7 84 43 6B 6A 6D C3",
    "to":   "82 6C 90 41 98 1E 83 42 6B 6A 6D C3"
  },
  {
    "from": "5C 2E 94 40 29 76 84 43 B2 CB 69 C3",
    "to":   "5C 2E 94 40 A4 D8 81 42 B2 CB 69 C3"
  },
  {
    "from": "68 6C 32 41 78 B6 32 43 FD E5 9C C2",
    "to":   "68 6C 32 41 85 6B 89 42 FD E5 9C C2"
  },
  {
    "from": "CA E1 0D 42 C4 CF 3B 43 BD 13 BA C2",
    "to":   "CA E1 0D 42 B8 9E 87 42 BD 13 BA C2"
  },
  {
    "from": "E0 26 52 42 C9 A3 49 43 A6 A5 E5 C2",
    "to":   "E0 26 52 42 AE 47 8F 42 A6 A5 E5 C2"
  },
  {
    "from": "B4 DD 4D 42 17 73 53 43 5F 7C F8 C2",
    "to":   "48 E1 5D 42 2E E6 8E 42 5F 7C F8 C2"
  },
  {
    "from": "71 05 33 42 0E D2 54 43 0B E3 EE C2",
    "to":   "71 05 33 42 1C A4 91 42 0B E3 EE C2"
  },
  {
    "from": "3D 1E 04 42 BA 36 52 43 B5 13 DC C2",
    "to":   "3D 1E 04 42 74 6D 8C 42 B5 13 DC C2"
  },
  {
    "from": "68 B2 87 40 4A 0B 43 43 7E 46 9E C2",
    "to":   "68 B2 87 40 00 00 8C 42 7E 46 9E C2"
  },
  {
    "from": "E0 DA C0 41 60 41 5E 43 D4 9E CD C2",
    "to":   "E0 DA C0 41 C0 82 90 42 D4 9E CD C2"
  },
  {
    "from": "31 76 09 42 98 C3 5E 43 19 0B EB C2",
    "to":   "31 76 09 42 30 87 91 42 19 0B EB C2"
  },
  {
    "from": "AB 93 B3 41 F6 7F 59 43 CF 33 04 C3",
    "to":   "AB 93 B3 41 EC FF 86 42 CF 33 04 C3"
  },
  {
    "from": "3F AC 9B 3F 4A 2C 59 43 AF FD F3 C2",
    "to":   "3F AC 9B 3F 94 58 86 42 AF FD F3 C2"
  },
  {
    "from": "26 2C E6 40 07 F9 5D 43 2E 33 D3 C2",
    "to":   "26 2C E6 40 0E F2 87 42 2E 33 D3 C2"
  }
]}


def load_map_rules():
    """从嵌入的数据加载地图替换规则"""
    rules = []
    for rule in MAP_PATCH_RULES['rules']:
        from_bytes = bytes.fromhex(rule['from'].replace(' ', ''))
        to_bytes = bytes.fromhex(rule['to'].replace(' ', ''))
        rules.append((from_bytes, to_bytes))
    return rules

def apply_map_patch(data, rules):
    """对二进制数据应用地图替换规则"""
    if isinstance(data, bytes):
        data = bytearray(data)
    elif isinstance(data, bytearray):
        pass
    else:
        data = bytearray(data)
    
    modified = False
    modifications = 0
    
    for from_bytes, to_bytes in rules:
        pos = 0
        while True:
            pos = data.find(from_bytes, pos)
            if pos == -1:
                break
            data[pos:pos+len(from_bytes)] = to_bytes
            modified = True
            modifications += 1
            pos += len(to_bytes)
    
    return bytes(data), modifications, modified

def modify_items_and_integrity(apk_path):
    """
    修改全物品和绕过完整性检查
    """
    print(f"🔧 开始修改全物品和完整性: {apk_path}")
    
    if not os.path.exists(apk_path):
        print("❌ APK文件不存在")
        return False
    
    # 备份原始文件
    backup_path = apk_path + '.bak'
    shutil.copy2(apk_path, backup_path)
    print(f"✅ 已创建备份: {backup_path}")
    
    try:
        # 使用'r+b'模式打开，可读写二进制
        with zipfile.ZipFile(apk_path, 'a') as apk:  # 'a' 追加模式
            namelist = apk.namelist()
            
            modified_files = {}
            
            # === 1. 修改OutfitDefs.json ===
            print("\n🎮 查找衣柜文件...")
            json_paths = [
                'assets/Data/Resources/OutfitDefs.json',
                'assets/Data/OutfitDefs.json',
                'Data/Resources/OutfitDefs.json',
            ]
            
            json_modified = False
            for json_path in json_paths:
                if json_path in namelist:
                    print(f"找到: {json_path}")
                    
                    # 读取JSON文件
                    with apk.open(json_path, 'r') as f:
                        content = f.read().decode('utf-8')
                        data = json.loads(content)
                    
                    print("修改衣柜数据...")
                    
                    # 检查版本
                    hair_AvatarFurCham = False
                    has_21 = False
                    
                    for item in data:
                        if "season" in item and isinstance(item["season"], str):
                            if "season_18" in item["season"]:
                                hair_AvatarFurCham = True
                            if "season_21" in item["season"]:
                                has_21 = True
                            if "season_26" in item["season"]:
                                hair_AvatarFurCham = False
                    
                    print(f"改炸毛: {hair_AvatarFurCham}, 九色鹿光翼: {has_21}")
                    
                    # 修改数据
                    modified_count = 0
                    wing_modified = 0
                    
                    for item in data:
                        # 基础解锁
                        if "isDefault" in item and not item["isDefault"]:
                            item["isDefault"] = True
                            modified_count += 1
                        if "isSkyKid" in item and not item["isSkyKid"]:
                            item["isSkyKid"] = True
                            modified_count += 1
                        if "inCloset" in item and not item["inCloset"]:
                            item["inCloset"] = True
                            modified_count += 1
                        if "isOnesie" in item and not item["isOnesie"]:
                            item["isOnesie"] = True
                            modified_count += 1
                        
                        # NPC着色器
                        if "name" in item and isinstance(item["name"], str):
                            if re.search(r'npc', item["name"], re.IGNORECASE):
                                item["shader"] = "SpiritBody"
                                modified_count += 1
                        
                        # 炸毛效果
                        if hair_AvatarFurCham and "type" in item and item["type"] == "hair":
                            item["shader"] = "AvatarFurCham"
                            modified_count += 1
                        
                        # 九色鹿光翼颜色
                        if has_21 and "type" in item and item["type"] == "wing":
                            colors = []
                            for i in range(5):
                                colors.append({
                                    "highEnergy": [
                                        random.randint(0, 360),
                                        random.randint(0, 100),
                                        80
                                    ]
                                })
                            item["wingStarColors"] = colors
                            wing_modified += 1
                    
                    print(f"修改了 {modified_count} 个项目，{wing_modified} 个光翼颜色")
                    
                    # 转换为JSON字符串
                    new_json = json.dumps(data, indent=2, ensure_ascii=False)
                    modified_files[json_path] = new_json.encode('utf-8')
                    
                    json_modified = True
                    print("✅ 衣柜文件修改完成")
                    break
            
            if not json_modified:
                print("⚠️ 未找到衣柜文件")
            
            # === 2. 修改libBootloader.so ===
            print("\n🔧 查找Bootloader文件...")
            so_patterns = [
                'lib/arm64-v8a/libBootloader.so',
                'lib/armeabi-v7a/libBootloader.so',
                'lib/x86/libBootloader.so',
                'lib/x86_64/libBootloader.so',
            ]
            
            so_modified = False
            for so_path in so_patterns:
                if so_path in namelist:
                    print(f"找到: {so_path}")
                    
                    # 读取.so文件
                    with apk.open(so_path, 'r') as f:
                        so_data = f.read()
                    
                    # 查找并替换integrity
                    target = b"integrity"
                    if target in so_data:
                        count = so_data.count(target)
                        print(f"找到 {count} 个integrity字符串")
                        
                        # 逐个替换
                        new_so_data = bytearray()
                        last_pos = 0
                        pos = 0
                        
                        while True:
                            pos = so_data.find(target, pos)
                            if pos == -1:
                                break
                            
                            new_so_data.extend(so_data[last_pos:pos])
                            new_so_data.extend(b'\x00' * 9)
                            
                            last_pos = pos + 9
                            pos = last_pos
                        
                        new_so_data.extend(so_data[last_pos:])
                        
                        # 验证长度
                        if len(new_so_data) == len(so_data):
                            modified_files[so_path] = bytes(new_so_data)
                            so_modified = True
                            print(f"✅ {so_path} 修改完成")
                        else:
                            print(f"❌ 长度不匹配，跳过修改")
                    else:
                        print(f"未找到integrity字符串")
                    break
            
            if not so_modified:
                print("⚠️ 未找到Bootloader文件")
            
            # 如果有文件需要修改，创建新APK
            if modified_files:
                # 创建新APK
                temp_apk = apk_path + '.temp'
                if create_modified_apk(apk_path, temp_apk, modified_files):
                    # 替换原始APK
                    shutil.move(temp_apk, apk_path)
                    print("✅ 全物品和完整性修改完成")
                    return True
                else:
                    print("❌ 创建修改版APK失败")
                    return False
            else:
                print("❌ 没有文件需要修改")
                return False
            
    except Exception as e:
        print(f"❌ 修改失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 恢复备份
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, apk_path)
            print("✅ 已恢复原始文件")
        
        return False

def modify_map_files(apk_path):
    """修改APK中的地图文件"""
    print(f"\n🗺️  开始修改地图文件...")
    
    # 加载地图规则
    map_rules = load_map_rules()
    print(f"加载了 {len(map_rules)} 条地图替换规则")
    
    # 查找地图文件
    map_file_patterns = [
        'assets/Data/Levels/Storm/Objects.level.bin',
        'assets/Data/Levels/Storm/objects.level.bin',
        'Data/Levels/Storm/Objects.level.bin',
    ]
    
    # 查找水文件（用于复制）
    water_meshes_patterns = [
        'assets/Data/Levels/Dawn_TrialsWater/BstBaked.meshes',
        'assets/Data/Levels/Dawn_TrialsWater/bstbaked.meshes',
        'Data/Levels/Dawn_TrialsWater/BstBaked.meshes',
    ]
    
    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            namelist = apk.namelist()
            
            # 查找地图文件
            map_file_found = None
            for pattern in map_file_patterns:
                if pattern in namelist:
                    map_file_found = pattern
                    break
            
            if not map_file_found:
                print("⚠️ 未找到地图文件")
                return False
            
            print(f"找到地图文件: {map_file_found}")
            
            modified_files = {}
            
            # 读取地图文件
            with apk.open(map_file_found, 'r') as f:
                map_data = f.read()
            
            # 应用地图补丁
            print("应用地图补丁...")
            new_map_data, modifications, modified = apply_map_patch(map_data, map_rules)
            
            if not modified:
                print("❌ 地图文件未找到匹配项，未修改")
                return False
            
            print(f"✅ 地图文件修改完成，应用了 {modifications} 处替换")
            modified_files[map_file_found] = new_map_data
            
            # 查找水文件用于复制
            water_source = None
            for pattern in water_meshes_patterns:
                if pattern in namelist:
                    water_source = pattern
                    break
            
            if water_source:
                print(f"找到水文件: {water_source}")
                
                # 读取水文件
                with apk.open(water_source, 'r') as f:
                    water_data = f.read()
                
                # 创建Storm目录中的新水文件路径
                storm_dir = os.path.dirname(map_file_found)
                new_water_file = os.path.join(storm_dir, "BstBaked.meshes")
                
                modified_files[new_water_file] = water_data
                print(f"✅ 已将水文件添加到修改列表: {new_water_file}")
            
            # 创建修改后的APK
            temp_apk = apk_path + '.temp'
            if create_modified_apk(apk_path, temp_apk, modified_files):
                # 替换原始APK
                shutil.move(temp_apk, apk_path)
                print("✅ 地图文件修改完成")
                return True
            else:
                print("❌ 创建修改版APK失败")
                return False
                
    except Exception as e:
        print(f"❌ 地图修改失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def create_modified_apk(input_apk, output_apk, modified_files):
    """
    创建一个新APK，只替换指定的文件
    """
    print(f"创建修改版APK: {output_apk}")
    
    try:
        with zipfile.ZipFile(input_apk, 'r') as zin:
            with zipfile.ZipFile(output_apk, 'w') as zout:
                # 复制所有文件，替换需要修改的文件
                for item in zin.infolist():
                    if item.filename in modified_files:
                        # 使用修改后的内容
                        zout.writestr(item, modified_files[item.filename])
                        print(f"替换/添加: {item.filename}")
                    else:
                        # 复制原始文件
                        zout.writestr(item, zin.read(item.filename))
        
        return True
    except Exception as e:
        print(f"创建修改版失败: {e}")
        return False

def verify_apk(apk_path):
    """
    验证APK是否有效
    """
    try:
        with zipfile.ZipFile(apk_path, 'r') as apk:
            # 检查基本文件
            required = ['AndroidManifest.xml', 'classes.dex']
            for req in required:
                if req not in apk.namelist():
                    print(f"❌ 缺少必要文件: {req}")
                    return False
            
            # 测试ZIP完整性
            corrupt = apk.testzip()
            if corrupt:
                print(f"❌ ZIP文件损坏: {corrupt}")
                return False
            
            print("✅ APK验证通过")
            return True
    except Exception as e:
        print(f"❌ APK验证失败: {e}")
        return False

def main():
    """主函数"""
    print("=" * 60)
    print("光遇APK全功能修改工具")
    print("包含：全物品解锁 + 地图修改 + 完整性绕过")
    print("作者：县小威，qq：3661380498")
    print("公开群：1027346190")
    print("开源免费，拒绝倒卖")
    print("=" * 60)
    
    # 查找APK文件
    apk_files = []
    for file in os.listdir('.'):
        if file.endswith('.apk') and ('光遇' in file or 'sky' in file.lower() or 'Sky' in file):
            apk_files.append(file)
    
    if not apk_files:
        print("当前目录下未找到光遇APK文件")
        print("\n目录内容:")
        for file in os.listdir('.'):
            print(f"  {file}")
        
        apk_path = input("\n请输入APK文件路径: ").strip()
        if not os.path.exists(apk_path):
            print("❌ 文件不存在")
            input("\n按回车键退出...")
            return
        
        apk_files.append(apk_path)
    
    # 显示找到的文件
    print(f"找到 {len(apk_files)} 个APK文件:")
    for i, file in enumerate(apk_files, 1):
        size = os.path.getsize(file) // (1024 * 1024)
        print(f"  {i}. {file} ({size}MB)")
    
    # 选择文件
    if len(apk_files) == 1:
        apk_path = apk_files[0]
        print(f"\n使用文件: {apk_path}")
    else:
        while True:
            try:
                choice = input(f"\n选择文件 (1-{len(apk_files)}): ").strip()
                idx = int(choice) - 1
                if 0 <= idx < len(apk_files):
                    apk_path = apk_files[idx]
                    break
                else:
                    print(f"请输入 1-{len(apk_files)}")
            except ValueError:
                print("请输入数字")
    
    # 验证APK
    print("\n验证APK文件...")
    if not verify_apk(apk_path):
        print("❌ APK可能已损坏")
        input("\n按回车键退出...")
        return
    
    # 选择功能
    success = False
    # 重置输入缓冲区（针对某些IDE或环境的问题）
    if sys.stdin.isatty():
    # 如果是交互式终端，清空输入缓冲区
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            sys.stdin.read(1)  # 丢弃一个字符
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    while True:
        print("\n请选择要执行的功能:")
        print("1. 全物品解锁 + 完整性绕过")
        print("2. 地图文件修改（暴无修改）")
        print("3. 全部功能（物品+地图+完整性）")
        print("4. 退出程序")
    
    # 强制重新获取输入，不使用任何缓存
        try:
            user_input = input("请输入数字选择 (1/2/3/4): ").strip()
            print(f"[DEBUG] 用户输入: '{user_input}'")  # 调试信息
        except Exception as e:
            print(f"输入错误: {e}")
            user_input = ""
    
        if user_input == '1':
            print("\n执行功能：全物品解锁 + 完整性绕过")
            success = modify_items_and_integrity(apk_path)
            break
        
        elif user_input == '2':
            print("\n执行功能：地图文件修改")
            success = modify_map_files(apk_path)
            break
        
        elif user_input == '3':
            print("\n执行功能：全部功能")
        
        # 先备份
            backup_path = apk_path + '.full.bak'
            shutil.copy2(apk_path, backup_path)
            print(f"✅ 已创建完整备份: {backup_path}")
        
        # 1. 全物品解锁和完整性
            print("\n=== 第一步：全物品解锁 + 完整性绕过 ===")
            success1 = modify_items_and_integrity(apk_path)
        
            if success1:
                print("\n=== 第二步：地图文件修改 ===")
                success2 = modify_map_files(apk_path)
                success = success1 or success2
            else:
                print("❌ 第一步失败，跳过第二步")
                success = False
            break
        
        elif user_input == '4':
            print("退出程序")
            input("\n按回车键退出...")
            return
        
        else:
            print("❌ 输入错误，请重新选择")
        # 等待一下，让用户看到错误信息
            import time
            time.sleep(0.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n操作取消")
        input("\n按回车键退出...")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        input("\n按回车键退出...")