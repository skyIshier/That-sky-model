#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
光遇 .mesh 转 OBJ 最终稳定版（增强候选质量检查 + 暴力索引搜索）
- 精确解析优先，自动跳过68字节文件名前缀
- 若压缩数据读取不完整，回退到多候选解压
- ZipPos 顶点解码为 (b-128)/127.5
- 精确解析中如果索引越界比例超过10%，则触发回退
- 启发式解析对每个候选结果进行顶点范围合理性检查，拒绝异常大范围
- 若所有候选失败，则尝试暴力索引搜索（从0开始逐字节扫描）
- 依赖 LZ4：pkg install lz4
"""

import ctypes
import struct
import io
import os
import sys
import glob
import re
import time
import gc
import binascii

# ==================== 全局配置 ====================
DEBUG = False
LZ4_LIB = 'liblz4.so'
DEBUG_FILE = None

# ==================== 调试输出 ====================
def debug_log(*args):
    if DEBUG:
        msg = " ".join(str(a) for a in args)
        print(msg, file=sys.stderr)
        if DEBUG_FILE:
            print(msg, file=DEBUG_FILE, flush=True)

# ==================== 标签解析 ====================
def parse_tags_from_filename(filename):
    base = os.path.basename(filename)
    name = base[:-5] if base.endswith('.mesh') else base
    parts = name.split('_')
    tags = {
        'ZipPos': False, 'ZipUvs': False, 'StripNorm': False,
        'StripAnim': False, 'CompOcc': False, 'ForceIdx32': False,
        'StripUv13': False, 'CopyFrameDelay': False, 'StripGeo': False,
    }
    for p in parts:
        if p in tags:
            tags[p] = True
    return tags

# ==================== LZ4 库加载 ====================
def load_lz4():
    try:
        lz4 = ctypes.CDLL(LZ4_LIB)
        lz4.LZ4_decompress_safe.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
        lz4.LZ4_decompress_safe.restype = ctypes.c_int
        return lz4
    except OSError as e:
        print(f"LZ4库加载失败: {e}")
        if os.path.exists('/data/data/com.termux'):
            try:
                import subprocess
                subprocess.run(['pkg', 'install', '-y', 'lz4'], check=True)
                lz4 = ctypes.CDLL(LZ4_LIB)
                lz4.LZ4_decompress_safe.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
                lz4.LZ4_decompress_safe.restype = ctypes.c_int
                return lz4
            except:
                pass
        print("请手动安装 LZ4 库：pkg install lz4")
        sys.exit(1)

def half_to_float(h):
    s = int((h >> 15) & 0x0001)
    e = int((h >> 10) & 0x001f)
    f = int(h & 0x03ff)
    if e == 0:
        if f == 0:
            return 0.0 * (1.0 if s == 0 else -1.0)
        else:
            while (f & 0x0400) == 0:
                f <<= 1
                e -= 1
            e += 1
            f &= ~0x0400
    elif e == 31:
        if f == 0:
            return float('inf') * (1.0 if s == 0 else -1.0)
        else:
            return float('nan')
    e = e - 15 + 127
    f = f << 13
    return struct.unpack('>f', struct.pack('>I', (s << 31) | (e << 23) | f))[0]

# ==================== 候选解压函数 ====================
def try_decompress(data, lz4):
    """尝试多种压缩偏移解压，返回解压后数据或 None"""
    candidate_sets = [
        (0x52, 0x56, 0x5a, 4),
        (0x4e, 0x51, 0x56, 2),
        (0x4e, 0x52, 0x56, 2),
        (0x4e, 0x50, 0x56, 2),
        (0x4c, 0x50, 0x56, 2),
        (0x68, 0x6c, 0x70, 4),
    ]
    for cs_off, us_off, d_off, size_bytes in candidate_sets:
        try:
            if cs_off+size_bytes > len(data) or us_off+size_bytes > len(data) or d_off > len(data):
                continue
            if size_bytes == 4:
                cs = struct.unpack('<I', data[cs_off:cs_off+4])[0]
                us = struct.unpack('<I', data[us_off:us_off+4])[0]
            else:
                cs = struct.unpack('<H', data[cs_off:cs_off+2])[0]
                us = struct.unpack('<H', data[us_off:us_off+2])[0]
            if not (0 < cs < 10*1024*1024 and 0 < us < 50*1024*1024 and cs < us):
                continue
            compressed = data[d_off:d_off+cs]
            if len(compressed) != cs:
                continue
            dest = ctypes.create_string_buffer(us)
            ret = lz4.LZ4_decompress_safe(compressed, dest, cs, us)
            if ret <= 0:
                continue
            return dest.raw
        except:
            continue
    return None

# ==================== 精确解析器（支持跳过前缀，处理压缩数据不完整）====================
def parse_fmt_mesh_exact(f, lz4, filename):
    tags = parse_tags_from_filename(filename)
    f.seek(0)
    data = f.read()
    if len(data) < 0x80:
        raise ValueError("文件太小")

    # 检测文件头类型
    start_offset = 0
    if data[0:4] == b'\x1F\x00\x00\x00':
        debug_log("检测到标准 0x1F 头，起始偏移 0")
        start_offset = 0
    else:
        # 检查是否带有文件名前缀（版本+64字节名称）
        version = struct.unpack_from('<I', data, 0)[0]
        if 0x10 <= version <= 0x30:
            name_bytes = data[4:68]
            null_pos = name_bytes.find(b'\x00')
            if null_pos > 0 and all(32 <= b <= 126 or b == 0 for b in name_bytes[:null_pos]):
                debug_log(f"检测到文件名前缀，版本 0x{version:X}，起始偏移 68")
                start_offset = 68
            else:
                pos = data.find(b'\x1F\x00\x00\x00')
                if pos != -1:
                    debug_log(f"在偏移 0x{pos:X} 处找到 0x1F 头")
                    start_offset = pos
                else:
                    head_hex = binascii.hexlify(data[:256]).decode()
                    msg = "\n========== 文件头前256字节 ==========\n" + head_hex + "\n====================================\n"
                    debug_log(msg)
                    raise ValueError("无法找到有效文件头")
        else:
            pos = data.find(b'\x1F\x00\x00\x00')
            if pos != -1:
                debug_log(f"在偏移 0x{pos:X} 处找到 0x1F 头")
                start_offset = pos
            else:
                head_hex = binascii.hexlify(data[:256]).decode()
                msg = "\n========== 文件头前256字节 ==========\n" + head_hex + "\n====================================\n"
                debug_log(msg)
                raise ValueError("无法找到有效文件头")

    if start_offset + 0x80 > len(data):
        raise ValueError("数据不足以包含标准头部")

    # 读取压缩信息（第一个LOD）
    compressed_size = struct.unpack_from('<I', data, start_offset + 0x4E)[0]
    uncompressed_size = struct.unpack_from('<I', data, start_offset + 0x52)[0]
    compressed_start = start_offset + 0x56
    compressed = data[compressed_start:compressed_start+compressed_size]

    # 处理压缩数据读取不完整的情况
    if len(compressed) != compressed_size:
        debug_log(f"压缩数据读取不完整 (expected {compressed_size}, got {len(compressed)})，尝试候选解压")
        decompressed = try_decompress(data, lz4)
        if decompressed is None:
            raise ValueError("所有解压候选均失败")
        return parse_raw_mesh(decompressed, tags)

    dest = ctypes.create_string_buffer(uncompressed_size)
    ret = lz4.LZ4_decompress_safe(compressed, dest, compressed_size, uncompressed_size)
    if ret <= 0:
        debug_log(f"LZ4解压失败，返回码 {ret}，尝试候选解压")
        decompressed = try_decompress(data, lz4)
        if decompressed is None:
            raise ValueError("所有解压候选均失败")
    else:
        decompressed = dest.raw

    return parse_raw_mesh(decompressed, tags)

def parse_raw_mesh(decompressed, tags):
    """解析未压缩的数据体"""
    if len(decompressed) < 0x80:
        raise ValueError("解压后数据过短")
    vnum = struct.unpack_from('<I', decompressed, 0x74)[0]
    inum = struct.unpack_from('<I', decompressed, 0x78)[0]

    # ----- 合理性检查 -----
    if vnum < 5 or vnum > 50000:
        raise ValueError(f"顶点数异常: {vnum}")
    if inum < 5 or inum > 150000 or inum % 3 != 0:
        raise ValueError(f"索引数异常: {inum}")
    if tags['ZipPos'] and vnum * 4 > len(decompressed):
        raise ValueError(f"ZipPos顶点数据大小超出解压数据长度: {vnum*4} > {len(decompressed)}")
    if not tags['ZipPos'] and vnum * 16 > len(decompressed):
        raise ValueError(f"普通顶点数据大小超出解压数据长度: {vnum*16} > {len(decompressed)}")
    # --------------------

    has_bones = tags['StripAnim']
    return parse_standard_mesh(decompressed, vnum, inum, tags, has_bones)

def parse_standard_mesh(decompressed, vnum, inum, tags, has_bones=False):
    """解析解压后的标准 mesh 数据，若索引越界超过阈值则抛出异常"""
    bs = io.BytesIO(decompressed)
    is_zip = tags['ZipPos']

    if is_zip:
        bs.seek(179)
        if tags['StripAnim'] or has_bones:
            bs.seek(vnum * 8, 1)
        ibuf = bs.read(inum * 2)
        if len(ibuf) != inum * 2:
            raise ValueError("索引数据不足")
        face_count = inum // 3
        index_buffer = []
        for i in range(face_count):
            off = i * 6
            v1, v2, v3 = struct.unpack('<HHH', ibuf[off:off+6])
            index_buffer.append((v1, v2, v3))

        bs.seek(len(decompressed) - vnum * 4)
        vbuf_comp = bs.read(vnum * 4)
        if len(vbuf_comp) != vnum * 4:
            raise ValueError("压缩顶点数据不足")
        vertex_buffer = []
        for i in range(vnum):
            off = i * 4
            a, b, c, d = struct.unpack('<BBBB', vbuf_comp[off:off+4])
            # 修正：将字节映射到 [-1, 1] 范围
            x = (b - 128) / 127.5
            y = (c - 128) / 127.5
            z = (d - 128) / 127.5
            vertex_buffer.append((x, y, z))
        uv_buffer = [(0.0, 0.0)] * vnum
        parser_name = 'exact_zip'
    else:
        bs.seek(179)
        vbuf = bs.read(vnum * 16)
        if len(vbuf) != vnum * 16:
            raise ValueError("顶点数据不足")
        vertex_buffer = []
        for i in range(vnum):
            off = i * 16
            x, y, z, w = struct.unpack('<ffff', vbuf[off:off+16])
            vertex_buffer.append((x, y, z))

        bs.seek(vnum * 4, 1)
        uvbuf = bs.read(vnum * 16)
        if len(uvbuf) != vnum * 16:
            raise ValueError("UV 数据不足")
        uv_buffer = []
        for i in range(vnum):
            off = i * 16
            u16, v16 = struct.unpack('<HH', uvbuf[off:off+4])
            u = half_to_float(u16)
            v = half_to_float(v16)
            uv_buffer.append((u, v))

        if tags['StripAnim'] or has_bones:
            bs.seek(vnum * 8, 1)
        ibuf = bs.read(inum * 2)
        if len(ibuf) != inum * 2:
            raise ValueError("索引数据不足")
        face_count = inum // 3
        index_buffer = []
        for i in range(face_count):
            off = i * 6
            v1, v2, v3 = struct.unpack('<HHH', ibuf[off:off+6])
            index_buffer.append((v1, v2, v3))
        parser_name = 'exact_normal'

    # 检查索引越界比例
    out_of_range = 0
    for face in index_buffer:
        if max(face) >= vnum:
            out_of_range += 1
    if out_of_range > 0:
        ratio = out_of_range / len(index_buffer)
        if ratio > 0.1:  # 超过10%的三角形越界则视为无效
            raise ValueError(f"索引越界比例 {ratio:.2f} > 0.1，拒绝结果")
        else:
            debug_log(f"警告: 索引越界比例 {ratio:.2f}")

    max_idx = max(max(face) for face in index_buffer)
    if max_idx >= vnum:
        debug_log(f"警告: 索引越界 max_idx={max_idx} >= vnum={vnum}")

    return vertex_buffer, uv_buffer, index_buffer, parser_name

# ==================== 增强启发式解析（多候选 + 严格质量检查）====================
def find_best_vertex_candidates(data, tags, max_offset=4096, max_candidates=5):
    """返回多个候选 (vnum, inum, off)，按顶点数降序"""
    candidates = []
    for off in range(0, min(len(data)-8, max_offset), 4):
        v = struct.unpack('<I', data[off:off+4])[0]
        i = struct.unpack('<I', data[off+4:off+8])[0]
        if 5 <= v < 50000 and 5 <= i < 150000 and i % 3 == 0:
            if tags.get('ZipPos', False):
                if v * 4 <= len(data):
                    candidates.append((v, i, off))
            else:
                if v * 16 + 0x100 <= len(data):
                    candidates.append((v, i, off))
    if not candidates:
        return []
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[:max_candidates]

def check_index_quality_enhanced(index_buffer, vertex_count):
    """增强的索引质量检查：退化三角形、零值、索引范围"""
    if not index_buffer:
        return False
    total_faces = len(index_buffer)
    degenerate = 0
    zero_count = 0
    out_of_range = 0
    for face in index_buffer:
        if face[0] == face[1] or face[1] == face[2] or face[0] == face[2]:
            degenerate += 1
        if face[0] == 0:
            zero_count += 1
        if face[1] == 0:
            zero_count += 1
        if face[2] == 0:
            zero_count += 1
        if max(face) >= vertex_count:
            out_of_range += 1
    if out_of_range > 0:
        return False
    degenerate_ratio = degenerate / total_faces
    zero_ratio = zero_count / (total_faces * 3)
    if degenerate_ratio > 0.2 or zero_ratio > 0.3:
        return False
    return True

def check_vertex_range(vertex_buffer, max_abs=1000.0):
    """检查顶点范围是否合理，太大则说明可能索引错误"""
    if not vertex_buffer:
        return False
    max_coord = max(max(abs(v[0]), abs(v[1]), abs(v[2])) for v in vertex_buffer)
    # ZipPos 正常范围在 [-1,1] 左右，普通模型坐标可能在几十或几百内，但超过1000通常异常
    if max_coord > max_abs:
        debug_log(f"顶点范围过大: {max_coord:.2f} > {max_abs}，拒绝")
        return False
    return True

def find_index_region_anywhere(decomp, vertex_count, target_face_count, start_points=None, step=4, max_iter_per_start=50000):
    if start_points is None:
        start_points = [0, 0x7c, 0xb3, 0x100, 0x200, 0x300, 0x400, 0x500, 0x600, 0x800, 0x1000, 0x2000]
    for search_start in start_points:
        for start in range(search_start, len(decomp)-6, step):
            if start > search_start + max_iter_per_start*step:
                break
            # 16位
            try:
                pos = start
                sample_faces = min(target_face_count, 5)
                sample_idx = []
                for _ in range(sample_faces):
                    v1,v2,v3 = struct.unpack('<HHH', decomp[pos:pos+6])
                    if max(v1,v2,v3) >= vertex_count:
                        raise ValueError
                    sample_idx.append((v1,v2,v3))
                    pos += 6
                if not check_index_quality_enhanced(sample_idx, vertex_count):
                    continue
                idx = []
                pos = start
                for i in range(target_face_count):
                    v1,v2,v3 = struct.unpack('<HHH', decomp[pos:pos+6])
                    if max(v1,v2,v3) >= vertex_count:
                        raise ValueError
                    idx.append((v1,v2,v3))
                    pos += 6
                if check_index_quality_enhanced(idx, vertex_count):
                    return idx, 16
            except:
                # 32位
                try:
                    pos = start
                    sample_faces = min(target_face_count, 5)
                    sample_idx = []
                    for _ in range(sample_faces):
                        v1,v2,v3 = struct.unpack('<III', decomp[pos:pos+12])
                        if max(v1,v2,v3) >= vertex_count:
                            raise ValueError
                        sample_idx.append((v1,v2,v3))
                        pos += 12
                    if not check_index_quality_enhanced(sample_idx, vertex_count):
                        continue
                    idx = []
                    pos = start
                    for i in range(target_face_count):
                        v1,v2,v3 = struct.unpack('<III', decomp[pos:pos+12])
                        if max(v1,v2,v3) >= vertex_count:
                            raise ValueError
                        idx.append((v1,v2,v3))
                        pos += 12
                    if check_index_quality_enhanced(idx, vertex_count):
                        return idx, 32
                except:
                    continue
    raise ValueError("未找到有效的索引区域")

def parse_heuristic_enhanced(decompressed, tags):
    """增强的多候选启发式，返回第一个通过严格质量检查的结果"""
    candidates = find_best_vertex_candidates(decompressed, tags, max_offset=4096, max_candidates=5)

    if not candidates:
        raise ValueError("无法确定顶点数")

    for idx_try, (vnum, inum, off) in enumerate(candidates):
        debug_log(f"尝试顶点数候选 {idx_try+1}: vnum={vnum}, inum={inum}, off=0x{off:X}")
        try:
            if tags['ZipPos']:
                vert_data_size = vnum * 4
                if len(decompressed) < vert_data_size:
                    continue
                vert_start = len(decompressed) - vert_data_size
                vertex_buffer = []
                for i in range(vnum):
                    off = vert_start + i*4
                    a,b,c,d = struct.unpack('<BBBB', decompressed[off:off+4])
                    x = (b - 128) / 127.5
                    y = (c - 128) / 127.5
                    z = (d - 128) / 127.5
                    vertex_buffer.append((x,y,z))
                uv_buffer = [(0.0,0.0)] * vnum
                face_count = inum // 3
                start_points = [0, 0x7c, 0xb3, 0x100, 0x200, 0x300, 0x400, 0x500, 0x600, 0x800, 0x1000, 0x2000]
                if tags['StripAnim']:
                    start_points = [vnum * 8, 0x7c + vnum * 8, 0xb3 + vnum * 8, 0x100 + vnum * 8]
                idx_buffer, _ = find_index_region_anywhere(decompressed, vnum, face_count, start_points=start_points)
                if not check_index_quality_enhanced(idx_buffer, vnum):
                    continue
                if not check_vertex_range(vertex_buffer):
                    continue
                return vertex_buffer, uv_buffer, idx_buffer, f'heuristic_zip_c{idx_try+1}'
            else:
                vertex_buffer = []
                pos = 0xB3
                for i in range(vnum):
                    if pos+12 > len(decompressed):
                        raise ValueError
                    x,y,z = struct.unpack('<fff', decompressed[pos:pos+12])
                    vertex_buffer.append((x,y,z))
                    pos += 16
                uv_start = 0xB3 + vnum*16 + vnum*4
                uv_buffer = []
                for i in range(vnum):
                    if uv_start+4 > len(decompressed):
                        uv_buffer.append((0.0,0.0))
                        uv_start += 16
                        continue
                    u16, v16 = struct.unpack('<HH', decompressed[uv_start:uv_start+4])
                    u = half_to_float(u16)
                    v = half_to_float(v16)
                    uv_buffer.append((u, v))
                    uv_start += 16
                face_count = inum // 3
                idx_start = uv_start
                if tags['StripAnim']:
                    idx_start += vnum * 8
                idx_buffer, _ = find_index_region_anywhere(decompressed, vnum, face_count, start_points=[idx_start])
                if not check_index_quality_enhanced(idx_buffer, vnum):
                    continue
                if not check_vertex_range(vertex_buffer):
                    continue
                return vertex_buffer, uv_buffer, idx_buffer, f'heuristic_normal_c{idx_try+1}'
        except Exception as e:
            debug_log(f"候选 {idx_try+1} 失败: {e}")
            continue

    # 如果所有候选都失败，尝试暴力搜索（适用于 ZipPos）
    if tags['ZipPos']:
        debug_log("所有候选失败，尝试暴力索引搜索...")
        # 暴力搜索：假设顶点数是从0x74/0x78读出的值，但也许索引位置完全不同
        # 先尝试从0x74读取顶点数
        if len(decompressed) >= 0x7c:
            vnum = struct.unpack_from('<I', decompressed, 0x74)[0]
            inum = struct.unpack_from('<I', decompressed, 0x78)[0]
            if 5 <= vnum < 50000 and 5 <= inum < 150000 and inum % 3 == 0:
                vert_data_size = vnum * 4
                if len(decompressed) >= vert_data_size:
                    vert_start = len(decompressed) - vert_data_size
                    vertex_buffer = []
                    for i in range(vnum):
                        off = vert_start + i*4
                        a,b,c,d = struct.unpack('<BBBB', decompressed[off:off+4])
                        x = (b - 128) / 127.5
                        y = (c - 128) / 127.5
                        z = (d - 128) / 127.5
                        vertex_buffer.append((x,y,z))
                    uv_buffer = [(0.0,0.0)] * vnum
                    face_count = inum // 3
                    # 从0开始逐步扫描，步长1
                    for start in range(0, len(decompressed)-6):
                        try:
                            idx = []
                            pos = start
                            for i in range(face_count):
                                if pos+6 > len(decompressed):
                                    raise ValueError
                                v1,v2,v3 = struct.unpack('<HHH', decompressed[pos:pos+6])
                                if max(v1,v2,v3) >= vnum:
                                    raise ValueError
                                idx.append((v1,v2,v3))
                                pos += 6
                            if check_index_quality_enhanced(idx, vnum) and check_vertex_range(vertex_buffer):
                                debug_log(f"暴力搜索在 0x{start:X} 找到索引")
                                return vertex_buffer, uv_buffer, idx, 'heuristic_bruteforce'
                        except:
                            continue
    raise ValueError("所有候选均失败")

# ==================== 主解析函数 ====================
def parse_mesh_file(mesh_file, lz4):
    try:
        with open(mesh_file, 'rb') as f:
            return parse_fmt_mesh_exact(f, lz4, mesh_file)
    except Exception as e:
        debug_log(f"精确解析失败: {e}")
        if DEBUG:
            import traceback
            traceback.print_exc(file=sys.stderr)
            if DEBUG_FILE:
                traceback.print_exc(file=DEBUG_FILE)

        # 精确解析失败，尝试用候选解压获得数据（可能已经尝试过，但确保我们有一个数据）
        with open(mesh_file, 'rb') as f:
            data = f.read()
        decompressed = try_decompress(data, lz4)
        if decompressed is None:
            debug_log("所有解压候选均失败，将整个文件作为解压数据")
            decompressed = data

        tags = parse_tags_from_filename(mesh_file)
        debug_log("尝试增强版启发式...")
        return parse_heuristic_enhanced(decompressed, tags)

# ==================== 导出 OBJ ====================
def export_obj(vertex_buffer, uv_buffer, index_buffer, obj_path, with_uv=True):
    total_faces = len(index_buffer)
    with open(obj_path, 'w') as out:
        for v in vertex_buffer:
            out.write(f'v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n')
        if with_uv:
            for uv in uv_buffer:
                out.write(f'vt {uv[0]:.6f} {uv[1]:.6f}\n')
            for face in index_buffer:
                out.write(f'f {face[0]+1}/{face[0]+1} {face[1]+1}/{face[1]+1} {face[2]+1}/{face[2]+1}\n')
        else:
            for face in index_buffer:
                out.write(f'f {face[0]+1} {face[1]+1} {face[2]+1}\n')
    print(f"导出成功: {obj_path} (共 {total_faces} 个面)")

# ==================== 交互式选择文件 ====================
def interactive_select_files(all_files):
    while True:
        print("\n找到以下 .mesh 文件：")
        for i, f in enumerate(all_files):
            print(f"{i+1}. {f}")
        print("\n光遇模型(.mesh)转.obj工具 (最终稳定版，带暴力搜索)")
        print("\n请输入要转换的文件序号（支持格式：1 2 3、1-5、1,2,3 或 all）")
        print("或输入 q 退出程序。")
        choice = input("选择: ").strip().lower()
        if choice == 'q':
            return None
        if choice == 'all':
            return all_files
        selected = []
        parts = re.split(r'[,\s]+', choice)
        for part in parts:
            if not part:
                continue
            if '-' in part:
                try:
                    s,e = map(int, part.split('-'))
                    if 1 <= s <= len(all_files) and 1 <= e <= len(all_files) and s <= e:
                        selected.extend(range(s-1, e))
                except:
                    pass
            else:
                try:
                    idx = int(part)-1
                    if 0 <= idx < len(all_files):
                        selected.append(idx)
                except:
                    pass
        if not selected:
            print("未选择任何有效文件，请重新输入。")
            continue
        return [all_files[i] for i in sorted(set(selected))]

# ==================== 主程序 ====================
def main():
    import argparse
    parser = argparse.ArgumentParser(description='光遇 .mesh 转 OBJ 最终稳定版')
    parser.add_argument('files', nargs='*', help='要转换的 .mesh 文件')
    parser.add_argument('-o', '--output', default='.', help='输出目录')
    parser.add_argument('--no-uv', action='store_true', help='不导出 UV')
    parser.add_argument('--debug', action='store_true', help='启用调试输出并写入 debug.log')
    args = parser.parse_args()

    global DEBUG, DEBUG_FILE
    if args.debug:
        DEBUG = True

    lz4 = load_lz4()
    with_uv = not args.no_uv

    if args.files:
        mesh_files = [f for f in args.files if os.path.isfile(f)]
        if not mesh_files:
            print("没有有效的输入文件。")
            sys.exit(1)
        out_dir = args.output
    else:
        all_files = glob.glob("*.mesh")
        if not all_files:
            print("当前目录下没有 .mesh 文件。")
            return
        mesh_files = interactive_select_files(all_files)
        if mesh_files is None:
            return
        out_dir = input("请输入输出目录（默认: .）: ").strip() or '.'

    os.makedirs(out_dir, exist_ok=True)

    if DEBUG:
        debug_path = os.path.join(out_dir, 'debug.log')
        DEBUG_FILE = open(debug_path, 'w', encoding='utf-8')
        debug_log(f"调试日志文件: {debug_path}")

    total = len(mesh_files)
    results = []
    for idx, mesh_file in enumerate(mesh_files, 1):
        print(f"\n处理 [{idx}/{total}]: {mesh_file}")
        if DEBUG_FILE:
            print(f"\n处理 [{idx}/{total}]: {mesh_file}", file=DEBUG_FILE, flush=True)
        start = time.time()
        res = {'file': mesh_file, 'status':'failed', 'vertex_count':0, 'face_count':0, 'parser':'unknown', 'time':0.0}
        try:
            vb, uvb, ib, parser_name = parse_mesh_file(mesh_file, lz4)
            res['status'] = 'success'
            res['vertex_count'] = len(vb)
            res['face_count'] = len(ib)
            res['parser'] = parser_name
            if vb:
                xs = [v[0] for v in vb]
                ys = [v[1] for v in vb]
                zs = [v[2] for v in vb]
                print(f"  顶点范围: X[{min(xs):.3f}, {max(xs):.3f}] Y[{min(ys):.3f}, {max(ys):.3f}] Z[{min(zs):.3f}, {max(zs):.3f}]")
                if DEBUG_FILE:
                    print(f"  顶点范围: X[{min(xs):.3f}, {max(xs):.3f}] Y[{min(ys):.3f}, {max(ys):.3f}] Z[{min(zs):.3f}, {max(zs):.3f}]", file=DEBUG_FILE, flush=True)
            out_path = os.path.join(out_dir, os.path.basename(mesh_file).replace('.mesh','.obj'))
            export_obj(vb, uvb, ib, out_path, with_uv)
        except Exception as e:
            res['error'] = str(e)
            if DEBUG:
                import traceback
                traceback.print_exc(file=sys.stderr)
                if DEBUG_FILE:
                    traceback.print_exc(file=DEBUG_FILE)
                    DEBUG_FILE.flush()
        finally:
            res['time'] = time.time() - start
            results.append(res)
            if res['status'] == 'success':
                print(f"  ✅ 成功: 顶点 {res['vertex_count']}, 面 {res['face_count']}, 解析器 {res['parser']}, 耗时 {res['time']:.2f}s")
                if DEBUG_FILE:
                    print(f"  ✅ 成功: 顶点 {res['vertex_count']}, 面 {res['face_count']}, 解析器 {res['parser']}, 耗时 {res['time']:.2f}s", file=DEBUG_FILE, flush=True)
            else:
                print(f"  ❌ 失败: {res['error']}, 耗时 {res['time']:.2f}s")
                if DEBUG_FILE:
                    print(f"  ❌ 失败: {res['error']}, 耗时 {res['time']:.2f}s", file=DEBUG_FILE, flush=True)
        gc.collect()

    success = sum(1 for r in results if r['status']=='success')
    failed = total - success
    print("\n"+"="*70)
    print("批量转换完成")
    print(f"总文件: {total}, 成功: {success}, 失败: {failed}")
    if DEBUG_FILE:
        print("\n"+"="*70, file=DEBUG_FILE, flush=True)
        print("批量转换完成", file=DEBUG_FILE, flush=True)
        print(f"总文件: {total}, 成功: {success}, 失败: {failed}", file=DEBUG_FILE, flush=True)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    res_file = os.path.join(out_dir, f"转换结果_{timestamp}.txt")
    with open(res_file, 'w', encoding='utf-8') as rf:
        rf.write("="*70+"\n")
        rf.write(f"总文件: {total}, 成功: {success}, 失败: {failed}\n\n")
        if success:
            rf.write("成功文件列表:\n")
            for r in results:
                if r['status']=='success':
                    rf.write(f"  {r['file']} 顶点:{r['vertex_count']} 面:{r['face_count']} 解析器:{r['parser']} 耗时:{r['time']:.2f}s\n")
        if failed:
            rf.write("\n失败文件列表:\n")
            for r in results:
                if r['status']=='failed':
                    rf.write(f"  {r['file']} 错误:{r['error']} 耗时:{r['time']:.2f}s\n")
        rf.write("="*70+"\n")

    print(f"\n结果已保存至: {res_file}")
    if DEBUG_FILE:
        print(f"调试日志已保存至: {debug_path}")
        DEBUG_FILE.close()

if __name__ == '__main__':
    main()